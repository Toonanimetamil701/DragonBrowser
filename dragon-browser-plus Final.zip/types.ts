
export interface Tab {
  id: string;
  url: string;
  title: string;
  favicon?: string;
  lastAccessed: number;
  isLoading: boolean;
  isPrivate: boolean;
  isHibernating?: boolean;
  history: string[];
  currentIndex: number;
}

export interface HistoryItem {
  id: string;
  url: string;
  title: string;
  timestamp: number;
}

export interface Bookmark {
  id: string;
  url: string;
  title: string;
  timestamp: number;
}

export interface NoteItem {
  id: string;
  text: string;
  date: string;
}

export interface DownloadItem {
  id: string;
  filename: string;
  url: string;
  size: string;
  type: 'image' | 'video' | 'audio' | 'pdf' | 'document' | 'other';
  timestamp: number;
  progress: number;
  status: 'completed' | 'downloading' | 'failed';
}

export interface ActiveMedia {
  url: string;
  filename: string;
  type: 'video' | 'audio' | 'image';
}

export interface Language {
  code: string;
  name: string;
}

export enum BrowserViewMode {
  BROWSER = 'BROWSER',
  TAB_SWITCHER = 'TAB_SWITCHER',
  SETTINGS = 'SETTINGS',
  HISTORY = 'HISTORY',
  DOWNLOADS = 'DOWNLOADS',
  BOOKMARKS = 'BOOKMARKS',
  DEVELOPMENT_LOG = 'DEVELOPMENT_LOG',
  NOTES_LIBRARY = 'NOTES_LIBRARY',
  SHIELD = 'SHIELD'
}

export type ThemeMode = 'dark' | 'light' | 'system';
export type ThemeColor = 'ember' | 'frost' | 'midas' | 'venom';
export type SearchEngine = 'google' | 'bing' | 'dragon';

export interface ToolbarConfig {
  showDesktop: boolean;
  showFind: boolean;
  showTranslate: boolean;
  showMic: boolean;
  showNewTab: boolean;
  showNotes: boolean;
}

export interface AppSettings {
  adBlockEnabled: boolean;
  dragonBreath: boolean;
  stealthFlight: boolean;
  autoPurge: boolean;
  scaleCompression: boolean;
  searchEngine: SearchEngine;
  dragonStrength: boolean;
  themeMode: ThemeMode;
  themeColor: ThemeColor;
  wallpaper: string;
  historyEnabled: boolean;
  doNotTrack: boolean;
  safeBrowsing: boolean;
  secureDns: boolean;
  incognitoLockEnabled: boolean;
  downloadLocation: string;
  trackersBlockedTotal: number;
  sovereigntyMode: boolean; 
  toolbarConfig: ToolbarConfig;
}
