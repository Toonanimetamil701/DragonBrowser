
import React, { useState } from 'react';
import { useDragon } from '../DragonContext';
import DragonHeader from '../components/DragonHeader';
import { Search, Clock, Trash2, Globe, ExternalLink, X } from 'lucide-react';
import { BrowserViewMode } from '../types';

export const History: React.FC = () => {
  const { history, clearHistory, removeHistoryItem, setViewMode } = useDragon();
  const [search, setSearch] = useState('');

  const filteredHistory = history.filter(h => 
    (h.title?.toLowerCase() || '').includes(search.toLowerCase()) || 
    (h.url?.toLowerCase() || '').includes(search.toLowerCase())
  );

  const handleClearAll = () => {
    if (window.confirm("Wipe all Dragon Search logs?")) {
      clearHistory();
      alert("Logs Secured and Purged.");
    }
  };

  const handleOpenSite = (url: string) => {
    setViewMode(BrowserViewMode.BROWSER);
    // Note: URL navigation handled by App component state listeners
  };

  return (
    <div className="flex flex-col h-full bg-dragon-dark text-slate-100 animate-fade-in pb-safe-bottom">
      <DragonHeader 
        title="DRAGON HISTORY" 
        subtitle="TEMPORAL LOG REGISTRY" 
        onBack={() => setViewMode(BrowserViewMode.BROWSER)}
        rightElement={
          history.length > 0 && (
            <button 
              onClick={handleClearAll}
              className="px-4 py-2 bg-red-500/20 text-red-500 border border-red-500/30 rounded-xl flex items-center gap-2 font-black text-[10px] uppercase tracking-widest active:scale-95 transition-all"
            >
              <Trash2 className="w-3.5 h-3.5" /> Clear All Logs
            </button>
          )
        }
      />

      <div className="p-6 space-y-6 flex-1 overflow-y-auto no-scrollbar">
        <div className="relative group">
          <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-dragon-ember transition-colors" />
          <input 
            type="text"
            placeholder="Search temporal archives..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-dragon-navy/50 border border-white/10 rounded-[1.5rem] py-5 pl-14 pr-6 text-base text-white placeholder-slate-600 focus:outline-none focus:border-dragon-ember/50 shadow-inner"
          />
        </div>

        <div className="space-y-4">
          {filteredHistory.length === 0 ? (
            <div className="py-32 text-center space-y-6 opacity-30">
              <Clock className="w-20 h-20 mx-auto text-slate-800" />
              <div className="space-y-2">
                <p className="text-sm font-black text-slate-700 uppercase tracking-widest italic">DRAGON HISTORY: NO LOGS DETECTED</p>
                <p className="text-[10px] text-slate-800 uppercase font-bold tracking-widest">Neural fragments have been secured</p>
              </div>
            </div>
          ) : (
            filteredHistory.map((h) => (
              <div 
                key={h.id} 
                className="bg-dragon-navy/40 rounded-[2rem] p-5 border border-white/5 flex items-center gap-5 group hover:bg-white/5 transition-all shadow-xl hover:border-white/10"
              >
                <div className="w-14 h-14 rounded-2xl bg-black/40 flex items-center justify-center shadow-inner border border-white/5 group-hover:scale-105 transition-transform shrink-0">
                  <Globe className="w-6 h-6 text-slate-500 group-hover:text-dragon-cyan transition-colors" />
                </div>
                <div className="flex-1 min-w-0">
                  <h4 className="text-sm font-black truncate text-white tracking-tight">{h.title || h.url}</h4>
                  <p className="text-[10px] text-slate-500 truncate uppercase font-bold tracking-tighter opacity-60 mt-1">{h.url}</p>
                  <span className="text-[9px] text-slate-600 font-mono mt-1.5 block font-bold">
                    {new Date(h.timestamp).toLocaleString([], { month: 'short', day: 'numeric', hour: '2-digit', minute: '2-digit' })}
                  </span>
                </div>
                <div className="flex gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                  <button 
                    onClick={() => handleOpenSite(h.url)}
                    className="p-3 bg-white/10 text-slate-400 hover:text-dragon-cyan hover:bg-dragon-cyan/10 rounded-xl transition-all shadow-lg"
                    title="Open Fragment"
                  >
                    <ExternalLink className="w-4 h-4" />
                  </button>
                  <button 
                    onClick={() => removeHistoryItem(h.id)}
                    className="p-3 bg-white/10 text-slate-400 hover:text-red-500 hover:bg-red-500/10 rounded-xl transition-all shadow-lg"
                    title="Delete Fragment"
                  >
                    <X className="w-4 h-4" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
