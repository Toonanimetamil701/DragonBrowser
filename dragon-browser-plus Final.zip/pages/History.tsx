
import React, { useState, useMemo } from 'react';
import { useDragon } from '../DragonContext';
import DragonHeader from '../components/DragonHeader';
import { Search, Clock, Trash2, Globe, ExternalLink, X, Calendar, ChevronRight } from 'lucide-react';
import { BrowserViewMode, HistoryItem } from '../types';

interface HistoryProps {
  onNavigate: (url: string) => void;
  onBack: () => void;
}

export const History: React.FC<HistoryProps> = ({ onNavigate, onBack }) => {
  const { history, clearHistory, removeHistoryItem } = useDragon();
  const [search, setSearch] = useState('');

  // --- Grouping Logic ---
  const groupedHistory = useMemo(() => {
    const groups: Record<string, HistoryItem[]> = {
      'Today': [],
      'Yesterday': [],
      'Last 7 Days': [],
      'Older': []
    };

    // Filter first
    const filtered = history.filter(h => 
      (h.title?.toLowerCase() || '').includes(search.toLowerCase()) || 
      (h.url?.toLowerCase() || '').includes(search.toLowerCase())
    );

    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const yesterdayStart = todayStart - 86400000;
    const weekStart = todayStart - (86400000 * 7);

    filtered.forEach(item => {
      if (item.timestamp >= todayStart) {
        groups['Today'].push(item);
      } else if (item.timestamp >= yesterdayStart) {
        groups['Yesterday'].push(item);
      } else if (item.timestamp >= weekStart) {
        groups['Last 7 Days'].push(item);
      } else {
        groups['Older'].push(item);
      }
    });

    return groups;
  }, [history, search]);

  const groupOrder = ['Today', 'Yesterday', 'Last 7 Days', 'Older'];

  const handleClearAll = () => {
    if (window.confirm("Wipe all Dragon Search logs?")) {
      clearHistory();
    }
  };

  const handleClearGroup = (groupName: string) => {
    if (window.confirm(`Clear all history from ${groupName}?`)) {
      const items = groupedHistory[groupName];
      items.forEach(item => removeHistoryItem(item.id));
    }
  };

  const handleOpenSite = (url: string) => {
    onNavigate(url);
  };

  const getFavicon = (url: string) => {
    try {
      const domain = new URL(url).hostname;
      return `https://www.google.com/s2/favicons?sz=64&domain=${domain}`;
    } catch {
      return '';
    }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-dragon-dark text-slate-900 dark:text-slate-100 animate-fade-in pb-safe-bottom transition-colors duration-300">
      <DragonHeader 
        title="TIMELINE" 
        subtitle="TEMPORAL REGISTRY" 
        onBack={onBack}
        rightElement={
          history.length > 0 && (
            <button 
              onClick={handleClearAll}
              className="p-2 bg-red-500/10 text-red-500 hover:bg-red-500/20 rounded-xl transition-all"
              title="Wipe All History"
            >
              <Trash2 size={18} />
            </button>
          )
        }
      />

      {/* Search Bar */}
      <div className="px-6 pt-2 pb-4 shrink-0 bg-white/50 dark:bg-dragon-dark/95 backdrop-blur-xl z-20 sticky top-[80px]">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-dragon-ember transition-colors" />
          <input 
            type="text"
            placeholder="Search timeline..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-white dark:bg-dragon-navy/50 border border-slate-200 dark:border-white/10 rounded-2xl py-3 pl-11 pr-4 text-sm font-medium focus:outline-none focus:border-dragon-ember/50 shadow-sm"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar px-6 pb-20 relative">
        {history.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-full opacity-30 space-y-4">
            <div className="w-20 h-20 rounded-full bg-slate-200 dark:bg-white/5 flex items-center justify-center">
               <Clock className="w-10 h-10 text-slate-400" />
            </div>
            <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-500">Timeline Empty</p>
          </div>
        ) : (
          <div className="space-y-8 pt-2">
            {groupOrder.map(group => {
              const items = groupedHistory[group];
              if (items.length === 0) return null;

              return (
                <div key={group} className="relative animate-fade-in">
                  {/* Group Header */}
                  <div className="flex items-center justify-between mb-6 sticky top-0 bg-slate-50/95 dark:bg-dragon-dark/95 backdrop-blur-md py-2 z-10">
                    <div className="flex items-center gap-3">
                      <div className="w-2 h-2 rounded-full bg-dragon-ember shadow-[0_0_10px_rgba(249,115,22,0.5)]" />
                      <h3 className="text-sm font-black uppercase tracking-widest text-slate-700 dark:text-slate-200">{group}</h3>
                      <span className="text-[10px] font-bold text-slate-400 bg-slate-200 dark:bg-white/10 px-2 py-0.5 rounded-md">
                        {items.length}
                      </span>
                    </div>
                    {items.length > 0 && (
                      <button 
                        onClick={() => handleClearGroup(group)}
                        className="text-[9px] font-bold uppercase tracking-wider text-slate-400 hover:text-red-500 transition-colors flex items-center gap-1"
                      >
                        Clear <X size={10} />
                      </button>
                    )}
                  </div>

                  {/* Timeline Container */}
                  <div className="relative border-l-2 border-slate-200 dark:border-white/10 ml-3 space-y-6 pb-2">
                    {items.map((item) => (
                      <div key={item.id} className="relative pl-8 group">
                        {/* Timeline Node */}
                        <div className="absolute -left-[5px] top-4 w-2.5 h-2.5 rounded-full bg-slate-300 dark:bg-white/20 border-2 border-slate-50 dark:border-dragon-dark group-hover:bg-dragon-cyan group-hover:scale-125 transition-all duration-300" />

                        {/* Card */}
                        <div className="bg-white dark:bg-dragon-navy/30 rounded-2xl p-4 border border-slate-200 dark:border-white/5 shadow-sm hover:shadow-md hover:border-dragon-cyan/30 transition-all flex items-start gap-4">
                          {/* Time */}
                          <div className="flex flex-col items-center gap-1 pt-1 shrink-0 w-12">
                             <span className="text-[10px] font-mono font-bold text-slate-400 dark:text-slate-500">
                               {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
                             </span>
                          </div>

                          {/* Content */}
                          <div 
                            className="flex-1 min-w-0 cursor-pointer"
                            onClick={() => handleOpenSite(item.url)}
                          >
                            <div className="flex items-center gap-2 mb-1">
                               <img 
                                 src={getFavicon(item.url)} 
                                 className="w-4 h-4 rounded-full bg-slate-100 dark:bg-black"
                                 onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                               />
                               <h4 className="text-xs font-bold text-slate-800 dark:text-slate-200 truncate group-hover:text-dragon-cyan transition-colors">
                                 {item.title || 'Untitled Node'}
                               </h4>
                            </div>
                            <p className="text-[10px] text-slate-500 truncate font-medium">{item.url}</p>
                          </div>

                          {/* Actions */}
                          <div className="flex flex-col gap-2 opacity-0 group-hover:opacity-100 transition-opacity">
                             <button 
                               onClick={() => removeHistoryItem(item.id)}
                               className="p-2 text-slate-400 hover:text-red-500 hover:bg-red-500/10 rounded-lg transition-all"
                             >
                               <Trash2 size={14} />
                             </button>
                          </div>
                        </div>
                      </div>
                    ))}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>
    </div>
  );
};
