
import React, { useState, useMemo } from 'react';
import { useDragon } from '../DragonContext';
import { 
  Search, Clock, Trash2, Globe, X, 
  ChevronLeft, MoreVertical, Copy, Layers, Share2, CheckCircle, ArrowUpRight, Calendar
} from 'lucide-react';
import { BrowserViewMode, HistoryItem } from '../types';
import { Share } from '@capacitor/share';
import DragonHeader from '../components/DragonHeader';

interface HistoryProps {
  onNavigate: (url: string) => void;
  onOpenInNewTab: (url: string) => void;
  onOpenInBackgroundTab?: (url: string) => void;
}

export const History: React.FC<HistoryProps> = ({ onNavigate, onOpenInNewTab, onOpenInBackgroundTab }) => {
  const { history, clearHistory, removeHistoryItem, removeHistoryItems, setViewMode } = useDragon();
  const [search, setSearch] = useState('');
  const [isSelectionMode, setIsSelectionMode] = useState(false);
  const [selectedIds, setSelectedIds] = useState<Set<string>>(new Set());
  
  // Active Item for Action Sheet
  const [activeItem, setActiveItem] = useState<HistoryItem | null>(null);

  const groupedHistory = useMemo(() => {
    const groups: Record<string, HistoryItem[]> = {
      'Today': [],
      'Yesterday': [],
      'Last 7 Days': [],
      'Older': []
    };

    const filtered = history.filter(h => 
      (h.title?.toLowerCase() || '').includes(search.toLowerCase()) || 
      (h.url?.toLowerCase() || '').includes(search.toLowerCase())
    );

    const now = new Date();
    const todayStart = new Date(now.getFullYear(), now.getMonth(), now.getDate()).getTime();
    const yesterdayStart = todayStart - 86400000;
    const weekStart = todayStart - (86400000 * 7);

    filtered.forEach(item => {
      if (item.timestamp >= todayStart) {
        groups['Today'].push(item);
      } else if (item.timestamp >= yesterdayStart) {
        groups['Yesterday'].push(item);
      } else if (item.timestamp >= weekStart) {
        groups['Last 7 Days'].push(item);
      } else {
        groups['Older'].push(item);
      }
    });

    return groups;
  }, [history, search]);

  const groupOrder = ['Today', 'Yesterday', 'Last 7 Days', 'Older'];

  const handleItemClick = (item: HistoryItem) => {
    if (isSelectionMode) {
      toggleSelection(item.id);
    } else {
      onNavigate(item.url);
    }
  };

  const handleLongPress = (item: HistoryItem) => {
    if (!isSelectionMode) {
      setIsSelectionMode(true);
      toggleSelection(item.id);
      if (navigator.vibrate) navigator.vibrate(50);
    }
  };

  const toggleSelection = (id: string) => {
    setSelectedIds(prev => {
      const newSet = new Set(prev);
      if (newSet.has(id)) newSet.delete(id);
      else newSet.add(id);
      return newSet;
    });
  };

  const exitSelectionMode = () => {
    setIsSelectionMode(false);
    setSelectedIds(new Set());
  };

  const handleDeleteSelected = () => {
    if (window.confirm(`Delete ${selectedIds.size} items?`)) {
      removeHistoryItems(Array.from(selectedIds));
      exitSelectionMode();
    }
  };

  const handleClearAll = () => {
    if (window.confirm("Clear entire browsing history? This cannot be undone.")) {
      clearHistory();
    }
  };

  const handleCopyLink = () => {
    if (activeItem) {
      navigator.clipboard.writeText(activeItem.url);
      setActiveItem(null);
    }
  };

  const handleShareLink = async () => {
    if (activeItem) {
      try {
        await Share.share({ title: activeItem.title, url: activeItem.url });
      } catch {}
      setActiveItem(null);
    }
  };

  const handleDeleteItem = () => {
    if (activeItem) {
      removeHistoryItem(activeItem.id);
      setActiveItem(null);
    }
  };

  const getFavicon = (url: string) => {
    try {
      const domain = new URL(url).hostname;
      return `https://www.google.com/s2/favicons?sz=64&domain=${domain}`;
    } catch { return ''; }
  };

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-black text-slate-900 dark:text-slate-100 animate-fade-in pb-safe-bottom relative">
      
      {/* Header */}
      {isSelectionMode ? (
        <div className="px-6 pb-6 pt-[calc(1.5rem+env(safe-area-inset-top))] bg-dragon-navy border-b border-dragon-cyan/20 sticky top-0 z-20 flex items-center gap-4 text-white shadow-lg">
          <button onClick={exitSelectionMode} className="p-2 -ml-2 rounded-full hover:bg-white/10 text-slate-300">
            <X size={24} />
          </button>
          <div className="flex-1">
            <h2 className="text-lg font-black uppercase tracking-widest">{selectedIds.size} Selected</h2>
          </div>
          {selectedIds.size > 0 && (
            <button 
              onClick={handleDeleteSelected}
              className="p-3 bg-red-500/20 text-red-500 rounded-xl hover:bg-red-500/30 transition-all active:scale-95 shadow-sm"
            >
              <Trash2 size={20} />
            </button>
          )}
        </div>
      ) : (
        <DragonHeader 
          title="HISTORY" 
          subtitle="TIMELINE" 
          onBack={() => setViewMode(BrowserViewMode.MAIN_MENU)}
          rightElement={
            history.length > 0 && (
              <button 
                onClick={handleClearAll}
                className="p-2.5 bg-red-50 dark:bg-red-500/10 text-red-500 rounded-xl hover:bg-red-100 dark:hover:bg-red-500/20 transition-all"
                title="Clear All"
              >
                <Trash2 size={20} />
              </button>
            )
          }
        />
      )}

      {/* Search */}
      {!isSelectionMode && (
        <div className="px-6 py-4 bg-slate-50 dark:bg-black z-10">
          <div className="relative group">
            <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 group-focus-within:text-dragon-ember transition-colors" />
            <input 
              type="text"
              placeholder="Search history..."
              value={search}
              onChange={(e) => setSearch(e.target.value)}
              className="w-full bg-white dark:bg-[#1a1a1a] border border-slate-200 dark:border-white/10 rounded-2xl py-3.5 pl-11 pr-4 text-sm text-slate-900 dark:text-white placeholder-slate-400 dark:placeholder-slate-600 focus:outline-none focus:border-dragon-ember/50 shadow-inner transition-all"
            />
          </div>
        </div>
      )}

      {/* Timeline Content */}
      <div className="flex-1 overflow-y-auto no-scrollbar px-6 pb-20">
        {history.length === 0 ? (
          <div className="flex flex-col items-center justify-center h-64 mt-12 opacity-40 space-y-6">
            <div className="w-24 h-24 rounded-full bg-slate-200 dark:bg-white/5 flex items-center justify-center border border-slate-300 dark:border-white/5">
               <Clock className="w-10 h-10 text-slate-400" />
            </div>
            <div className="text-center space-y-2">
              <p className="text-sm font-black uppercase tracking-[0.2em] text-slate-500">Time Void</p>
              <p className="text-[10px] text-slate-400 uppercase font-bold tracking-widest">No records found</p>
            </div>
          </div>
        ) : (
          <div className="pt-2">
            {groupOrder.map((group, index) => {
              const items = groupedHistory[group];
              if (items.length === 0) return null;

              return (
                <div key={group} className="relative pl-6 pb-8 border-l-2 border-slate-200 dark:border-white/10 last:border-0 last:pb-0 ml-2.5 animate-fade-in" style={{ animationDelay: `${index * 100}ms` }}>
                  {/* Timeline Marker */}
                  <div className="absolute -left-[7px] top-0 w-3 h-3 rounded-full bg-dragon-ember ring-4 ring-slate-50 dark:ring-black z-10" />
                  
                  {/* Group Header */}
                  <h3 className="text-xs font-black uppercase tracking-[0.2em] text-slate-500 mb-6 -mt-1.5 flex items-center gap-2">
                    {group} <span className="text-[9px] opacity-60 px-2 py-0.5 bg-slate-200 dark:bg-white/10 rounded-full">{items.length}</span>
                  </h3>

                  {/* Items Grid */}
                  <div className="space-y-3">
                    {items.map((item) => {
                      const isSelected = selectedIds.has(item.id);
                      
                      return (
                        <div 
                          key={item.id}
                          className={`
                            relative flex items-center gap-4 p-4 rounded-2xl border transition-all duration-200 group
                            ${isSelectionMode 
                               ? (isSelected ? 'bg-dragon-cyan/10 border-dragon-cyan/30' : 'bg-white dark:bg-[#111] border-slate-200 dark:border-white/5 opacity-60')
                               : 'bg-white dark:bg-[#111] border-slate-200 dark:border-white/5 hover:border-dragon-ember/30 dark:hover:border-dragon-ember/30 active:scale-[0.99] shadow-sm'}
                          `}
                          onClick={() => handleItemClick(item)}
                          onContextMenu={(e) => { e.preventDefault(); handleLongPress(item); }}
                        >
                          {/* Selection Checkbox */}
                          {isSelectionMode && (
                            <div className={`w-5 h-5 rounded-full border-2 flex items-center justify-center transition-colors shrink-0 ${isSelected ? 'bg-dragon-cyan border-dragon-cyan' : 'border-slate-300 dark:border-slate-600'}`}>
                              {isSelected && <CheckCircle size={12} className="text-black" strokeWidth={3} />}
                            </div>
                          )}

                          {/* Favicon */}
                          {!isSelectionMode && (
                            <div className="w-10 h-10 rounded-xl bg-slate-100 dark:bg-black flex items-center justify-center shrink-0 border border-slate-200 dark:border-white/5 shadow-inner text-slate-400">
                               <img 
                                 src={getFavicon(item.url)} 
                                 className="w-5 h-5 rounded-sm object-contain opacity-80"
                                 onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                               />
                            </div>
                          )}

                          {/* Content */}
                          <div className="flex-1 min-w-0">
                            <h4 className={`text-[13px] font-bold truncate leading-tight mb-1 ${isSelected ? 'text-dragon-cyan' : 'text-slate-800 dark:text-slate-200'}`}>
                              {item.title || 'Untitled Page'}
                            </h4>
                            <p className="text-[10px] text-slate-500 truncate font-mono opacity-70">{item.url}</p>
                          </div>

                          {/* Time / Actions */}
                          <div className="flex items-center gap-2">
                             {!isSelectionMode && (
                               <span className="text-[9px] font-bold text-slate-400 tabular-nums">
                                 {new Date(item.timestamp).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit', hour12: false })}
                               </span>
                             )}
                             
                             {!isSelectionMode && (
                               <button 
                                 onClick={(e) => { e.stopPropagation(); setActiveItem(item); }}
                                 className="p-2 text-slate-400 hover:text-slate-800 dark:hover:text-white hover:bg-slate-100 dark:hover:bg-white/10 rounded-lg transition-colors"
                               >
                                 <MoreVertical size={16} />
                               </button>
                             )}
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              );
            })}
          </div>
        )}
      </div>

      {/* Action Sheet Modal */}
      {activeItem && (
        <div className="fixed inset-0 z-[200] flex items-end justify-center sm:items-center p-0 sm:p-4 animate-fade-in">
          <div className="absolute inset-0 bg-black/60 backdrop-blur-sm" onClick={() => setActiveItem(null)} />
          
          <div className="relative w-full max-w-sm bg-white dark:bg-[#1a1a1a] rounded-t-[2rem] sm:rounded-[2rem] border-t sm:border border-slate-200 dark:border-white/10 shadow-2xl overflow-hidden flex flex-col animate-slide-up ring-1 ring-black/5">
             <div className="p-4 bg-slate-50 dark:bg-black/40 border-b border-slate-100 dark:border-white/5 flex items-center gap-3">
                <div className="w-10 h-10 rounded-xl bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 flex items-center justify-center shrink-0">
                   <img src={getFavicon(activeItem.url)} className="w-5 h-5 opacity-80" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                </div>
                <div className="flex-1 min-w-0">
                   <h3 className="text-xs font-black text-slate-800 dark:text-white uppercase tracking-tight truncate">{activeItem.title}</h3>
                   <p className="text-[10px] text-slate-500 truncate font-mono">{activeItem.url}</p>
                </div>
                <button onClick={() => setActiveItem(null)} className="p-2 bg-slate-200 dark:bg-white/10 rounded-full text-slate-500 hover:text-slate-800 dark:hover:text-white">
                   <X size={16} />
                </button>
             </div>

             <div className="p-2 space-y-1">
                <button onClick={() => { onOpenInNewTab(activeItem.url); setActiveItem(null); }} className="w-full flex items-center gap-4 px-4 py-3.5 hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl transition-colors text-slate-700 dark:text-slate-200">
                   <ArrowUpRight size={18} />
                   <span className="text-xs font-bold uppercase tracking-widest">Open New Tab</span>
                </button>
                {onOpenInBackgroundTab && (
                  <button onClick={() => { onOpenInBackgroundTab(activeItem.url); setActiveItem(null); }} className="w-full flex items-center gap-4 px-4 py-3.5 hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl transition-colors text-slate-700 dark:text-slate-200">
                     <Layers size={18} />
                     <span className="text-xs font-bold uppercase tracking-widest">Open Background</span>
                  </button>
                )}
                <button onClick={handleCopyLink} className="w-full flex items-center gap-4 px-4 py-3.5 hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl transition-colors text-slate-700 dark:text-slate-200">
                   <Copy size={18} />
                   <span className="text-xs font-bold uppercase tracking-widest">Copy Link</span>
                </button>
                <button onClick={handleShareLink} className="w-full flex items-center gap-4 px-4 py-3.5 hover:bg-slate-100 dark:hover:bg-white/5 rounded-xl transition-colors text-slate-700 dark:text-slate-200">
                   <Share2 size={18} />
                   <span className="text-xs font-bold uppercase tracking-widest">Share</span>
                </button>
                <div className="h-px bg-slate-100 dark:bg-white/5 my-1 mx-4" />
                <button onClick={handleDeleteItem} className="w-full flex items-center gap-4 px-4 py-3.5 hover:bg-red-50 dark:hover:bg-red-500/10 rounded-xl transition-colors text-red-500">
                   <Trash2 size={18} />
                   <span className="text-xs font-bold uppercase tracking-widest">Remove from History</span>
                </button>
             </div>
          </div>
        </div>
      )}
    </div>
  );
};
