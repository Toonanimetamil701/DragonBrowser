
import React, { useState, useMemo } from 'react';
import { useDragon } from '../DragonContext';
import DragonHeader from '../components/DragonHeader';
import { 
  Palette, Search, Check, Monitor, 
  ChevronRight, Zap, Lock, ShieldCheck,
  Download, Trash2, Sun, Moon,
  Info, Pencil, FolderOpen,
  Globe, Server, Sparkles, Ghost,
  Settings as SettingsIcon, FileText, ShieldAlert,
  ArrowRight
} from 'lucide-react';
import { SearchEngine, AppSettings, BrowserViewMode } from '../types';
import { AppLockScreen } from '../components/AppLockScreen';

type SettingsPage = 'MAIN' | 'GENERAL' | 'PRIVACY' | 'STORAGE' | 'ABOUT';

export const Settings: React.FC = () => {
  const { settings, updateSettings, setViewMode, purgeAllData, architect } = useDragon();
  const [currentView, setCurrentView] = useState<SettingsPage>('MAIN');
  const [searchQuery, setSearchQuery] = useState('');
  const [showPinSetup, setShowPinSetup] = useState(false);
  
  const handleToggle = (key: keyof AppSettings) => {
    updateSettings({ [key]: !settings[key] });
  };

  const handlePinSetupComplete = (pin: string) => {
    updateSettings({ security: { ...settings.security, appLockEnabled: true, pin: pin } });
    setShowPinSetup(false);
  };

  const renderToggle = (label: string, value: boolean, onToggle: () => void, icon?: React.ReactNode) => (
    <div className="flex items-center justify-between p-5 bg-white dark:bg-dragon-navy/50 rounded-2xl border border-slate-200 dark:border-white/5 transition-all shadow-sm">
      <div className="flex items-center gap-4">
        <div className="p-2.5 bg-slate-100 dark:bg-white/5 rounded-xl text-slate-500 dark:text-slate-400">
          {icon}
        </div>
        <div className="flex flex-col">
          <span className="text-[13px] font-bold uppercase tracking-tight text-slate-800 dark:text-slate-200">{label}</span>
        </div>
      </div>
      <button
        onClick={onToggle}
        className={`w-12 h-7 rounded-full relative transition-all duration-300 shadow-inner ${value ? 'bg-dragon-ember' : 'bg-slate-300 dark:bg-slate-700'}`}
      >
        <div className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow-lg transition-all duration-300 ${value ? 'translate-x-6' : 'translate-x-1'}`} />
      </button>
    </div>
  );

  const renderGeneralSettings = () => (
    <div className="space-y-8 animate-fade-in">
       <div className="space-y-4">
          <h3 className="text-[10px] font-black text-slate-500 dark:text-slate-400 uppercase tracking-[0.3em] pl-2 border-l-2 border-dragon-ember">Search Engine</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {[
              { id: 'dragon', name: 'Dragon AI', icon: <Sparkles className="w-5 h-5" />, color: 'text-dragon-ember' },
              { id: 'google', name: 'Google', icon: <Globe className="w-5 h-5" />, color: 'text-blue-500' },
              { id: 'bing', name: 'Bing', icon: <Search className="w-5 h-5" />, color: 'text-cyan-500' },
            ].map(engine => (
              <button 
                key={engine.id}
                onClick={() => updateSettings({ searchEngine: engine.id as SearchEngine })}
                className={`flex flex-col items-center justify-center gap-3 p-6 rounded-[2rem] border transition-all ${settings.searchEngine === engine.id ? 'bg-dragon-ember/10 border-dragon-ember/40 text-white shadow-xl' : 'bg-white dark:bg-dragon-navy/50 border-transparent text-slate-500 hover:bg-white/5'}`}
              >
                <div className={settings.searchEngine === engine.id ? engine.color : 'text-slate-400'}>{engine.icon}</div>
                <span className="text-[10px] font-bold uppercase tracking-widest">{engine.name}</span>
                {settings.searchEngine === engine.id && <Check size={14} className="text-dragon-ember mt-1" />}
              </button>
            ))}
          </div>
       </div>
    </div>
  );

  const renderPrivacySettings = () => (
    <div className="space-y-8 animate-fade-in">
       <div className="space-y-3">
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] pl-2 border-l-2 border-dragon-cyan">Browser Security</h3>
          <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
            {renderToggle("Ad Blocker", settings.adBlockEnabled, () => handleToggle('adBlockEnabled'), <ShieldCheck size={18} className="text-dragon-cyan" />)}
            {renderToggle("Safe Browsing", settings.safeBrowsing, () => handleToggle('safeBrowsing'), <ShieldAlert size={18} className="text-orange-500" />)}
          </div>
       </div>

       <div className="space-y-3">
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] pl-2 border-l-2 border-dragon-ember">Privacy Settings</h3>
          <div className="grid grid-cols-1 md:grid-cols-3 gap-3">
            {renderToggle("Do Not Track", settings.doNotTrack, () => handleToggle('doNotTrack'), <Ghost size={18} />)}
            {renderToggle("Anti-Tracking", settings.stealthFlight, () => handleToggle('stealthFlight'), <Zap size={18} />)}
            {renderToggle("Secure DNS", settings.secureDns, () => handleToggle('secureDns'), <Server size={18} />)}
          </div>
       </div>

       <div className="space-y-3">
          <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] pl-2 border-l-2 border-purple-500">Device Security</h3>
          <button 
            onClick={() => settings.security.appLockEnabled ? updateSettings({ security: { ...settings.security, appLockEnabled: false } }) : setShowPinSetup(true)}
            className="w-full p-6 bg-white dark:bg-dragon-navy/50 border border-slate-200 dark:border-white/5 rounded-3xl flex items-center justify-between group hover:bg-slate-50 dark:hover:bg-white/10 transition-all shadow-sm"
          >
             <div className="flex items-center gap-4">
                <div className={`p-3 rounded-2xl ${settings.security.appLockEnabled ? 'bg-dragon-cyan/20 text-dragon-cyan' : 'bg-slate-100 dark:bg-white/5 text-slate-500'}`}>
                  <Lock size={20} />
                </div>
                <div className="text-left">
                  <p className="text-[14px] font-bold text-slate-900 dark:text-white uppercase tracking-tight">Application Lock</p>
                  <p className="text-[9px] text-slate-500 uppercase font-bold tracking-widest">{settings.security.appLockEnabled ? 'Lock is Active' : 'No Lock Set'}</p>
                </div>
             </div>
             <ChevronRight size={18} className="text-slate-300 group-hover:text-dragon-cyan transition-colors" />
          </button>
       </div>
    </div>
  );

  const renderStorageSettings = () => (
    <div className="space-y-8 animate-fade-in">
      <div className="space-y-4">
        <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] pl-2 border-l-2 border-purple-500">Storage Settings</h3>
        <div className="bg-white dark:bg-dragon-navy/50 border border-slate-200 dark:border-white/5 rounded-3xl p-6 flex flex-col md:flex-row items-start md:items-center justify-between gap-4 group shadow-sm">
          <div className="flex items-center gap-4">
            <div className="p-4 bg-purple-500/10 text-purple-500 rounded-2xl border border-purple-500/20">
              <FolderOpen size={24} />
            </div>
            <div className="text-left overflow-hidden">
              <p className="text-base font-bold text-slate-900 dark:text-white uppercase tracking-tight">Downloads Folder</p>
              <p className="text-[10px] text-slate-500 font-mono mt-1 break-all">{settings.downloadLocation}</p>
            </div>
          </div>
          <button onClick={() => alert("Select a new folder from your device storage.")} className="px-5 py-3 bg-white dark:bg-white/5 hover:bg-slate-100 dark:hover:bg-white/10 text-slate-400 hover:text-dragon-cyan rounded-xl border border-slate-200 dark:border-white/5 transition-all text-[10px] font-black uppercase tracking-widest flex items-center gap-2">
            <Pencil size={14} /> Change Path
          </button>
        </div>
      </div>
      
      <div className="space-y-4">
        <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] pl-2 border-l-2 border-red-500">Danger Zone</h3>
        <button 
          onClick={() => { if(window.confirm('WARNING: This will delete all history, bookmarks, and saved data. Continue?')) purgeAllData(); }}
          className="w-full p-6 bg-red-500/5 border border-red-500/10 hover:bg-red-500/10 text-red-500 rounded-[2.5rem] flex items-center justify-center gap-4 font-black uppercase text-xs tracking-[0.2em] active:scale-95 transition-all group"
        >
          <Trash2 size={20} className="group-hover:rotate-12 transition-transform" /> 
          Clear All Browser Data
        </button>
      </div>
    </div>
  );

  const renderAboutSettings = () => (
    <div className="space-y-12 animate-fade-in flex flex-col items-center text-center py-10">
       <div className="relative">
          <div className="absolute -inset-16 bg-dragon-ember/20 blur-[100px] rounded-full animate-pulse-slow" />
          <img src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" className="w-32 h-32 md:w-40 md:h-40 rounded-[3rem] object-cover border border-white/10 relative z-10 shadow-2xl" alt="Dragon" />
          <div className="absolute -bottom-4 -right-4 p-4 bg-dragon-navy rounded-2xl border border-white/10 z-20 shadow-xl">
             <ShieldCheck className="w-8 h-8 text-dragon-cyan" />
          </div>
       </div>
       
       <div className="space-y-3 relative z-10">
          <h2 className="text-4xl md:text-5xl font-black text-white italic tracking-tighter uppercase leading-none">Dragon Browser</h2>
          <div className="flex items-center justify-center gap-3">
             <span className="h-[2px] w-8 bg-dragon-ember rounded-full" />
             <p className="text-dragon-ember text-xs font-black tracking-[0.5em] uppercase">Private Edition</p>
             <span className="h-[2px] w-8 bg-dragon-ember rounded-full" />
          </div>
          <p className="text-slate-500 text-[10px] font-bold uppercase tracking-[0.2em]">Version 1.1.2 STABLE</p>
       </div>

       <div className="grid grid-cols-2 gap-4 w-full max-w-sm">
          <div className="bg-white dark:bg-dragon-navy/50 p-6 rounded-3xl border border-white/5 shadow-sm">
             <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Developer</p>
             <p className="text-sm font-bold text-white uppercase">{architect}</p>
          </div>
          <div className="bg-white dark:bg-dragon-navy/50 p-6 rounded-3xl border border-white/5 shadow-sm">
             <p className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-1">Platform</p>
             <p className="text-sm font-bold text-white uppercase">Sovereign V8</p>
          </div>
       </div>

       <div className="pt-8 opacity-40">
          <p className="text-[9px] text-slate-400 font-bold leading-relaxed max-w-xs uppercase tracking-tight">
            High-performance browsing with a focus on user privacy and data security.
          </p>
       </div>
    </div>
  );

  const renderMainMenu = () => (
    <div className="grid grid-cols-1 md:grid-cols-2 gap-4 animate-fade-in">
      {[
        { id: 'GENERAL', label: 'General', desc: 'Search engine & behavior', icon: <SettingsIcon size={20} className="text-dragon-ember" /> },
        { id: 'PRIVACY', label: 'Privacy & Security', desc: 'Lock, Shield, Protection', icon: <ShieldCheck size={20} className="text-dragon-cyan" /> },
        { id: 'STORAGE', label: 'Downloads & Data', desc: 'Storage path & cleanup', icon: <Download size={20} className="text-purple-500" /> },
        { id: 'ABOUT', label: 'About Dragon', desc: 'App version & info', icon: <Info size={20} className="text-slate-500" /> },
      ].map(item => (
        <button
          key={item.id}
          onClick={() => setCurrentView(item.id as SettingsPage)}
          className="w-full p-6 bg-white dark:bg-dragon-navy/50 border border-slate-200 dark:border-white/5 rounded-[2.5rem] flex items-center justify-between group hover:bg-slate-50 dark:hover:bg-white/10 transition-all shadow-sm hover:shadow-xl hover:scale-[1.01]"
        >
          <div className="flex items-center gap-5 min-w-0">
            <div className="p-4 rounded-2xl bg-slate-50 dark:bg-black/40 border border-slate-100 dark:border-white/5 group-hover:scale-110 transition-transform shrink-0">
              {item.icon}
            </div>
            <div className="flex flex-col items-start text-left min-w-0">
              <span className="text-[15px] font-bold text-slate-900 dark:text-slate-100 uppercase tracking-tighter truncate w-full">{item.label}</span>
              <span className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest mt-1 truncate w-full">{item.desc}</span>
            </div>
          </div>
          <ChevronRight size={20} className="text-slate-300 dark:text-slate-600 group-hover:text-dragon-cyan transition-colors shrink-0" />
        </button>
      ))}
    </div>
  );

  const getHeaderTitle = () => {
    switch(currentView) {
      case 'GENERAL': return "GENERAL";
      case 'PRIVACY': return "PRIVACY & SECURITY";
      case 'STORAGE': return "DOWNLOADS & DATA";
      case 'ABOUT': return "ABOUT DRAGON";
      default: return "SETTINGS";
    }
  };

  const getHeaderSubtitle = () => {
    switch(currentView) {
      case 'MAIN': return "BROWSER CONTROLS";
      default: return "SET PREFERENCES";
    }
  };

  if (showPinSetup) {
    return <AppLockScreen isSetupMode={true} onSetupComplete={handlePinSetupComplete} onCancelSetup={() => setShowPinSetup(false)} />;
  }

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-dragon-dark text-slate-900 dark:text-slate-100 overflow-hidden relative">
      <DragonHeader 
        title={getHeaderTitle()} 
        subtitle={getHeaderSubtitle()} 
        onBack={() => {
          if (currentView !== 'MAIN') setCurrentView('MAIN');
          else setViewMode(BrowserViewMode.MAIN_MENU);
        }} 
      />
      
      {currentView === 'MAIN' && (
        <div className="px-6 py-4 bg-slate-50 dark:bg-dragon-dark/95 backdrop-blur-xl z-40 sticky top-0 flex justify-center">
          <div className="relative group w-full max-w-4xl">
            <Search className="absolute left-5 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-400 dark:text-slate-500 group-focus-within:text-dragon-ember transition-colors" />
            <input
              type="text"
              placeholder="Search setting fragments..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="w-full bg-white dark:bg-dragon-navy/80 border border-slate-200 dark:border-white/10 rounded-[1.5rem] py-4 pl-14 pr-6 text-base font-medium focus:outline-none focus:border-dragon-ember/50 shadow-inner"
            />
          </div>
        </div>
      )}

      <div className="flex-1 overflow-y-auto no-scrollbar pb-safe-bottom">
        <div className="max-w-4xl mx-auto px-6 py-4 space-y-6">
          {searchQuery ? (
             <div className="py-20 text-center space-y-4 opacity-30">
               <Ghost size={48} className="mx-auto text-slate-400" />
               <p className="text-[10px] font-black uppercase tracking-[0.4em]">Search Not Available</p>
             </div>
          ) : (
            <>
              {currentView === 'GENERAL' && renderGeneralSettings()}
              {currentView === 'PRIVACY' && renderPrivacySettings()}
              {currentView === 'STORAGE' && renderStorageSettings()}
              {currentView === 'ABOUT' && renderAboutSettings()}
              {currentView === 'MAIN' && renderMainMenu()}
            </>
          )}

          {/* Resources links for standard info */}
          {currentView === 'MAIN' && (
             <div className="pt-10 space-y-4 pb-12">
                <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] text-center">Resources</h3>
                <div className="flex flex-wrap justify-center gap-3">
                   {[
                     { label: 'Privacy Policy', icon: <Ghost size={12} /> },
                     { label: 'Feedback', icon: <FileText size={12} /> },
                     { label: 'Developer Hub', icon: <Globe size={12} /> }
                   ].map(link => (
                     <button key={link.label} className="px-5 py-3 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 rounded-2xl text-[9px] font-black uppercase tracking-widest text-slate-500 hover:text-dragon-cyan transition-all flex items-center gap-2 shadow-sm">
                       {link.icon} {link.label}
                     </button>
                   ))}
                </div>
             </div>
          )}
        </div>
      </div>
    </div>
  );
};
