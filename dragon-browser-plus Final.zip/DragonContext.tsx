import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { AppSettings, HistoryItem, Bookmark, DownloadItem, BrowserViewMode, ActiveMedia, NoteItem, ToolbarConfig, SecurityConfig, SitePermissions, DownloadPriority, SystemPermissions } from './types';
import { App as CapacitorApp } from '@capacitor/app';
import { LocalNotifications } from '@capacitor/local-notifications';

// Mocking the NativeBiometric plugin interface for safe web fallback
const NativeBiometric = {
  isAvailable: async () => {
    return { isAvailable: true }; 
  },
  verifyIdentity: async (options?: any) => {
    return Promise.resolve();
  }
};

export interface Shortcut {
  id: string;
  name: string;
  url: string;
  isProtected?: boolean;
}

interface DragonContextType {
  settings: AppSettings;
  updateSettings: (updates: Partial<AppSettings>) => void;
  history: HistoryItem[];
  addHistory: (item: Omit<HistoryItem, 'id' | 'timestamp'>) => void;
  removeHistoryItem: (id: string) => void;
  clearHistory: () => void;
  bookmarks: Bookmark[];
  toggleBookmark: (url: string, title: string) => void;
  downloads: DownloadItem[];
  addDownload: (url: string, filename: string) => void;
  removeDownload: (id: string) => void;
  pauseDownload: (id: string) => void;
  resumeDownload: (id: string) => void;
  cancelDownload: (id: string) => void;
  updateDownloadPriority: (id: string, priority: DownloadPriority) => void;
  moveDownloadOrder: (id: string, direction: 'up' | 'down') => void;
  speedDial: Shortcut[];
  addShortcut: (name: string, url: string) => void;
  removeShortcut: (id: string) => void;
  updateSpeedDial: (shortcuts: Shortcut[]) => void;
  notes: NoteItem[];
  deletedNotes: NoteItem[];
  addNote: (content: string) => void;
  removeNote: (id: string) => void;
  recoverNote: (id: string) => void;
  permanentlyDeleteNote: (id: string) => void;
  clearAllNotes: () => void;
  viewMode: BrowserViewMode;
  setViewMode: (mode: BrowserViewMode) => void;
  isIncognitoAuthenticated: boolean;
  authenticateTabLock: () => Promise<boolean>;
  setIncognitoLocked: (locked: boolean) => void;
  architect: string;
  incrementTrackers: (count: number) => void;
  purgeAllData: () => void;
  activeMedia: ActiveMedia | null;
  playMedia: (url: string, filename: string, type: 'video' | 'audio' | 'image') => void;
  closeMedia: () => void;
  // App Lock Props
  isAppLocked: boolean;
  unlockApp: () => void;
  lockApp: () => void;
  performBiometricCheck: () => Promise<boolean>;
  // Site Permissions
  getSitePermissions: (url: string) => SitePermissions;
  updateSitePermissions: (url: string, permissions: Partial<SitePermissions>) => void;
  resetSitePermissions: (url: string) => void;
  // System Permission Management
  requestSystemPermission: (type: keyof SystemPermissions) => Promise<boolean>;
}

const DragonContext = createContext<DragonContextType | undefined>(undefined);

export const useDragon = () => {
  const context = useContext(DragonContext);
  if (!context) {
    throw new Error('useDragon must be used within a DragonProvider');
  }
  return context;
};

const DEFAULT_SHORTCUTS: Shortcut[] = [
  { id: 'sd-1', name: 'Google', url: 'google.com', isProtected: true },
  { id: 'sd-2', name: 'YouTube', url: 'youtube.com', isProtected: true },
  { id: 'sd-3', name: 'Facebook', url: 'facebook.com', isProtected: true },
  { id: 'sd-4', name: 'Gemini', url: 'gemini.google.com', isProtected: true },
  { id: 'sd-5', name: 'Instagram', url: 'instagram.com', isProtected: true },
  { id: 'sd-6', name: 'Amazon', url: 'amazon.com', isProtected: false },
  { id: 'sd-7', name: 'ChatGPT', url: 'chatgpt.com', isProtected: false },
  { id: 'sd-8', name: 'Netflix', url: 'netflix.com', isProtected: false }
];

const DEFAULT_SITE_PERMISSIONS: SitePermissions = {
  javascript: true,
  cookies: true,
  location: true,
  camera: true,
  microphone: true,
  popups: false,
  lastModified: 0
};

const DEFAULT_SYSTEM_PERMISSIONS: SystemPermissions = {
  camera: 'prompt',
  microphone: 'prompt',
  location: 'prompt',
  notifications: 'prompt',
  storage: 'prompt'
};

const MAX_CONCURRENT_DOWNLOADS = 3;

// Utility to generate a numeric ID from a string for LocalNotifications
const getNotificationId = (id: string) => {
  let hash = 0;
  for (let i = 0; i < id.length; i++) {
    const char = id.charCodeAt(i);
    hash = ((hash << 5) - hash) + char;
    hash = hash & hash;
  }
  return Math.abs(hash); // Ensure positive
};

export const DragonProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const architect = "Amudhan T";
  
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('dragon_settings');
    const defaultSettings: AppSettings = {
      adBlockEnabled: true, dragonBreath: true, stealthFlight: true, autoPurge: false,
      javaScriptEnabled: true,
      scaleCompression: false, isDesktopMode: false, searchEngine: 'dragon',
      themeMode: 'system', themeColor: 'ember', wallpaper: 'void', historyEnabled: true,
      doNotTrack: true, safeBrowsing: true, secureDns: true, incognitoLockEnabled: false,
      downloadLocation: '/Internal Storage/Downloads/Dragon', 
      muteDownloadNotifications: false,
      trackersBlockedTotal: 0, // Reset to 0 for real counting
      sovereigntyMode: false, 
      toolbarConfig: {
        showFind: true, 
        showTranslate: true, 
        showMic: true, 
        showNewTab: true, 
        showNotes: true, 
        showDesktopMode: true,
        showBookmark: true,
        showTabs: true
      },
      security: {
        appLockEnabled: false,
        pin: null,
        biometricsEnabled: false,
        lockTimeout: 30000 
      },
      systemPermissions: DEFAULT_SYSTEM_PERMISSIONS
    };
    if (!saved) return defaultSettings;
    try {
      const parsed = JSON.parse(saved);
      return {
        ...defaultSettings,
        ...parsed,
        toolbarConfig: { ...defaultSettings.toolbarConfig, ...(parsed.toolbarConfig || {}) },
        security: { ...defaultSettings.security, ...(parsed.security || {}) },
        systemPermissions: { ...defaultSettings.systemPermissions, ...(parsed.systemPermissions || DEFAULT_SYSTEM_PERMISSIONS) }
      };
    } catch {
      return defaultSettings;
    }
  });

  const [history, setHistory] = useState<HistoryItem[]>(() => {
    const saved = localStorage.getItem('dragon_history');
    try {
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => {
    const saved = localStorage.getItem('dragon_bookmarks');
    try {
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [downloads, setDownloads] = useState<DownloadItem[]>(() => {
    const saved = localStorage.getItem('dragon_downloads');
    try {
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [speedDial, setSpeedDial] = useState<Shortcut[]>(() => {
    const saved = localStorage.getItem('dragon_speed_dial');
    if (!saved) return DEFAULT_SHORTCUTS;
    try {
      const parsed = JSON.parse(saved);
      const protectedOnes = DEFAULT_SHORTCUTS.filter(s => s.isProtected);
      const userItems = parsed.filter((p: Shortcut) => !protectedOnes.some(pr => pr.url === p.url));
      return [...protectedOnes, ...userItems].slice(0, 8);
    } catch {
      return DEFAULT_SHORTCUTS;
    }
  });

  const [notes, setNotes] = useState<NoteItem[]>(() => {
    const saved = localStorage.getItem('dragon_notes_library');
    try {
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [deletedNotes, setDeletedNotes] = useState<NoteItem[]>(() => {
    const saved = localStorage.getItem('dragon_notes_trash');
    try {
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [sitePermissionRegistry, setSitePermissionRegistry] = useState<Record<string, SitePermissions>>(() => {
    const saved = localStorage.getItem('dragon_site_permissions');
    try {
      return saved ? JSON.parse(saved) : {};
    } catch {
      return {};
    }
  });

  const [viewMode, setViewMode] = useState<BrowserViewMode>(BrowserViewMode.BROWSER);
  const [activeMedia, setActiveMedia] = useState<ActiveMedia | null>(null);
  const [isAppLocked, setIsAppLocked] = useState<boolean>(() => settings.security?.appLockEnabled || false);
  const lastBackgroundTime = useRef<number>(Date.now());

  // Download Management Refs
  const downloadControllers = useRef<Map<string, AbortController>>(new Map());
  const downloadBuffers = useRef<Map<string, Uint8Array[]>>(new Map());
  const queueProcessorTimeout = useRef<number | null>(null);

  // --- Effects ---
  useEffect(() => { localStorage.setItem('dragon_settings', JSON.stringify(settings)); }, [settings]);
  useEffect(() => { localStorage.setItem('dragon_speed_dial', JSON.stringify(speedDial)); }, [speedDial]);
  useEffect(() => { localStorage.setItem('dragon_history', JSON.stringify(history)); }, [history]);
  useEffect(() => { localStorage.setItem('dragon_bookmarks', JSON.stringify(bookmarks)); }, [bookmarks]);
  useEffect(() => { localStorage.setItem('dragon_notes_library', JSON.stringify(notes)); }, [notes]);
  useEffect(() => { localStorage.setItem('dragon_notes_trash', JSON.stringify(deletedNotes)); }, [deletedNotes]);
  useEffect(() => { localStorage.setItem('dragon_downloads', JSON.stringify(downloads)); }, [downloads]);
  useEffect(() => { localStorage.setItem('dragon_site_permissions', JSON.stringify(sitePermissionRegistry)); }, [sitePermissionRegistry]);

  // Request Notification Permission & Register Actions
  useEffect(() => {
    const setupNotifications = async () => {
      try {
        if (LocalNotifications) {
          // Check tracking state first
          if (settings.systemPermissions.notifications !== 'granted') return;

          const perm = await LocalNotifications.requestPermissions();
          if (perm.display === 'granted') {
            await LocalNotifications.registerActionTypes({
              types: [{
                id: 'DOWNLOAD_ACTIONS',
                actions: [
                  { id: 'pause', title: 'Pause' },
                  { id: 'cancel', title: 'Cancel', destructive: true }
                ]
              }, {
                id: 'PAUSED_ACTIONS',
                actions: [
                  { id: 'resume', title: 'Resume' },
                  { id: 'cancel', title: 'Cancel', destructive: true }
                ]
              }]
            });

            LocalNotifications.addListener('localNotificationActionPerformed', (notification) => {
              const { actionId, notification: { extra } } = notification;
              if (extra && extra.downloadId) {
                if (actionId === 'pause') pauseDownload(extra.downloadId);
                if (actionId === 'resume') resumeDownload(extra.downloadId);
                if (actionId === 'cancel') cancelDownload(extra.downloadId);
              }
            });
          }
        }
      } catch (e) {
        console.warn("Notification setup failed (non-native env):", e);
      }
    };
    setupNotifications();
  }, [settings.systemPermissions.notifications]); 

  useEffect(() => {
    let appStateListener: any;
    const setupListener = async () => {
      appStateListener = await CapacitorApp.addListener('appStateChange', ({ isActive }) => {
        if (!isActive) {
          lastBackgroundTime.current = Date.now();
        } else {
          const timeDiff = Date.now() - lastBackgroundTime.current;
          if (settings.security.appLockEnabled && timeDiff > settings.security.lockTimeout) {
            setIsAppLocked(true);
          }
        }
      });
    };
    setupListener();
    return () => { if (appStateListener) appStateListener.remove(); };
  }, [settings.security.appLockEnabled, settings.security.lockTimeout]);

  // --- Queue Processing ---
  const priorityWeight = (p: DownloadPriority) => {
    if (p === 'high') return 3;
    if (p === 'normal') return 2;
    return 1;
  };

  const processQueue = useCallback(() => {
    if (queueProcessorTimeout.current) clearTimeout(queueProcessorTimeout.current);
    
    queueProcessorTimeout.current = window.setTimeout(() => {
      setDownloads(currentDownloads => {
        const active = currentDownloads.filter(d => d.status === 'downloading');
        const queued = currentDownloads.filter(d => d.status === 'queued');
        
        queued.sort((a, b) => {
          const pA = priorityWeight(a.priority);
          const pB = priorityWeight(b.priority);
          if (pA !== pB) return pB - pA; 
          return a.queueIndex - b.queueIndex; 
        });

        if (active.length < MAX_CONCURRENT_DOWNLOADS && queued.length > 0) {
          const next = queued[0];
          setTimeout(() => {
             startStreamDownload(next.id, next.url, next.receivedBytes);
          }, 0);
          return currentDownloads;
        }

        if (active.length >= MAX_CONCURRENT_DOWNLOADS && queued.length > 0) {
          const highestQueued = queued[0];
          const sortedActive = [...active].sort((a, b) => priorityWeight(a.priority) - priorityWeight(b.priority));
          const lowestActive = sortedActive[0];

          if (priorityWeight(highestQueued.priority) > priorityWeight(lowestActive.priority)) {
             const controller = downloadControllers.current.get(lowestActive.id);
             if (controller) controller.abort();
             
             setTimeout(() => {
                startStreamDownload(highestQueued.id, highestQueued.url, highestQueued.receivedBytes);
             }, 0);
             
             return currentDownloads.map(d => {
               if (d.id === lowestActive.id) return { ...d, status: 'paused', speed: 'Paused (Preempted)' };
               return d;
             });
          }
        }

        return currentDownloads;
      });
    }, 100);
  }, []);

  useEffect(() => {
    const hasQueued = downloads.some(d => d.status === 'queued');
    const activeCount = downloads.filter(d => d.status === 'downloading').length;
    
    if (hasQueued && activeCount < MAX_CONCURRENT_DOWNLOADS) {
      processQueue();
    }
  }, [downloads.length]);


  // --- Helper Functions ---
  const formatSize = (bytes: number) => {
    if (bytes === 0) return '0 B';
    const k = 1024;
    const sizes = ['B', 'KB', 'MB', 'GB', 'TB'];
    const i = Math.floor(Math.log(bytes) / Math.log(k));
    return parseFloat((bytes / Math.pow(k, i)).toFixed(2)) + ' ' + sizes[i];
  };

  const updateNativeNotification = async (
    id: string, 
    filename: string, 
    progress: number, 
    speed: string, 
    status: 'downloading' | 'paused' | 'completed' | 'failed'
  ) => {
    try {
      if (!LocalNotifications || settings.systemPermissions.notifications !== 'granted') return;
      const notifId = getNotificationId(id);

      if (status === 'completed' || status === 'failed') {
        await LocalNotifications.cancel({ notifications: [{ id: notifId }] });
        if (status === 'completed') {
           await LocalNotifications.schedule({
             notifications: [{
               title: 'Download Complete',
               body: `${filename} has been saved.`,
               id: notifId + 10000, 
               schedule: { at: new Date(Date.now() + 100) },
               sound: settings.muteDownloadNotifications ? undefined : 'default',
               smallIcon: 'ic_stat_save',
             }]
           });
        }
        return;
      }

      const bars = Math.floor(progress / 10);
      const visualBar = '[' + '||||||||||'.substring(0, bars) + '..........'.substring(0, 10 - bars) + ']';

      await LocalNotifications.schedule({
        notifications: [{
          title: status === 'paused' ? `Paused: ${filename}` : `Downloading: ${filename}`,
          body: `${progress}% • ${speed} • ${visualBar}`,
          id: notifId,
          schedule: { at: new Date(Date.now() + 100) },
          ongoing: true,
          autoCancel: false,
          sound: settings.muteDownloadNotifications ? undefined : 'default',
          smallIcon: 'ic_stat_download', 
          actionTypeId: status === 'paused' ? 'PAUSED_ACTIONS' : 'DOWNLOAD_ACTIONS',
          extra: { downloadId: id }
        }]
      });
    } catch (e) { }
  };

  const notify = (title: string, body: string) => {
    if ('Notification' in window && Notification.permission === 'granted' && !settings.muteDownloadNotifications) {
      new Notification(title, { body, icon: '/favicon.ico' });
    }
  };

  const getFileType = (name: string): DownloadItem['type'] => {
    const ext = name.split('.').pop()?.toLowerCase();
    if (['jpg', 'jpeg', 'png', 'gif', 'webp'].includes(ext || '')) return 'image';
    if (['mp4', 'webm', 'avi', 'mov', 'mkv'].includes(ext || '')) return 'video';
    if (['mp3', 'wav', 'ogg'].includes(ext || '')) return 'audio';
    if (['pdf'].includes(ext || '')) return 'pdf';
    if (['doc', 'docx', 'txt', 'xls'].includes(ext || '')) return 'document';
    if (['zip', 'rar', '7z'].includes(ext || '')) return 'archive';
    if (['apk'].includes(ext || '')) return 'apk';
    return 'other';
  };

  // --- Permission Management ---
  const requestSystemPermission = useCallback(async (type: keyof SystemPermissions): Promise<boolean> => {
    const current = settings.systemPermissions[type];
    
    // 1. Check if already granted
    if (current === 'granted') return true;

    // 2. Trigger Native Request Directly (Auto-Grant enabled in native wrapper)
    try {
      if (type === 'camera') {
        // Trigger via MediaDevices to prompt OS
        await navigator.mediaDevices.getUserMedia({ video: true }).then(stream => {
          stream.getTracks().forEach(track => track.stop()); // Stop immediately after permission
        });
      } else if (type === 'microphone') {
        // Trigger via MediaDevices
        await navigator.mediaDevices.getUserMedia({ audio: true }).then(stream => {
          stream.getTracks().forEach(track => track.stop());
        });
      } else if (type === 'location') {
        // Trigger via Geolocation
        await new Promise((resolve, reject) => {
          navigator.geolocation.getCurrentPosition(resolve, reject);
        });
      } else if (type === 'notifications') {
        const result = await LocalNotifications.requestPermissions();
        if (result.display !== 'granted') throw new Error('Denied');
      } else if (type === 'storage') {
        // Android 13+ Granular Permissions Logic
        console.log("Requesting Granular Media Permissions (Images, Video, Audio)...");
        // Simulate native grant
        await new Promise(resolve => setTimeout(resolve, 500));
      }

      // 3. Update State on Success
      setSettings(prev => ({
        ...prev,
        systemPermissions: { ...prev.systemPermissions, [type]: 'granted' }
      }));
      
      if (type === 'storage') {
        notify("Media & File Access Secured", "Dragon Browser can now upload and download files.");
      }
      
      return true;

    } catch (e) {
      console.warn(`Permission denied for ${type}:`, e);
      setSettings(prev => ({
        ...prev,
        systemPermissions: { ...prev.systemPermissions, [type]: 'denied' }
      }));
      return false;
    }
  }, [settings.systemPermissions]);

  // --- Download Logic ---
  const startStreamDownload = async (id: string, url: string, startByte = 0) => {
    // 1. Check for Storage Permission FIRST
    if (settings.systemPermissions.storage !== 'granted') {
      const granted = await requestSystemPermission('storage');
      if (!granted) {
        setDownloads(prev => prev.map(d => d.id === id ? { ...d, status: 'failed' } : d));
        notify("Download Failed", "Media/File permission is required to save files.");
        return;
      }
    }

    const controller = new AbortController();
    downloadControllers.current.set(id, controller);

    try {
      setDownloads(prev => prev.map(d => d.id === id ? { 
        ...d, 
        status: 'downloading',
        speed: 'Starting...'
      } : d));

      const response = await fetch(url, {
        signal: controller.signal,
        headers: startByte > 0 ? { 'Range': `bytes=${startByte}-` } : {},
        mode: 'cors', 
        referrerPolicy: 'no-referrer',
        credentials: 'omit' 
      });

      if (!response.ok) throw new Error(`HTTP Error: ${response.status}`);
      if (!response.body) throw new Error("ReadableStream not supported");

      const contentLength = response.headers.get('content-length');
      const contentType = response.headers.get('content-type') || 'application/octet-stream';
      const totalBytes = contentLength ? parseInt(contentLength, 10) + startByte : 0;
      
      const reader = response.body.getReader();
      let receivedLength = startByte;
      const chunks: Uint8Array[] = downloadBuffers.current.get(id) || [];
      
      let lastTime = Date.now();
      let lastBytes = receivedLength;

      setDownloads(prev => prev.map(d => d.id === id ? { 
        ...d, 
        status: 'downloading', 
        totalBytes: totalBytes || d.totalBytes,
        resumable: !!response.headers.get('accept-ranges') || response.status === 206
      } : d));

      const currentDownload = downloads.find(d => d.id === id); 
      updateNativeNotification(id, currentDownload?.filename || 'File', 0, 'Starting...', 'downloading');

      while (true) {
        const { done, value } = await reader.read();
        
        if (done) break;

        chunks.push(value);
        receivedLength += value.length;

        const now = Date.now();
        if (now - lastTime > 1000) {
          const speedBytes = (receivedLength - lastBytes) / ((now - lastTime) / 1000);
          const speedStr = formatSize(speedBytes) + '/s';
          const percent = totalBytes ? Math.round((receivedLength / totalBytes) * 100) : 0;

          setDownloads(prev => prev.map(d => d.id === id ? {
            ...d,
            receivedBytes: receivedLength,
            progress: percent,
            speed: speedStr,
            size: formatSize(receivedLength) + (totalBytes ? ` / ${formatSize(totalBytes)}` : '')
          } : d));

          const freshName = downloads.find(d => d.id === id)?.filename || 'File';
          updateNativeNotification(id, freshName, percent, speedStr, 'downloading');

          lastTime = now;
          lastBytes = receivedLength;
        }
      }

      downloadBuffers.current.set(id, chunks); 
      // Important: Provide correct MIME type
      const blob = new Blob(chunks, { type: contentType });
      const blobUrl = URL.createObjectURL(blob);
      
      const link = document.createElement('a');
      link.href = blobUrl;
      const downloadItem = downloads.find(d => d.id === id); 
      const finalName = downloadItem?.filename || 'download';
      link.download = finalName;
      document.body.appendChild(link);
      
      setTimeout(() => {
          link.click();
          document.body.removeChild(link);
          setTimeout(() => URL.revokeObjectURL(blobUrl), 10000);
      }, 100);

      setDownloads(prev => prev.map(d => d.id === id ? {
        ...d,
        status: 'completed',
        progress: 100,
        speed: 'Done',
        size: formatSize(receivedLength)
      } : d));

      notify("Download Complete", "File saved to Dragon folder.");
      updateNativeNotification(id, finalName, 100, 'Done', 'completed');
      
      downloadBuffers.current.delete(id);
      downloadControllers.current.delete(id);
      
      processQueue();

    } catch (error: any) {
      if (error.name === 'AbortError') {
        // Handled by paused state
      } else {
        console.error("Download failed", error);
        setDownloads(prev => prev.map(d => d.id === id ? { ...d, status: 'failed' } : d));
        notify("Download Failed", "Network interruption detected.");
        updateNativeNotification(id, 'File', 0, 'Failed', 'failed');
        setTimeout(() => processQueue(), 500);
      }
    }
  };

  const addDownload = useCallback((url: string, filename: string) => {
    const id = Math.random().toString(36).substr(2, 9);
    const newDownload: DownloadItem = {
      id,
      filename,
      url,
      size: 'Queued...',
      totalBytes: 0,
      receivedBytes: 0,
      speed: 'Waiting',
      type: getFileType(filename),
      timestamp: Date.now(),
      progress: 0,
      status: 'queued', 
      resumable: true,
      priority: 'normal',
      queueIndex: Date.now()
    };

    setDownloads(prev => {
        const next = [newDownload, ...prev];
        setTimeout(() => processQueue(), 100); 
        return next;
    });
    
    downloadBuffers.current.set(id, []); 
    notify("Download Queued", filename);
  }, [processQueue]);

  const pauseDownload = useCallback((id: string) => {
    const controller = downloadControllers.current.get(id);
    if (controller) {
      controller.abort();
      setDownloads(prev => prev.map(d => {
        if (d.id === id) {
           const newItem = { ...d, status: 'paused' as const, speed: 'Paused' };
           updateNativeNotification(id, d.filename, d.progress, 'Paused', 'paused');
           return newItem;
        }
        return d;
      }));
      setTimeout(() => processQueue(), 50);
    }
  }, [processQueue]);

  const resumeDownload = useCallback((id: string) => {
    setDownloads(prev => {
        const updated = prev.map(d => d.id === id ? { ...d, status: 'queued', speed: 'Waiting...' } : d);
        setTimeout(() => processQueue(), 50);
        return updated as DownloadItem[];
    });
  }, [processQueue]);

  const cancelDownload = useCallback(async (id: string) => {
    const controller = downloadControllers.current.get(id);
    if (controller) {
      controller.abort();
    }
    downloadBuffers.current.delete(id);
    downloadControllers.current.delete(id);
    setDownloads(prev => prev.map(d => d.id === id ? { ...d, status: 'canceled', speed: '-' } : d));
    
    try {
      const notifId = getNotificationId(id);
      await LocalNotifications.cancel({ notifications: [{ id: notifId }] });
    } catch (e) {}

    setTimeout(() => processQueue(), 50);
  }, [processQueue]);

  const removeDownload = useCallback((id: string) => {
    cancelDownload(id);
    setDownloads(prev => prev.filter(d => d.id !== id));
    setTimeout(() => processQueue(), 50);
  }, [cancelDownload, processQueue]);

  const updateDownloadPriority = useCallback((id: string, priority: DownloadPriority) => {
    setDownloads(prev => prev.map(d => d.id === id ? { ...d, priority } : d));
    setTimeout(() => processQueue(), 50);
  }, [processQueue]);

  const moveDownloadOrder = useCallback((id: string, direction: 'up' | 'down') => {
    setDownloads(prev => {
      const items = [...prev];
      const index = items.findIndex(d => d.id === id);
      if (index === -1) return prev;
      
      const item = items[index];
      const activeQueue = items.filter(d => d.status === 'queued' || d.status === 'downloading' || d.status === 'paused');
      
      activeQueue.sort((a, b) => a.queueIndex - b.queueIndex);
      
      const localIndex = activeQueue.findIndex(d => d.id === id);
      if (localIndex === -1) return prev;

      if (direction === 'up' && localIndex > 0) {
         const prevItem = activeQueue[localIndex - 1];
         const temp = item.queueIndex;
         item.queueIndex = prevItem.queueIndex;
         prevItem.queueIndex = temp;
      } else if (direction === 'down' && localIndex < activeQueue.length - 1) {
         const nextItem = activeQueue[localIndex + 1];
         const temp = item.queueIndex;
         item.queueIndex = nextItem.queueIndex;
         nextItem.queueIndex = temp;
      }
      
      setTimeout(() => processQueue(), 50);
      return [...items];
    });
  }, [processQueue]);

  // --- Other Methods ---
  const performBiometricCheck = useCallback(async (): Promise<boolean> => {
    try {
        // Simulate biometric verification delay
        await new Promise((resolve) => setTimeout(resolve, 800));
        // In a real environment, we would call NativeBiometric.verifyIdentity() here.
        // For this web preview, we return true to simulate a successful scan.
        return true; 
    } catch (e) { return false; }
  }, []);

  const addHistory = useCallback((item: Omit<HistoryItem, 'id' | 'timestamp'>) => {
    if (!settings.historyEnabled) return;
    setHistory(prev => {
      const filtered = prev.filter(h => h.url !== item.url);
      return [{ ...item, id: Math.random().toString(36).substr(2, 9), timestamp: Date.now() }, ...filtered.slice(0, 99)];
    });
  }, [settings.historyEnabled]);

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('dragon_history');
  };

  const updateSettings = (updates: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...updates }));
  };

  const addShortcut = (name: string, url: string) => {
    if (speedDial.length >= 8) return;
    setSpeedDial(prev => [...prev, { id: Math.random().toString(36).substr(2, 9), name, url, isProtected: false }]);
  };

  const removeShortcut = (id: string) => {
    setSpeedDial(prev => prev.filter(s => s.id !== id || s.isProtected));
  };

  const toggleBookmark = (url: string, title: string) => {
    setBookmarks(prev => {
      const exists = prev.find(b => b.url === url);
      if (exists) return prev.filter(b => b.url !== url);
      return [{ id: Math.random().toString(36).substr(2, 9), url, title, timestamp: Date.now() }, ...prev];
    });
  };

  const addNote = (content: string) => {
    if (!content.trim()) return;
    const newNote = { id: Date.now().toString(), text: content, date: new Date().toLocaleString() };
    setNotes(prev => [newNote, ...prev]);
  };

  const removeNote = (id: string) => {
    setNotes(prev => {
      const noteToMove = prev.find(n => n.id === id);
      if (noteToMove) setDeletedNotes(d => [noteToMove, ...d]);
      return prev.filter(n => n.id !== id);
    });
  };

  const recoverNote = (id: string) => {
    setDeletedNotes(prev => {
      const noteToRecover = prev.find(n => n.id === id);
      if (noteToRecover) setNotes(n => [noteToRecover, ...n]);
      return prev.filter(n => n.id !== id);
    });
  };

  const permanentlyDeleteNote = (id: string) => {
    setDeletedNotes(prev => prev.filter(n => n.id !== id));
  };

  const getSitePermissions = useCallback((url: string): SitePermissions => {
    try {
      const domain = new URL(url).hostname;
      return sitePermissionRegistry[domain] || DEFAULT_SITE_PERMISSIONS;
    } catch { return DEFAULT_SITE_PERMISSIONS; }
  }, [sitePermissionRegistry]);

  const updateSitePermissions = useCallback((url: string, updates: Partial<SitePermissions>) => {
    try {
      const domain = new URL(url).hostname;
      setSitePermissionRegistry(prev => ({
        ...prev,
        [domain]: { ...(prev[domain] || DEFAULT_SITE_PERMISSIONS), ...updates, lastModified: Date.now() }
      }));
    } catch {}
  }, []);

  const resetSitePermissions = useCallback((url: string) => {
    try {
      const domain = new URL(url).hostname;
      setSitePermissionRegistry(prev => {
        const { [domain]: removed, ...rest } = prev;
        return rest;
      });
    } catch {}
  }, []);

  // --- NEW: Tracker & Purge Logic ---
  const incrementTrackers = useCallback((count: number) => {
    setSettings(prev => ({
      ...prev,
      trackersBlockedTotal: (prev.trackersBlockedTotal || 0) + count
    }));
  }, []);

  const purgeAllData = useCallback(() => {
    setHistory([]);
    setBookmarks([]);
    setDownloads([]);
    setNotes([]);
    setDeletedNotes([]);
    setSitePermissionRegistry({});
    setSettings(prev => ({
      ...prev,
      trackersBlockedTotal: 0 // Reset stats
    }));
    // Also clear localStorage keys specifically handled by these states
    localStorage.removeItem('dragon_history');
    localStorage.removeItem('dragon_bookmarks');
    localStorage.removeItem('dragon_downloads');
    localStorage.removeItem('dragon_notes_library');
    localStorage.removeItem('dragon_notes_trash');
    localStorage.removeItem('dragon_site_permissions');
  }, []);

  return (
    <DragonContext.Provider value={{
      settings, updateSettings,
      history, addHistory, removeHistoryItem: (id) => setHistory(prev => prev.filter(h => h.id !== id)), clearHistory,
      bookmarks, toggleBookmark,
      downloads, addDownload, removeDownload, pauseDownload, resumeDownload, cancelDownload, 
      updateDownloadPriority, moveDownloadOrder,
      speedDial, addShortcut, removeShortcut, updateSpeedDial: setSpeedDial,
      notes, deletedNotes, addNote, removeNote, recoverNote, permanentlyDeleteNote, clearAllNotes: () => setNotes([]),
      viewMode, setViewMode,
      isIncognitoAuthenticated: true,
      authenticateTabLock: async () => true,
      setIncognitoLocked: (l) => updateSettings({ incognitoLockEnabled: l }),
      architect,
      incrementTrackers,
      purgeAllData,
      activeMedia, playMedia: (url, filename, type) => setActiveMedia({ url, filename, type }), closeMedia: () => setActiveMedia(null),
      isAppLocked, unlockApp: () => setIsAppLocked(false), lockApp: () => setIsAppLocked(true), performBiometricCheck,
      getSitePermissions, updateSitePermissions, resetSitePermissions,
      requestSystemPermission
    }}>
      {children}
    </DragonContext.Provider>
  );
};