
import React, { createContext, useContext, useState, useEffect, useCallback, useRef } from 'react';
import { AppSettings, HistoryItem, Bookmark, DownloadItem, BrowserViewMode, ActiveMedia, NoteItem, ToolbarConfig, SecurityConfig, SitePermissions, DownloadPriority, ImageContextData } from './types';
import { App as CapacitorApp } from '@capacitor/app';
import { LocalNotifications } from '@capacitor/local-notifications';

export interface Shortcut {
  id: string;
  name: string;
  url: string;
  isProtected?: boolean;
}

interface DragonContextType {
  settings: AppSettings;
  updateSettings: (updates: Partial<AppSettings>) => void;
  history: HistoryItem[];
  addHistory: (item: Omit<HistoryItem, 'id' | 'timestamp'>) => void;
  removeHistoryItem: (id: string) => void;
  clearHistory: () => void;
  bookmarks: Bookmark[];
  toggleBookmark: (url: string, title: string) => void;
  downloads: DownloadItem[];
  addDownload: (url: string, filename: string) => void;
  removeDownload: (id: string) => void;
  pauseDownload: (id: string) => void;
  resumeDownload: (id: string) => void;
  cancelDownload: (id: string) => void;
  updateDownloadPriority: (id: string, priority: DownloadPriority) => void;
  moveDownloadOrder: (id: string, direction: 'up' | 'down') => void;
  speedDial: Shortcut[];
  addShortcut: (name: string, url: string) => void;
  removeShortcut: (id: string) => void;
  updateSpeedDial: (shortcuts: Shortcut[]) => void;
  notes: NoteItem[];
  deletedNotes: NoteItem[];
  addNote: (content: string) => void;
  removeNote: (id: string) => void;
  recoverNote: (id: string) => void;
  permanentlyDeleteNote: (id: string) => void;
  clearAllNotes: () => void;
  viewMode: BrowserViewMode;
  setViewMode: (mode: BrowserViewMode) => void;
  notesEntrySource: 'menu' | 'pencil';
  setNotesEntrySource: (source: 'menu' | 'pencil') => void;
  isIncognitoAuthenticated: boolean;
  authenticateTabLock: () => Promise<boolean>;
  setIncognitoLocked: (locked: boolean) => void;
  architect: string;
  incrementTrackers: (count: number) => void;
  purgeAllData: () => void;
  activeMedia: ActiveMedia | null;
  playMedia: (url: string, filename: string, type: 'video' | 'audio' | 'image') => void;
  closeMedia: () => void;
  isAppLocked: boolean;
  unlockApp: () => void;
  lockApp: () => void;
  performBiometricCheck: () => Promise<boolean>;
  getSitePermissions: (url: string) => SitePermissions;
  updateSitePermissions: (url: string, permissions: Partial<SitePermissions>) => void;
  resetSitePermissions: (url: string) => void;
  sitePermissionRegistry: Record<string, SitePermissions>;
  imageContextMenuData: ImageContextData | null;
  openImageContextMenu: (url: string) => void;
  closeImageContextMenu: () => void;
}

const DragonContext = createContext<DragonContextType | undefined>(undefined);

export const useDragon = () => {
  const context = useContext(DragonContext);
  if (!context) throw new Error('useDragon must be used within a DragonProvider');
  return context;
};

const DEFAULT_SHORTCUTS: Shortcut[] = [
  { id: 'sd-1', name: 'Google', url: 'google.com', isProtected: true },
  { id: 'sd-2', name: 'YouTube', url: 'youtube.com', isProtected: true },
  { id: 'sd-3', name: 'Facebook', url: 'facebook.com', isProtected: true },
  { id: 'sd-4', name: 'Gemini', url: 'gemini.google.com', isProtected: true },
  { id: 'sd-5', name: 'Instagram', url: 'instagram.com', isProtected: true },
  { id: 'sd-6', name: 'Amazon', url: 'amazon.com', isProtected: false },
  { id: 'sd-7', name: 'ChatGPT', url: 'chatgpt.com', isProtected: false },
  { id: 'sd-8', name: 'Netflix', url: 'netflix.com', isProtected: false }
];

const DEFAULT_SITE_PERMISSIONS: SitePermissions = {
  javascript: true,
  cookies: true,
  location: true,
  camera: true,
  microphone: true,
  popups: false,
  lastModified: 0
};

export const DragonProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const architect = "Amudhan T";
  
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('dragon_settings');
    const defaultSettings: AppSettings = {
      adBlockEnabled: true, dragonBreath: true, stealthFlight: true, autoPurge: false,
      javaScriptEnabled: true, scaleCompression: false, isDesktopMode: false, searchEngine: 'dragon',
      themeMode: 'system', themeColor: 'ember', wallpaper: 'void', historyEnabled: true,
      doNotTrack: true, safeBrowsing: true, secureDns: true, incognitoLockEnabled: false,
      downloadLocation: '/Internal Storage/Downloads/Dragon', 
      muteDownloadNotifications: false, pipEnabled: true, floatingFeaturesEnabled: false,
      trackersBlockedTotal: 1542, sovereigntyMode: false, 
      toolbarConfig: { showLens: true, showTranslate: true, showMic: true, showNewTab: true, showNotes: true, showDesktopMode: true, showBookmark: true, showTabs: true },
      security: { appLockEnabled: false, pin: null, biometricsEnabled: false, lockTimeout: 30000 }
    };
    if (!saved) return defaultSettings;
    try { return { ...defaultSettings, ...JSON.parse(saved) }; } catch { return defaultSettings; }
  });

  const [history, setHistory] = useState<HistoryItem[]>(() => {
    try { const saved = localStorage.getItem('dragon_history'); return saved ? JSON.parse(saved) : []; } catch { return []; }
  });

  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => {
    try { const saved = localStorage.getItem('dragon_bookmarks'); return saved ? JSON.parse(saved) : []; } catch { return []; }
  });

  const [downloads, setDownloads] = useState<DownloadItem[]>(() => {
    try { const saved = localStorage.getItem('dragon_downloads'); return saved ? JSON.parse(saved) : []; } catch { return []; }
  });

  const [speedDial, setSpeedDial] = useState<Shortcut[]>(() => {
    try { const saved = localStorage.getItem('dragon_speed_dial'); return saved ? JSON.parse(saved) : DEFAULT_SHORTCUTS; } catch { return DEFAULT_SHORTCUTS; }
  });

  const [notes, setNotes] = useState<NoteItem[]>(() => {
    try { const saved = localStorage.getItem('dragon_notes_library'); return saved ? JSON.parse(saved) : []; } catch { return []; }
  });

  const [deletedNotes, setDeletedNotes] = useState<NoteItem[]>(() => {
    try { const saved = localStorage.getItem('dragon_deleted_notes'); return saved ? JSON.parse(saved) : []; } catch { return []; }
  });

  const [sitePermissionRegistry, setSitePermissionRegistry] = useState<Record<string, SitePermissions>>(() => {
    try { const saved = localStorage.getItem('dragon_site_permissions'); return saved ? JSON.parse(saved) : {}; } catch { return {}; }
  });

  const [viewMode, setViewMode] = useState<BrowserViewMode>(BrowserViewMode.BROWSER);
  const [notesEntrySource, setNotesEntrySource] = useState<'menu' | 'pencil'>('menu');
  const [activeMedia, setActiveMedia] = useState<ActiveMedia | null>(null);
  const [isAppLocked, setIsAppLocked] = useState<boolean>(() => settings.security?.appLockEnabled || false);
  const [imageContextMenuData, setImageContextMenuData] = useState<ImageContextData | null>(null);

  useEffect(() => { localStorage.setItem('dragon_settings', JSON.stringify(settings)); }, [settings]);
  useEffect(() => { localStorage.setItem('dragon_history', JSON.stringify(history)); }, [history]);
  useEffect(() => { localStorage.setItem('dragon_bookmarks', JSON.stringify(bookmarks)); }, [bookmarks]);
  useEffect(() => { localStorage.setItem('dragon_downloads', JSON.stringify(downloads)); }, [downloads]);
  useEffect(() => { localStorage.setItem('dragon_site_permissions', JSON.stringify(sitePermissionRegistry)); }, [sitePermissionRegistry]);
  useEffect(() => { localStorage.setItem('dragon_notes_library', JSON.stringify(notes)); }, [notes]);
  useEffect(() => { localStorage.setItem('dragon_deleted_notes', JSON.stringify(deletedNotes)); }, [deletedNotes]);

  const getSitePermissions = useCallback((url: string): SitePermissions => {
    if (!url || url === 'dragon://home') return DEFAULT_SITE_PERMISSIONS;
    try {
      const domain = new URL(url).hostname;
      return sitePermissionRegistry[domain] || DEFAULT_SITE_PERMISSIONS;
    } catch { return DEFAULT_SITE_PERMISSIONS; }
  }, [sitePermissionRegistry]);

  const updateSitePermissions = useCallback((url: string, updates: Partial<SitePermissions>) => {
    try {
      const domain = url.includes('://') ? new URL(url).hostname : url;
      setSitePermissionRegistry(prev => ({
        ...prev,
        [domain]: { ...(prev[domain] || DEFAULT_SITE_PERMISSIONS), ...updates, lastModified: Date.now() }
      }));
    } catch {}
  }, []);

  const resetSitePermissions = useCallback((url: string) => {
    try {
      const domain = url.includes('://') ? new URL(url).hostname : url;
      setSitePermissionRegistry(prev => {
        const { [domain]: removed, ...rest } = prev;
        return rest;
      });
    } catch {}
  }, []);

  const addHistory = useCallback((item: Omit<HistoryItem, 'id' | 'timestamp'>) => {
    if (!settings.historyEnabled) return;
    setHistory(prev => [{ ...item, id: Math.random().toString(36).substr(2, 9), timestamp: Date.now() }, ...prev.filter(h => h.url !== item.url).slice(0, 99)]);
  }, [settings.historyEnabled]);

  const updateSettings = (updates: Partial<AppSettings>) => setSettings(prev => ({ ...prev, ...updates }));

  const addNote = useCallback((content: string) => {
    const newNote: NoteItem = {
      id: Math.random().toString(36).substr(2, 9),
      text: content,
      date: new Date().toLocaleDateString(undefined, { month: 'short', day: 'numeric', year: 'numeric' })
    };
    setNotes(prev => [newNote, ...prev]);
  }, []);

  const removeNote = useCallback((id: string) => {
    setNotes(prev => {
      const noteToMove = prev.find(n => n.id === id);
      if (noteToMove) {
        setDeletedNotes(d => [noteToMove, ...d]);
      }
      return prev.filter(n => n.id !== id);
    });
  }, []);

  const recoverNote = useCallback((id: string) => {
    setDeletedNotes(prev => {
      const noteToRecover = prev.find(n => n.id === id);
      if (noteToRecover) {
        setNotes(n => [noteToRecover, ...n]);
      }
      return prev.filter(n => n.id !== id);
    });
  }, []);

  const permanentlyDeleteNote = useCallback((id: string) => {
    setDeletedNotes(prev => prev.filter(n => n.id !== id));
  }, []);

  return (
    <DragonContext.Provider value={{
      settings, updateSettings, history, addHistory, removeHistoryItem: (id) => setHistory(prev => prev.filter(h => h.id !== id)),
      clearHistory: () => setHistory([]), bookmarks, toggleBookmark: (url, title) => setBookmarks(prev => prev.find(b => b.url === url) ? prev.filter(b => b.url !== url) : [{ id: Math.random().toString(36).substr(2, 9), url, title, timestamp: Date.now() }, ...prev]),
      downloads, addDownload: (url, filename) => {}, removeDownload: (id) => {}, pauseDownload: (id) => {}, resumeDownload: (id) => {}, cancelDownload: (id) => {}, updateDownloadPriority: (id, p) => {}, moveDownloadOrder: (id, d) => {},
      speedDial, addShortcut: (n, u) => {}, removeShortcut: (id) => {}, updateSpeedDial: (s) => setSpeedDial(s),
      notes, deletedNotes, addNote, removeNote, recoverNote, permanentlyDeleteNote, clearAllNotes: () => setNotes([]),
      viewMode, setViewMode, notesEntrySource, setNotesEntrySource, isIncognitoAuthenticated: true, authenticateTabLock: async () => true, setIncognitoLocked: (l) => {}, architect, incrementTrackers: (c) => {}, 
      purgeAllData: () => { setHistory([]); setBookmarks([]); setDownloads([]); setNotes([]); setDeletedNotes([]); setSitePermissionRegistry({}); },
      activeMedia, playMedia: (url, filename, type) => setActiveMedia({ url, filename, type }), closeMedia: () => setActiveMedia(null),
      isAppLocked, unlockApp: () => setIsAppLocked(false), lockApp: () => setIsAppLocked(true), performBiometricCheck: async () => false,
      getSitePermissions, updateSitePermissions, resetSitePermissions, sitePermissionRegistry,
      imageContextMenuData, openImageContextMenu: (url) => setImageContextMenuData({ url }), closeImageContextMenu: () => setImageContextMenuData(null)
    }}>
      {children}
    </DragonContext.Provider>
  );
};
