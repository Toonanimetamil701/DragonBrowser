
import React, { createContext, useContext, useState, useEffect, useCallback } from 'react';
import { AppSettings, HistoryItem, Bookmark, DownloadItem, BrowserViewMode, ActiveMedia, NoteItem, ToolbarConfig } from './types';

export interface Shortcut {
  id: string;
  name: string;
  url: string;
  isProtected?: boolean;
}

interface DragonContextType {
  settings: AppSettings;
  updateSettings: (updates: Partial<AppSettings>) => void;
  history: HistoryItem[];
  addHistory: (item: Omit<HistoryItem, 'id' | 'timestamp'>) => void;
  removeHistoryItem: (id: string) => void;
  clearHistory: () => void;
  bookmarks: Bookmark[];
  toggleBookmark: (url: string, title: string) => void;
  downloads: DownloadItem[];
  addDownload: (url: string, filename: string) => void;
  removeDownload: (id: string) => void;
  speedDial: Shortcut[];
  addShortcut: (name: string, url: string) => void;
  removeShortcut: (id: string) => void;
  updateSpeedDial: (shortcuts: Shortcut[]) => void;
  notes: NoteItem[];
  deletedNotes: NoteItem[];
  addNote: (content: string) => void;
  removeNote: (id: string) => void;
  recoverNote: (id: string) => void;
  permanentlyDeleteNote: (id: string) => void;
  clearAllNotes: () => void;
  viewMode: BrowserViewMode;
  setViewMode: (mode: BrowserViewMode) => void;
  isIncognitoAuthenticated: boolean;
  authenticateTabLock: () => Promise<boolean>;
  setIncognitoLocked: (locked: boolean) => void;
  architect: string;
  incrementTrackers: (count: number) => void;
  purgeAllData: () => void;
  activeMedia: ActiveMedia | null;
  playMedia: (url: string, filename: string, type: 'video' | 'audio' | 'image') => void;
  closeMedia: () => void;
}

const DragonContext = createContext<DragonContextType | undefined>(undefined);

const DEFAULT_SHORTCUTS: Shortcut[] = [
  { id: 'sd-1', name: 'Google', url: 'google.com', isProtected: true },
  { id: 'sd-2', name: 'YouTube', url: 'youtube.com', isProtected: true },
  { id: 'sd-3', name: 'Facebook', url: 'facebook.com', isProtected: true },
  { id: 'sd-4', name: 'Gemini', url: 'gemini.google.com', isProtected: true },
  { id: 'sd-5', name: 'Instagram', url: 'instagram.com', isProtected: true },
  { id: 'sd-6', name: 'Amazon', url: 'amazon.com', isProtected: false },
  { id: 'sd-7', name: 'ChatGPT', url: 'chatgpt.com', isProtected: false },
  { id: 'sd-8', name: 'Netflix', url: 'netflix.com', isProtected: false }
];

export const DragonProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const architect = "Amudhan T";
  
  const [settings, setSettings] = useState<AppSettings>(() => {
    const saved = localStorage.getItem('dragon_settings');
    const defaultSettings: AppSettings = {
      adBlockEnabled: true, dragonBreath: true, stealthFlight: true, autoPurge: false,
      scaleCompression: false, searchEngine: 'dragon', dragonStrength: false,
      themeMode: 'dark', themeColor: 'ember', wallpaper: 'void', historyEnabled: true,
      doNotTrack: true, safeBrowsing: true, secureDns: true, incognitoLockEnabled: false,
      downloadLocation: '/Internal Storage/Downloads/Dragon', trackersBlockedTotal: 1542,
      sovereigntyMode: false, toolbarConfig: {
        showDesktop: true, showFind: true, showTranslate: true, showMic: true, showNewTab: true, showNotes: true
      }
    };
    if (!saved) return defaultSettings;
    try {
      const parsed = JSON.parse(saved);
      // Merge with defaultToolbarConfig to ensure new keys exist
      return {
        ...parsed,
        toolbarConfig: { ...defaultSettings.toolbarConfig, ...(parsed.toolbarConfig || {}) }
      };
    } catch {
      return defaultSettings;
    }
  });

  const [history, setHistory] = useState<HistoryItem[]>(() => {
    const saved = localStorage.getItem('dragon_history');
    try {
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [bookmarks, setBookmarks] = useState<Bookmark[]>(() => {
    const saved = localStorage.getItem('dragon_bookmarks');
    try {
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [downloads, setDownloads] = useState<DownloadItem[]>(() => {
    const saved = localStorage.getItem('dragon_downloads');
    try {
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [speedDial, setSpeedDial] = useState<Shortcut[]>(() => {
    const saved = localStorage.getItem('dragon_speed_dial');
    if (!saved) return DEFAULT_SHORTCUTS;
    try {
      const parsed = JSON.parse(saved);
      const protectedOnes = DEFAULT_SHORTCUTS.filter(s => s.isProtected);
      const userItems = parsed.filter((p: Shortcut) => !protectedOnes.some(pr => pr.url === p.url));
      return [...protectedOnes, ...userItems].slice(0, 8);
    } catch {
      return DEFAULT_SHORTCUTS;
    }
  });

  // Notes Engine State
  const [notes, setNotes] = useState<NoteItem[]>(() => {
    const saved = localStorage.getItem('dragon_notes_library');
    try {
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [deletedNotes, setDeletedNotes] = useState<NoteItem[]>(() => {
    const saved = localStorage.getItem('dragon_notes_trash');
    try {
      return saved ? JSON.parse(saved) : [];
    } catch {
      return [];
    }
  });

  const [viewMode, setViewMode] = useState<BrowserViewMode>(BrowserViewMode.BROWSER);
  const [activeMedia, setActiveMedia] = useState<ActiveMedia | null>(null);

  // Persistence Effects
  useEffect(() => { localStorage.setItem('dragon_settings', JSON.stringify(settings)); }, [settings]);
  useEffect(() => { localStorage.setItem('dragon_speed_dial', JSON.stringify(speedDial)); }, [speedDial]);
  useEffect(() => { localStorage.setItem('dragon_history', JSON.stringify(history)); }, [history]);
  useEffect(() => { localStorage.setItem('dragon_bookmarks', JSON.stringify(bookmarks)); }, [bookmarks]);
  useEffect(() => { localStorage.setItem('dragon_notes_library', JSON.stringify(notes)); }, [notes]);
  useEffect(() => { localStorage.setItem('dragon_notes_trash', JSON.stringify(deletedNotes)); }, [deletedNotes]);
  useEffect(() => { localStorage.setItem('dragon_downloads', JSON.stringify(downloads)); }, [downloads]);

  const addHistory = useCallback((item: Omit<HistoryItem, 'id' | 'timestamp'>) => {
    if (!settings.historyEnabled) return;
    setHistory(prev => {
      const filtered = prev.filter(h => h.url !== item.url);
      return [{ ...item, id: Math.random().toString(36).substr(2, 9), timestamp: Date.now() }, ...filtered.slice(0, 99)];
    });
  }, [settings.historyEnabled]);

  const clearHistory = () => {
    setHistory([]);
    localStorage.removeItem('dragon_history');
  };

  const updateSettings = (updates: Partial<AppSettings>) => {
    setSettings(prev => ({ ...prev, ...updates }));
  };

  const addShortcut = (name: string, url: string) => {
    if (speedDial.length >= 8) return;
    setSpeedDial(prev => [...prev, { id: Math.random().toString(36).substr(2, 9), name, url, isProtected: false }]);
  };

  const removeShortcut = (id: string) => {
    setSpeedDial(prev => prev.filter(s => s.id !== id || s.isProtected));
  };

  const toggleBookmark = (url: string, title: string) => {
    setBookmarks(prev => {
      const exists = prev.find(b => b.url === url);
      if (exists) return prev.filter(b => b.url !== url);
      return [{ id: Math.random().toString(36).substr(2, 9), url, title, timestamp: Date.now() }, ...prev];
    });
  };

  // Notes Management Functions
  const addNote = (content: string) => {
    if (!content.trim()) return;
    const newNote = { id: Date.now().toString(), text: content, date: new Date().toLocaleString() };
    setNotes(prev => [newNote, ...prev]);
  };

  const removeNote = (id: string) => {
    setNotes(prev => {
      const noteToMove = prev.find(n => n.id === id);
      if (noteToMove) setDeletedNotes(d => [noteToMove, ...d]);
      return prev.filter(n => n.id !== id);
    });
  };

  const recoverNote = (id: string) => {
    setDeletedNotes(prev => {
      const noteToRecover = prev.find(n => n.id === id);
      if (noteToRecover) setNotes(n => [noteToRecover, ...n]);
      return prev.filter(n => n.id !== id);
    });
  };

  const permanentlyDeleteNote = (id: string) => {
    setDeletedNotes(prev => prev.filter(n => n.id !== id));
  };

  return (
    <DragonContext.Provider value={{
      settings, updateSettings,
      history, addHistory, removeHistoryItem: (id) => setHistory(prev => prev.filter(h => h.id !== id)), clearHistory,
      bookmarks, toggleBookmark,
      downloads, addDownload: (url, filename) => {}, removeDownload: (id) => {},
      speedDial, addShortcut, removeShortcut, updateSpeedDial: setSpeedDial,
      notes, deletedNotes, addNote, removeNote, recoverNote, permanentlyDeleteNote, clearAllNotes: () => setNotes([]),
      viewMode, setViewMode,
      isIncognitoAuthenticated: true,
      authenticateTabLock: async () => true,
      setIncognitoLocked: (l) => updateSettings({ incognitoLockEnabled: l }),
      architect,
      incrementTrackers: (c) => {},
      purgeAllData: () => { setHistory([]); setBookmarks([]); setDownloads([]); setNotes([]); setDeletedNotes([]); },
      activeMedia, playMedia: (url, filename, type) => setActiveMedia({ url, filename, type }), closeMedia: () => setActiveMedia(null)
    }}>
      {children}
    </DragonContext.Provider>
  );
};

export const useDragon = () => {
  const context = useContext(DragonContext);
  if (!context) throw new Error('useDragon must be used within DragonProvider');
  return context;
};
