
import React, { useRef, useState, useEffect, useCallback } from 'react';
import { RefreshCw, ExternalLink, ArrowRightLeft, Monitor } from 'lucide-react';
import { Tab } from '../types';
import { useDragon } from '../DragonContext';
import { Capacitor } from '@capacitor/core';
import { enforceSovereignProtocol, DESKTOP_USER_AGENT } from '../utils/urlUtils';

const DragonWebView = React.forwardRef<HTMLIFrameElement, any>(({ pullToRefreshEnabled, refreshControlColor, style, ...props }, ref) => (
  <iframe
    ref={ref}
    style={style}
    {...props}
    data-pull-refresh={pullToRefreshEnabled}
    data-refresh-color={refreshControlColor}
  />
));

interface BrowserViewportProps {
  activeTab: Tab;
  onLoadStart: () => void;
  onLoadEnd: () => void;
  isDragonBreath: boolean;
  isDesktopMode: boolean;
  accentColor: string;
  onReload: () => void;
  refreshTrigger?: number;
}

export const BrowserViewport: React.FC<BrowserViewportProps> = ({ 
  activeTab, 
  onLoadStart, 
  onLoadEnd,
  isDragonBreath,
  isDesktopMode,
  accentColor,
  onReload,
  refreshTrigger = 0
}) => {
  const { settings } = useDragon();
  const containerRef = useRef<HTMLDivElement>(null);
  const [loadError, setLoadError] = useState(false);
  const [viewportKey, setViewportKey] = useState(0);
  const [desktopLockActive, setDesktopLockActive] = useState(false);
  const [redirectActive, setRedirectActive] = useState(false);
  
  const [startY, setStartY] = useState(0);
  const [pullDistance, setPullDistance] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const PULL_THRESHOLD = 120;

  const isNative = Capacitor.isNativePlatform();
  const effectiveUrl = enforceSovereignProtocol(activeTab.url);
  const wasRedirected = effectiveUrl !== activeTab.url;
  
  const isHighFidelityNode = (url: string) => {
    const nodes = [
      'youtube.com', 'youtu.be', 'facebook.com', 'amazon.com',
      'github.com', 'gemini.google.com', 'netflix.com', 
      'jiostar.com', 'primevideo.com', 'twitch.tv'
    ];
    return nodes.some(domain => url.includes(domain));
  };

  const forceDesktop = isHighFidelityNode(effectiveUrl) || settings.dragonStrength;

  // Determine current theme mode for website injection
  const isDark = settings.themeMode === 'dark' || (settings.themeMode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);

  useEffect(() => {
    if (refreshTrigger > 0) {
      setViewportKey(prev => prev + 1);
    }
  }, [refreshTrigger]);

  useEffect(() => {
    setLoadError(false);
    setIsRefreshing(false);
    setPullDistance(0);
    setDesktopLockActive(false);
    setRedirectActive(false);
    
    if (wasRedirected) {
      setRedirectActive(true);
    }

    if (forceDesktop) {
      setDesktopLockActive(true);
    }
  }, [effectiveUrl, forceDesktop, wasRedirected, activeTab.url]);

  const handleRefresh = useCallback(() => {
    setLoadError(false);
    setViewportKey(prev => prev + 1);
    onReload();
  }, [onReload]);

  const onTouchStart = (e: React.TouchEvent) => {
    if (isRefreshing) return;
    if (containerRef.current && containerRef.current.scrollTop === 0) {
      setStartY(e.touches[0].pageY);
    }
  };

  const onTouchMove = (e: React.TouchEvent) => {
    if (isRefreshing || startY === 0) return;
    const currentY = e.touches[0].pageY;
    const diff = currentY - startY;
    if (diff > 0 && (!containerRef.current || containerRef.current.scrollTop === 0)) {
       const dampenedDiff = Math.min(diff * 0.5, PULL_THRESHOLD + 60);
       setPullDistance(dampenedDiff);
    }
  };

  const onTouchEnd = () => {
    if (isRefreshing) return;
    if (pullDistance >= PULL_THRESHOLD) {
      setIsRefreshing(true);
      setPullDistance(PULL_THRESHOLD);
      setTimeout(() => {
        handleRefresh();
      }, 500);
    } else {
      setPullDistance(0);
    }
    setStartY(0);
  };

  const onIframeLoad = () => {
    setLoadError(false);
    onLoadEnd();
  };

  if (activeTab.url === 'dragon://home') return null;

  const getViewportStyles = () => {
    const baseStyles: React.CSSProperties = { 
      width: '100%', 
      height: '100%', 
      backgroundColor: isDark ? '#000' : '#fff',
      colorScheme: isDark ? 'dark' : 'light' 
    };

    if (forceDesktop) {
      return {
        ...baseStyles,
        width: '1280px',
        height: 'calc(100% / 0.3125)',
        transform: 'scale(0.3125)',
        transformOrigin: 'top left',
      };
    }
    return baseStyles;
  };

  return (
    <div 
      ref={containerRef}
      className="w-full h-full relative bg-white dark:bg-black overflow-hidden flex flex-col transition-colors duration-300"
      onTouchStart={onTouchStart}
      onTouchMove={onTouchMove}
      onTouchEnd={onTouchEnd}
    >
      <div 
        className="absolute top-0 left-0 w-full flex items-center justify-center z-50 pointer-events-none transition-all duration-300 ease-out"
        style={{ 
          transform: `translateY(${pullDistance - 60}px)`, 
          opacity: Math.min(pullDistance / (PULL_THRESHOLD * 0.8), 1) 
        }}
      >
        <div className="bg-white dark:bg-dragon-navy border border-slate-200 dark:border-dragon-ember/30 p-3 rounded-full shadow-xl">
          <RefreshCw 
            size={24} 
            color="#F97316"
            className={`${isRefreshing ? 'animate-spin' : ''}`} 
            style={{ transform: isRefreshing ? undefined : `rotate(${pullDistance * 3}deg)` }}
          />
        </div>
      </div>
      
      <div className="absolute bottom-6 right-6 z-40 flex flex-col items-end gap-2 pointer-events-none">
        
        {redirectActive && !activeTab.isLoading && (
          <div className="animate-fade-in">
             <div className="bg-black/80 backdrop-blur-xl border border-blue-500/30 rounded-full px-3 py-1.5 flex items-center gap-2 shadow-2xl">
                <ArrowRightLeft size={12} className="text-blue-400" />
                <div className="flex flex-col leading-none">
                  <span className="text-[8px] font-black text-white uppercase tracking-widest">Mobile Redirect</span>
                </div>
             </div>
          </div>
        )}

        {desktopLockActive && !activeTab.isLoading && (
           <div className="animate-fade-in">
              <div className="bg-dragon-navy/90 backdrop-blur-xl border border-dragon-cyan/30 rounded-full px-3 py-1.5 flex items-center gap-2 shadow-[0_0_15px_rgba(6,182,212,0.2)]">
                 <Monitor size={12} className="text-dragon-cyan" />
                 <div className="flex flex-col leading-none">
                    <span className="text-[9px] font-black text-white uppercase tracking-widest">DESKTOP LOCK</span>
                 </div>
              </div>
           </div>
        )}
      </div>
      
      <div 
        key={`${effectiveUrl}-${viewportKey}`}
        className="flex-1 w-full h-full relative overflow-auto no-scrollbar"
        style={{ 
          transform: `translateY(${isRefreshing ? pullDistance / 2 : 0}px)`,
          transition: isRefreshing ? 'none' : 'transform 0.4s cubic-bezier(0.19, 1, 0.22, 1)'
        }}
      >
        <DragonWebView
          src={effectiveUrl}
          style={getViewportStyles()}
          className="border-none block transition-colors duration-300"
          allow="accelerometer; autoplay; clipboard-read; clipboard-write; encrypted-media; gyroscope; picture-in-picture; web-share; fullscreen; camera; microphone; geolocation"
          onLoad={onIframeLoad}
          onError={() => setLoadError(true)}
          title={activeTab.title}
          pullToRefreshEnabled={true}
          refreshControlColor="#F97316"
        />
      </div>
    </div>
  );
};
