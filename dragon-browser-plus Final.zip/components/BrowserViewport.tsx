
import React, { useRef, useEffect, useState, useImperativeHandle, forwardRef } from 'react';
import { Tab } from '../types';
import { useDragon } from '../DragonContext';

interface BrowserViewportProps {
  activeTab: Tab;
  onLoadStart: () => void;
  onLoadEnd: () => void;
  isDragonBreath: boolean;
  isDesktopMode?: boolean;
  javaScriptEnabled?: boolean;
  accentColor: string;
  onReload: () => void;
  refreshTrigger?: number;
  onInternalNavigate?: (url: string) => void;
}

export interface BrowserViewportHandle {
  goBack: () => boolean;
  canGoBack: () => boolean;
}

export const BrowserViewport = forwardRef<BrowserViewportHandle, BrowserViewportProps>(({ 
  activeTab, 
  onLoadEnd,
  isDesktopMode,
  javaScriptEnabled = true,
  refreshTrigger,
  onInternalNavigate
}, ref) => {
  const { getSitePermissions, settings } = useDragon();
  const iframeRef = useRef<HTMLIFrameElement>(null);
  const [viewportWidth, setViewportWidth] = useState(window.innerWidth);

  useImperativeHandle(ref, () => ({
    goBack: () => {
      if (iframeRef.current?.contentWindow) {
        try {
          iframeRef.current.contentWindow.history.back();
          return true;
        } catch (e) { return false; }
      }
      return false;
    },
    canGoBack: () => true
  }));

  useEffect(() => {
    const handleResize = () => setViewportWidth(window.innerWidth);
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);
  
  const handleLoad = () => {
    onLoadEnd();
    
    // NAVIGATION BRIDGE: Detect actual URL of the WebView
    try {
       const currentUrl = iframeRef.current?.contentWindow?.location.href;
       if (currentUrl && currentUrl !== 'about:blank' && onInternalNavigate) {
          onInternalNavigate(currentUrl);
       }
    } catch (e) {
       // Cross-origin prevents reading URL
    }
  };

  if (activeTab.url === 'dragon://home') return null;

  const sitePerms = getSitePermissions(activeTab.url);
  const sandboxRules = [
    "allow-forms", "allow-presentation", "allow-downloads", "allow-modals",
    "allow-orientation-lock", "allow-pointer-lock", "allow-top-navigation",
    "allow-top-navigation-by-user-activation"
  ];

  if (javaScriptEnabled && sitePerms.javascript) sandboxRules.push("allow-scripts");
  if (sitePerms.cookies) sandboxRules.push("allow-same-origin");
  if (sitePerms.popups) {
    sandboxRules.push("allow-popups");
    sandboxRules.push("allow-popups-to-escape-sandbox");
  }

  const allowFeatures = [
    "accelerometer", "autoplay", "clipboard-write", "encrypted-media", "gyroscope", "fullscreen"
  ];
  if (sitePerms.camera) allowFeatures.push("camera");
  if (sitePerms.microphone) allowFeatures.push("microphone");
  if (sitePerms.location) allowFeatures.push("geolocation");
  if (settings.pipEnabled) allowFeatures.push("picture-in-picture");

  const desktopTargetWidth = 1280;
  const scale = isDesktopMode ? viewportWidth / desktopTargetWidth : 1;

  // THEME SYNC LOGIC FOR WEBSITES
  const getIframeColorScheme = () => {
    if (settings.themeMode === 'dark') return 'dark';
    if (settings.themeMode === 'light') return 'light';
    // If system, check if current runtime preference is dark
    return window.matchMedia('(prefers-color-scheme: dark)').matches ? 'dark' : 'light';
  };

  return (
    <div className="w-full h-full bg-white dark:bg-black relative overflow-hidden transition-colors duration-300" style={{ isolation: 'isolate' }}>
       <iframe
          ref={iframeRef}
          src={activeTab.url}
          className={`border-none bg-white block absolute top-0 left-0 transition-all duration-300 w-full h-full ${isDesktopMode ? 'origin-top-left' : ''}`}
          title={activeTab.title}
          sandbox={sandboxRules.join(' ')}
          allow={allowFeatures.join('; ')}
          loading="eager"
          onLoad={handleLoad}
          onError={handleLoad}
          key={`viewport-${activeTab.id}-${refreshTrigger}-${isDesktopMode}-${javaScriptEnabled}-${JSON.stringify(sitePerms)}-${settings.themeMode}`}
          style={{
             colorScheme: getIframeColorScheme(),
             touchAction: 'auto',
             width: isDesktopMode ? `${desktopTargetWidth}px` : '100%',
             height: isDesktopMode ? `${(1 / scale) * 100}%` : '100%',
             transform: isDesktopMode ? `scale(${scale})` : 'none'
          }}
        />
    </div>
  );
});

BrowserViewport.displayName = 'BrowserViewport';
