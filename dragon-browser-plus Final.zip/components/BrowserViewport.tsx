
import React, { useEffect } from 'react';
import { ExternalLink, Shield, RotateCw } from 'lucide-react';
import { Tab } from '../types';
import { useDragonEngine } from '../services/BrowserEngine';

interface BrowserViewportProps {
  activeTab: Tab;
  onLoadStart: () => void;
  onLoadEnd: () => void;
  isDragonBreath: boolean;
  isDesktopMode: boolean;
  accentColor: string;
  onReload: () => void;
  refreshTrigger?: number;
}

export const BrowserViewport: React.FC<BrowserViewportProps> = ({ 
  activeTab, 
  onLoadEnd,
  isDesktopMode,
  accentColor
}) => {
  const engine = useDragonEngine();

  // Automatically clear loading state as we hand off to native browser
  useEffect(() => {
    const timer = setTimeout(() => {
      onLoadEnd();
    }, 500);
    return () => clearTimeout(timer);
  }, [activeTab.url, onLoadEnd]);

  const handleRelaunch = () => {
    engine.open(activeTab.url, {
      themeColor: accentColor,
      isPrivate: activeTab.isPrivate,
      searchEngine: 'google',
      isDesktopMode: isDesktopMode
    });
  };

  if (activeTab.url === 'dragon://home') return null;

  return (
    <div className="w-full h-full flex flex-col items-center justify-center bg-slate-50 dark:bg-black p-8 text-center space-y-8 animate-fade-in">
      <div className="relative group">
        <div className="absolute -inset-6 bg-gradient-to-r from-orange-500 to-red-500 rounded-full blur-xl opacity-20 group-hover:opacity-30 transition-opacity animate-pulse" />
        <div className="relative w-24 h-24 bg-white dark:bg-dragon-navy rounded-[2rem] shadow-2xl flex items-center justify-center border border-white/10">
          <img 
            src={`https://www.google.com/s2/favicons?sz=128&domain=${new URL(activeTab.url).hostname}`}
            className="w-12 h-12 object-contain"
            alt="Site Icon"
            onError={(e) => { 
              e.currentTarget.style.display = 'none';
            }}
          />
        </div>
      </div>
      
      <div className="space-y-3 max-w-md">
        <h2 className="text-2xl font-black text-slate-900 dark:text-white tracking-tight truncate">
          {activeTab.title || 'Dragon Engine'}
        </h2>
        <p className="text-sm text-slate-500 font-mono break-all opacity-70">
          {activeTab.url}
        </p>
      </div>

      <div className="p-5 bg-white dark:bg-white/5 rounded-3xl border border-slate-200 dark:border-white/5 max-w-xs w-full shadow-lg">
         <div className="flex items-center gap-3 mb-3 pb-3 border-b border-slate-100 dark:border-white/5">
            <Shield className="w-4 h-4 text-orange-500" />
            <span className="text-xs font-black uppercase text-slate-700 dark:text-slate-300 tracking-widest">Native Core Active</span>
         </div>
         <p className="text-[10px] text-slate-500 leading-relaxed text-left font-medium">
           This node is currently active in the Dragon Native Engine to ensure maximum performance and bypass restrictions.
         </p>
      </div>

      <button 
        onClick={handleRelaunch}
        className="px-8 py-4 bg-dragon-ember hover:bg-orange-600 text-white rounded-2xl font-black uppercase tracking-widest text-xs flex items-center gap-3 shadow-xl shadow-orange-500/20 active:scale-95 transition-all"
      >
        <ExternalLink size={16} />
        Open Interface
      </button>
    </div>
  );
};
