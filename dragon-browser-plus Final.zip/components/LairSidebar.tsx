
import React, { useState } from 'react';
import { 
  X, Book, FileText, Calculator, Palette, Trash2, 
  ShieldCheck, Monitor, Search, Ghost, Globe, Clock, 
  Download, Star, Sparkles, Plus, ExternalLink, Copy, Library
} from 'lucide-react';
import { ThemeColor, AppSettings, SearchEngine, BrowserViewMode } from '../types';
import { useDragon } from '../DragonContext';

interface LairSidebarProps {
  isOpen: boolean;
  onClose: () => void;
  currentTheme: ThemeColor;
  onThemeChange: (theme: ThemeColor) => void;
  settings: AppSettings;
  onToggleSetting: (key: keyof AppSettings) => void;
  onEngineChange: (engine: SearchEngine) => void;
  shieldStats: number;
}

export const LairSidebar: React.FC<LairSidebarProps> = ({ 
  isOpen, onClose, currentTheme, onThemeChange, settings, onToggleSetting, onEngineChange, shieldStats
}) => {
  const { setViewMode, notes, addNote, removeNote, bookmarks, toggleBookmark } = useDragon();
  const [activeTab, setActiveTab] = useState<'notes' | 'bookmarks' | 'theme' | 'shield'>('theme');
  const [currentNote, setCurrentNote] = useState("");

  const handleSaveNote = () => {
    if (currentNote.trim()) {
      addNote(currentNote);
      setCurrentNote("");
      alert("Note Saved to Library");
    }
  };

  const handleCopyQuickNote = () => {
    if (currentNote.trim()) {
      navigator.clipboard.writeText(currentNote);
      alert("Copied to clipboard.");
    }
  };

  const themes: { id: ThemeColor; name: string; color: string }[] = [
    { id: 'ember', name: 'Ember', color: '#f97316' },
    { id: 'frost', name: 'Frost', color: '#06b6d4' },
    { id: 'midas', name: 'Midas', color: '#eab308' },
    { id: 'venom', name: 'Venom', color: '#22c55e' },
  ];

  const navigateTo = (mode: BrowserViewMode) => {
    setViewMode(mode);
    onClose();
  };

  return (
    <>
      {isOpen && (
        <div className="fixed inset-0 bg-black/80 backdrop-blur-md z-[70]" onClick={onClose} />
      )}

      <div className={`
        fixed top-0 right-0 h-full w-85 max-w-[85vw] bg-dragon-dark/95 border-l border-white/10 shadow-2xl z-[80] transform transition-transform duration-500 ease-out flex flex-col backdrop-blur-3xl
        ${isOpen ? 'translate-x-0' : 'translate-x-full'}
      `}>
        <div className="p-8 border-b border-white/5 flex items-center justify-between bg-black/40">
          <div className="flex items-center gap-4">
             <img src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" className="w-10 h-10 object-contain drop-shadow-[0_0_10px_rgba(249,115,22,0.3)] rounded-full" />
             <div>
                <h2 className="text-xl font-black text-white tracking-tight italic text-dragon-ember uppercase leading-none">The Lair</h2>
                <p className="text-[10px] text-slate-500 uppercase font-bold tracking-[0.2em] mt-1">Architect Tools</p>
             </div>
          </div>
          <button onClick={onClose} className="p-3 bg-white/5 hover:bg-white/10 rounded-2xl text-slate-400 transition-all active:scale-90">
            <X className="w-5 h-5" />
          </button>
        </div>

        {/* Tab Selection */}
        <div className="flex p-3 gap-2 bg-black/20 overflow-x-auto no-scrollbar">
          {[
            { id: 'theme', icon: <Palette className="w-4 h-4" />, label: 'Style' },
            { id: 'notes', icon: <FileText className="w-4 h-4" />, label: 'Notes' },
            { id: 'bookmarks', icon: <Star className="w-4 h-4" />, label: 'Bookmarks' },
            { id: 'shield', icon: <ShieldCheck className="w-4 h-4" />, label: 'Shield' },
          ].map(tab => (
            <button
              key={tab.id}
              onClick={() => setActiveTab(tab.id as any)}
              className={`
                flex-1 flex flex-col items-center justify-center gap-1.5 py-4 px-3 rounded-2xl text-[9px] font-black transition-all whitespace-nowrap
                ${activeTab === tab.id 
                  ? 'bg-gradient-to-br from-[var(--theme-color)] to-dragon-dark text-white shadow-xl scale-105 ring-1 ring-white/20' 
                  : 'text-slate-500 hover:text-slate-300 hover:bg-white/5'}
              `}
            >
              {tab.icon}
              {tab.label.toUpperCase()}
            </button>
          ))}
        </div>

        <div className="flex-1 overflow-y-auto p-6 space-y-8 no-scrollbar">
          
          {activeTab === 'theme' && (
            <div className="space-y-8 animate-fade-in">
              <div className="space-y-4">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-l-2 border-dragon-ember pl-3">Essence Sync</h3>
                <div className="grid grid-cols-2 gap-4">
                  {themes.map(t => (
                    <button
                      key={t.id}
                      onClick={() => onThemeChange(t.id)}
                      className={`
                        relative p-5 rounded-[2rem] border transition-all flex flex-col gap-3 overflow-hidden group
                        ${currentTheme === t.id ? 'border-[var(--theme-color)] bg-[var(--theme-color)]/10 shadow-lg shadow-[var(--theme-color)]/10' : 'border-white/5 bg-white/5 hover:border-white/20'}
                      `}
                    >
                      <div className="w-10 h-10 rounded-2xl shadow-2xl border-4 border-black/30" style={{ backgroundColor: t.color }} />
                      <span className="text-[10px] font-black text-slate-300 uppercase tracking-widest">{t.name}</span>
                    </button>
                  ))}
                </div>
              </div>

              <div className="space-y-4">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-l-2 border-dragon-cyan pl-3">Neural Matrix Hub</h3>
                <div className="flex flex-col gap-2 p-3 bg-black/40 rounded-[2rem] border border-white/5">
                  {[
                    { id: 'dragon', name: 'Dragon Engine', icon: <Sparkles className="w-4 h-4" />, color: 'text-dragon-ember' },
                    { id: 'google', name: 'Google', icon: <Globe className="w-4 h-4" />, color: 'text-blue-500' },
                    { id: 'bing', name: 'Microsoft Bing', icon: <Search className="w-4 h-4" />, color: 'text-cyan-500' },
                  ].map(engine => (
                    <button
                      key={engine.id}
                      onClick={() => onEngineChange(engine.id as SearchEngine)}
                      className={`
                        flex items-center justify-between p-4 rounded-xl transition-all border
                        ${settings.searchEngine === engine.id 
                          ? 'bg-white/10 border-white/20 text-white shadow-lg' 
                          : 'border-transparent text-slate-500 hover:bg-white/5'}
                      `}
                    >
                      <div className="flex items-center gap-3">
                        <div className={engine.color}>{engine.icon}</div>
                        <span className="text-xs font-black uppercase tracking-tight">{engine.name}</span>
                      </div>
                      {settings.searchEngine === engine.id && (
                        <div className="w-2 h-2 rounded-full bg-[var(--theme-color)] shadow-[0_0_8px_var(--theme-color)]" />
                      )}
                    </button>
                  ))}
                </div>
              </div>
            </div>
          )}

          {activeTab === 'notes' && (
            <div className="h-full flex flex-col gap-6 animate-fade-in">
              <div className="flex items-center justify-between">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-l-2 border-dragon-ember pl-3">Quick Notes</h3>
                <button 
                  onClick={() => navigateTo(BrowserViewMode.NOTES_LIBRARY)}
                  className="flex items-center gap-2 text-[9px] font-black text-dragon-cyan uppercase tracking-widest hover:brightness-110 transition-all"
                >
                  <Library size={12} /> Open Library
                </button>
              </div>

              <div className="space-y-4">
                <textarea 
                  value={currentNote}
                  onChange={(e) => setCurrentNote(e.target.value)}
                  placeholder="Inscribe data fragment..."
                  className="w-full min-h-[120px] bg-black/40 border border-white/10 rounded-3xl p-5 text-sm text-slate-300 focus:outline-none focus:border-dragon-ember shadow-inner resize-none italic leading-relaxed"
                />
                
                <div className="flex gap-3">
                   <button 
                    onClick={handleCopyQuickNote}
                    className="flex-1 flex items-center justify-center gap-2 py-4 bg-white/5 border border-white/10 text-slate-400 hover:text-white rounded-2xl text-[9px] font-black uppercase tracking-widest transition-all active:scale-95"
                  >
                    <Copy size={14} /> Copy
                  </button>
                  <button 
                    onClick={handleSaveNote}
                    className="flex-1 flex items-center justify-center gap-2 py-4 bg-dragon-ember text-white rounded-2xl text-[9px] font-black uppercase tracking-widest shadow-xl shadow-dragon-ember/20 active:scale-95 transition-all"
                  >
                    <Plus size={16} /> Save to Library
                  </button>
                </div>
              </div>

              <div className="space-y-4 pb-12">
                <div className="flex items-center gap-2 px-1">
                   <div className="h-px flex-1 bg-white/5" />
                   <span className="text-[8px] font-black text-slate-600 uppercase tracking-[0.3em]">Recent Notes</span>
                   <div className="h-px flex-1 bg-white/5" />
                </div>
                {notes.length === 0 ? (
                  <p className="text-center text-slate-700 text-[9px] font-black uppercase tracking-[0.4em] pt-12">No notes saved</p>
                ) : (
                  notes.slice(0, 3).map((note) => (
                    <div key={note.id} className="group relative bg-white/5 border border-white/5 rounded-[1.5rem] p-5 shadow-xl hover:border-white/10 transition-all">
                      <p className="text-sm text-slate-300 leading-relaxed pr-8 font-medium italic truncate">"{note.text}"</p>
                      <div className="text-[8px] font-black text-slate-600 uppercase tracking-widest mt-2">{note.date}</div>
                      <button 
                        onClick={() => removeNote(note.id)}
                        className="absolute top-5 right-5 text-slate-600 hover:text-red-500 opacity-0 group-hover:opacity-100 transition-opacity"
                      >
                        <Trash2 className="w-4 h-4" />
                      </button>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {activeTab === 'bookmarks' && (
            <div className="h-full flex flex-col gap-6 animate-fade-in">
              <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-l-2 border-dragon-cyan pl-3">Saved Bookmarks</h3>
              <div className="space-y-4 pb-12">
                {bookmarks.length === 0 ? (
                  <p className="text-center text-slate-700 text-[9px] font-black uppercase tracking-[0.4em] pt-12">No bookmarks saved yet</p>
                ) : (
                  bookmarks.map((b) => (
                    <div key={b.id} className="group relative bg-white/5 border border-white/5 rounded-[1.5rem] p-5 flex items-center gap-4 hover:bg-white/10 transition-all shadow-lg">
                      <div className="w-12 h-12 rounded-2xl bg-black/40 flex items-center justify-center text-dragon-cyan border border-white/5 shadow-inner shrink-0">
                        <Globe className="w-6 h-6" />
                      </div>
                      <div className="flex-1 min-w-0">
                        <h4 className="text-xs font-black text-slate-100 truncate tracking-tight uppercase leading-none">{b.title}</h4>
                        <p className="text-[9px] text-slate-500 truncate uppercase font-bold tracking-tighter mt-1">{b.url}</p>
                      </div>
                      <div className="flex gap-1 opacity-0 group-hover:opacity-100 transition-opacity">
                         <button onClick={() => navigateTo(BrowserViewMode.BROWSER)} className="p-2.5 text-slate-500 hover:text-dragon-cyan bg-white/5 rounded-xl"><ExternalLink className="w-4 h-4" /></button>
                         <button onClick={() => toggleBookmark(b.url, b.title)} className="p-2.5 text-slate-500 hover:text-red-500 bg-white/5 rounded-xl"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    </div>
                  ))
                )}
              </div>
            </div>
          )}

          {activeTab === 'shield' && (
             <div className="space-y-8 animate-fade-in">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em] border-l-2 border-dragon-cyan pl-3">Protection Status</h3>
                <div className="bg-gradient-to-br from-dragon-navy to-dragon-dark rounded-[2.5rem] p-10 border border-white/10 text-center shadow-2xl relative overflow-hidden group">
                  <div className="absolute -inset-10 bg-dragon-cyan/10 blur-[60px] rounded-full group-hover:bg-dragon-ember/10 transition-colors" />
                  <div className="relative">
                    <div className="text-6xl font-black text-white mb-2 tabular-nums tracking-tighter italic drop-shadow-2xl">
                      {settings.trackersBlockedTotal.toLocaleString()}
                    </div>
                    <div className="text-[9px] text-dragon-cyan uppercase font-black tracking-[0.4em] mt-3">Intercepted Threats</div>
                  </div>
                </div>

                <div className="space-y-4">
                   {[
                     { label: 'Dragon Breath', active: settings.dragonBreath, desc: 'Script Interceptor' },
                     { label: 'Stealth Flight', active: settings.stealthFlight, desc: 'Masking Protocol' },
                     { label: 'Neural Mapping', active: settings.safeBrowsing, desc: 'Threat Prediction' },
                   ].map(feat => (
                     <div key={feat.label} className="flex justify-between items-center p-6 bg-white/5 rounded-[2rem] border border-white/5 group hover:border-white/20 transition-all shadow-xl">
                        <div className="text-left">
                          <span className="text-xs font-black text-slate-100 block uppercase tracking-tight">{feat.label}</span>
                          <span className="text-[9px] text-slate-500 uppercase font-bold tracking-widest">{feat.desc}</span>
                        </div>
                        <div className={`text-[9px] font-black px-4 py-2 rounded-full shadow-lg border ${feat.active ? 'bg-green-500/10 text-green-500 border-green-500/30' : 'bg-slate-800 text-slate-600 border-white/5'}`}>
                           {feat.active ? 'ONLINE' : 'OFFLINE'}
                        </div>
                     </div>
                   ))}
                </div>
             </div>
          )}
        </div>
      </div>
    </>
  );
};