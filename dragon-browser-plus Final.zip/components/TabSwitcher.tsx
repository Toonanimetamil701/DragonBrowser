
import React from 'react';
import { Plus, Shield, X, Globe, Lock, Ghost, Trash2, Layers } from 'lucide-react';
import { Tab, BrowserViewMode } from '../types';

interface TabSwitcherProps {
  tabs: Tab[];
  activeTabId: string;
  onSelectTab: (id: string) => void;
  onCloseTab: (id: string) => void;
  onCreateTab: (isPrivate?: boolean) => void;
  onClose: () => void;
  onCloseIncognito: () => void;
  onCloseAll: () => void;
}

export const TabSwitcher: React.FC<TabSwitcherProps> = ({
  tabs,
  activeTabId,
  onSelectTab,
  onCloseTab,
  onCreateTab,
  onClose,
  onCloseAll
}) => {
  return (
    <div className="flex flex-col h-full bg-dragon-dark text-slate-100 animate-fade-in overflow-hidden relative">
      {/* Safe Zone Header */}
      <div className="flex flex-col bg-dragon-navy/80 border-b border-white/5 backdrop-blur-xl shrink-0 pt-safe-top pb-4 px-6 gap-4">
        {/* Title Row */}
        <div className="flex items-center justify-between pt-2">
          <div className="flex items-center gap-2">
            <Layers className="w-4 h-4 text-slate-400" />
            <h2 className="text-sm font-black text-white uppercase tracking-[0.2em]">Tab Vault</h2>
          </div>
          
          {/* NEW: Clear All Tabs Option */}
          {tabs.length > 0 && (
            <button 
              onClick={() => { if(window.confirm("Purge all tabs in current context?")) onCloseAll(); }}
              className="flex items-center gap-2 px-3 py-1.5 bg-red-500/10 text-red-500 rounded-lg text-[9px] font-black uppercase tracking-widest active:scale-95 transition-all border border-red-500/20"
            >
              <Trash2 size={12} /> Clear All
            </button>
          )}
        </div>

        {/* Session Control Buttons */}
        <div className="flex gap-3">
          <button 
            onClick={() => onCreateTab(false)}
            className="flex-1 flex items-center justify-center gap-2 p-4 bg-dragon-ember rounded-2xl text-white font-black uppercase text-[10px] tracking-widest transition-transform active:scale-95 shadow-lg shadow-dragon-ember/20"
          >
            <Plus size={16} /> New Session
          </button>
          
          <button 
            onClick={() => onCreateTab(true)}
            className="flex-1 flex items-center justify-center gap-2 p-4 bg-purple-600 rounded-2xl text-white font-black uppercase text-[10px] tracking-widest transition-transform active:scale-95 shadow-lg shadow-purple-900/20"
          >
            <Shield size={16} /> New Incognito
          </button>
        </div>
      </div>

      {/* Tab Grid */}
      <div className="flex-1 overflow-y-auto p-4 no-scrollbar pb-32">
        <div className="grid grid-cols-2 gap-4">
          {tabs.map((tab) => (
            <div 
              key={tab.id}
              onClick={() => onSelectTab(tab.id)}
              className={`
                relative group flex flex-col rounded-[2rem] border-2 transition-all duration-300 overflow-hidden shadow-2xl h-48
                ${tab.isPrivate ? 'bg-slate-950 shadow-[0_0_20px_rgba(147,51,234,0.15)]' : 'bg-dragon-navy/40'}
                ${activeTabId === tab.id 
                  ? (tab.isPrivate ? 'border-purple-500 ring-4 ring-purple-500/20 scale-[1.02]' : 'border-dragon-ember ring-4 ring-dragon-ember/10 scale-[1.02]')
                  : (tab.isPrivate ? 'border-purple-500/20 hover:border-purple-500/40' : 'border-white/5 hover:border-white/20')
                }
              `}
            >
              {/* Tab Header inside Card */}
              <div className={`p-4 flex items-center gap-2 border-b shrink-0 ${tab.isPrivate ? 'bg-purple-900/10 border-purple-500/10' : 'bg-black/40 border-white/5'}`}>
                {tab.isPrivate ? (
                  <Ghost size={12} className="text-purple-400 shrink-0" />
                ) : (
                  <Globe size={12} className="text-dragon-cyan shrink-0" />
                )}
                <span className={`text-[10px] font-black truncate flex-1 uppercase tracking-tighter ${tab.isPrivate ? 'text-purple-100' : 'text-slate-300'}`}>
                  {tab.isPrivate && (tab.title === 'Dragon Search' || !tab.title) ? 'Incognito Mode' : (tab.title || 'Untitled Node')}
                </span>
                {tab.isPrivate && (
                  <span className="text-[7px] font-black bg-purple-600 text-white px-1.5 py-0.5 rounded tracking-widest shadow-lg shadow-purple-600/20">
                    PRIVATE
                  </span>
                )}
              </div>

              {/* Tab Preview (Placeholder/Visual) */}
              <div className="flex-1 flex items-center justify-center bg-black/20 p-4">
                 <div className={`w-12 h-12 rounded-2xl flex items-center justify-center opacity-20 ${tab.isPrivate ? 'bg-purple-500' : 'bg-dragon-cyan'}`}>
                    {tab.isPrivate ? <Ghost className="w-6 h-6 text-white" /> : <Globe className="w-6 h-6 text-white" />}
                 </div>
              </div>

              {/* Close Button */}
              <button 
                onClick={(e) => { e.stopPropagation(); onCloseTab(tab.id); }}
                className={`
                  absolute top-2 right-2 w-8 h-8 rounded-full backdrop-blur-md flex items-center justify-center transition-colors shadow-lg border
                  ${tab.isPrivate 
                    ? 'bg-purple-900/40 border-purple-500/20 text-purple-300 hover:text-white hover:bg-purple-600' 
                    : 'bg-black/60 border-white/5 text-slate-400 hover:text-red-400'}
                `}
              >
                <X size={16} />
              </button>

              {/* Active Indicator */}
              {activeTabId === tab.id && (
                <div className={`absolute bottom-0 inset-x-0 h-1 ${tab.isPrivate ? 'bg-purple-500' : 'bg-dragon-ember'}`} />
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Footer / Close Button */}
      <div className="p-4 pb-safe-bottom shrink-0 bg-dragon-navy/40 border-t border-white/5 z-40 backdrop-blur-md">
         <button 
           onClick={onClose}
           className="w-full py-4 rounded-2xl bg-white/5 border border-white/10 text-xs font-black uppercase tracking-widest text-slate-400 hover:text-white transition-all active:scale-95"
         >
           Close Switcher
         </button>
      </div>
    </div>
  );
};
