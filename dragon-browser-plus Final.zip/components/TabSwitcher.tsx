
import React, { useState, useMemo } from 'react';
import { Plus, X, Globe, Lock, Search, MoreVertical, Clock, LayoutGrid, Folder, FolderPlus, Edit3, Trash2, Check, Pin } from 'lucide-react';
import { Tab, TabGroup } from '../types';

interface TabSwitcherProps {
  tabs: Tab[];
  tabGroups: TabGroup[];
  activeTabId: string;
  onSelectTab: (id: string) => void;
  onCloseTab: (id: string) => void;
  onDuplicateTab: (id: string) => void;
  onCreateTab: (isPrivate?: boolean, groupId?: string) => void;
  onCreateGroup: (title: string) => void;
  onDeleteGroup: (groupId: string) => void;
  onUpdateGroup: (groupId: string, updates: Partial<TabGroup>) => void;
  onMoveTabToGroup: (tabId: string, groupId?: string) => void;
  onClose: () => void;
  onCloseIncognito: () => void;
  onCloseAll: () => void;
  onTogglePin: (id: string) => void;
  onRestoreClosedTab?: () => void;
  canRestoreTab?: boolean;
  onOpenHistory?: () => void;
}

export const TabSwitcher: React.FC<TabSwitcherProps> = ({
  tabs,
  tabGroups,
  activeTabId,
  onSelectTab,
  onCloseTab,
  onDuplicateTab,
  onCreateTab,
  onCreateGroup,
  onDeleteGroup,
  onUpdateGroup,
  onMoveTabToGroup,
  onClose,
  onCloseAll,
  onTogglePin,
  onRestoreClosedTab,
  canRestoreTab,
  onOpenHistory
}) => {
  const [activeSection, setActiveSection] = useState<'tabs' | 'private'>('tabs');
  const [isSearchActive, setIsSearchActive] = useState(false);
  const [searchQuery, setSearchQuery] = useState('');
  const [showMenu, setShowMenu] = useState(false);
  
  // Drag and Drop State
  const [draggedTabId, setDraggedTabId] = useState<string | null>(null);

  // Group Editing
  const [isCreatingGroup, setIsCreatingGroup] = useState(false);
  const [newGroupTitle, setNewGroupTitle] = useState('');
  const [editingGroupId, setEditingGroupId] = useState<string | null>(null);
  const [editTitle, setEditTitle] = useState('');

  const GROUP_COLORS = ['#f97316', '#06b6d4', '#eab308', '#22c55e', '#ef4444', '#a855f7'];

  // --- Filtering Logic ---
  const filteredTabs = useMemo(() => {
    let result = tabs.filter(t => activeSection === 'private' ? t.isPrivate : !t.isPrivate);
    if (searchQuery) {
      const lowerQ = searchQuery.toLowerCase();
      result = result.filter(t => (t.title || '').toLowerCase().includes(lowerQ) || (t.url || '').toLowerCase().includes(lowerQ));
    }
    return result;
  }, [tabs, activeSection, searchQuery]);

  // Group Logic
  const groupedTabs = useMemo(() => {
    const groups = tabGroups.map(g => ({
      group: g,
      tabs: filteredTabs.filter(t => t.groupId === g.id)
    })); // Empty groups are visible for dropping tabs

    const ungrouped = filteredTabs.filter(t => !t.groupId);
    return { groups, ungrouped };
  }, [tabGroups, filteredTabs]);

  // --- Actions ---
  const handleCreateGroup = () => {
    if (newGroupTitle.trim()) {
      onCreateGroup(newGroupTitle);
      setNewGroupTitle('');
      setIsCreatingGroup(false);
    }
  };

  const startEditingGroup = (group: TabGroup) => {
    setEditingGroupId(group.id);
    setEditTitle(group.title);
  };

  const saveEditingGroup = (groupId: string) => {
    onUpdateGroup(groupId, { title: editTitle });
    setEditingGroupId(null);
  };

  // --- Drag & Drop ---
  const handleDragStart = (e: React.DragEvent, tabId: string) => {
    setDraggedTabId(tabId);
    e.dataTransfer.setData('text/plain', tabId);
    e.dataTransfer.effectAllowed = 'move';
  };

  const handleDragOver = (e: React.DragEvent) => {
    e.preventDefault();
    e.dataTransfer.dropEffect = 'move';
  };

  const handleDrop = (e: React.DragEvent, targetGroupId?: string) => {
    e.preventDefault();
    const tabId = e.dataTransfer.getData('text/plain');
    if (tabId) {
      onMoveTabToGroup(tabId, targetGroupId);
    }
    setDraggedTabId(null);
  };

  // --- Render Helpers ---
  const renderTabCard = (tab: Tab) => {
    const domain = tab.url.startsWith('dragon://') ? 'Dragon' : new URL(tab.url).hostname.replace('www.', '');
    const favicon = tab.url.startsWith('dragon://') 
      ? 'https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg' 
      : `https://www.google.com/s2/favicons?sz=64&domain=${domain}`;

    return (
      <div 
        key={tab.id}
        draggable={!tab.isPrivate}
        onDragStart={(e) => handleDragStart(e, tab.id)}
        onClick={() => onSelectTab(tab.id)}
        className={`
          relative flex flex-col rounded-[1.2rem] overflow-hidden transition-all duration-300 h-44 shadow-lg group
          ${activeTabId === tab.id ? 'ring-2 ring-purple-500 scale-[1.02]' : 'ring-1 ring-white/10 hover:ring-white/20'}
          ${draggedTabId === tab.id ? 'opacity-50 scale-95' : ''}
          bg-[#232428]
        `}
      >
        {/* Card Header */}
        <div className="flex items-center justify-between px-3 py-2.5 bg-[#2b2c31] shrink-0">
          <div className="flex items-center gap-2 min-w-0">
            <img 
              src={favicon} 
              className="w-4 h-4 rounded-sm object-cover" 
              onError={(e) => { (e.target as HTMLImageElement).style.display = 'none' }}
            />
            <span className="text-[11px] font-bold text-slate-200 truncate leading-none">
              {tab.title || 'New Tab'}
            </span>
          </div>
          <button 
            onClick={(e) => { e.stopPropagation(); onCloseTab(tab.id); }}
            className="p-1 text-slate-400 hover:text-white rounded-full hover:bg-white/10 transition-colors"
          >
            <X size={14} />
          </button>
        </div>

        {/* Card Preview / Body */}
        <div className="flex-1 relative bg-[#1e1f23] p-3 flex flex-col items-center justify-center group-hover:bg-[#25262a] transition-colors">
           {tab.pinned && (
             <div className="absolute top-2 right-2 text-purple-400">
               <Pin size={12} fill="currentColor" />
             </div>
           )}
           <div className={`w-12 h-12 rounded-2xl flex items-center justify-center mb-2 ${tab.isPrivate ? 'bg-purple-500/20 text-purple-400' : 'bg-blue-500/20 text-blue-400'}`}>
              {tab.isPrivate ? <Lock size={20} /> : <Globe size={20} />}
           </div>
           <span className="text-[9px] font-medium text-slate-500 text-center px-2 line-clamp-2">
             {domain}
           </span>
        </div>
      </div>
    );
  };

  return (
    <div className="flex flex-col h-full w-full bg-gradient-to-br from-indigo-950 via-slate-950 to-black text-white overflow-hidden relative font-sans">
      
      {/* Top Header */}
      <div className="flex items-center justify-between px-6 pt-[calc(1rem+env(safe-area-inset-top))] pb-4 shrink-0 z-20">
        <div className="flex items-center gap-6">
          <button 
            onClick={() => setActiveSection('tabs')}
            className={`text-lg font-black transition-colors ${activeSection === 'tabs' ? 'text-white' : 'text-white/40 hover:text-white/70'}`}
          >
            Tabs
          </button>
          <button 
            onClick={() => setActiveSection('private')}
            className={`text-lg font-black transition-colors ${activeSection === 'private' ? 'text-white' : 'text-white/40 hover:text-white/70'}`}
          >
            Private
          </button>
        </div>
        
        <button 
          onClick={() => setIsSearchActive(!isSearchActive)}
          className={`p-2.5 rounded-full transition-all ${isSearchActive ? 'bg-white/20 text-white' : 'bg-white/5 text-white/60 hover:bg-white/10 hover:text-white'}`}
        >
          <Search size={20} />
        </button>
      </div>

      {/* Search Input */}
      {isSearchActive && (
        <div className="px-4 pb-2 animate-fade-in shrink-0">
          <input 
            autoFocus
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            placeholder="Search tabs..."
            className="w-full bg-white/10 border border-white/10 rounded-xl px-4 py-3 text-sm text-white placeholder-white/40 focus:outline-none focus:bg-white/15"
          />
        </div>
      )}

      {/* Main Grid Content */}
      <div className="flex-1 overflow-y-auto p-4 no-scrollbar pb-32">
        {/* Groups */}
        {groupedTabs.groups.map(({ group, tabs }) => (
          <div 
            key={group.id}
            className={`mb-6 rounded-[2rem] border border-white/5 bg-white/5 p-4 ${draggedTabId ? 'border-dashed border-white/20' : ''}`}
            onDragOver={handleDragOver}
            onDrop={(e) => handleDrop(e, group.id)}
          >
            <div className="flex items-center justify-between mb-3 px-2">
              {editingGroupId === group.id ? (
                <div className="flex-1 flex items-center gap-2">
                   <input 
                      autoFocus
                      value={editTitle}
                      onChange={(e) => setEditTitle(e.target.value)}
                      className="bg-black/40 border border-white/20 rounded-lg px-2 py-1 text-xs text-white focus:outline-none flex-1"
                   />
                   <div className="flex gap-1">
                     {GROUP_COLORS.map(c => (
                       <button 
                         key={c}
                         onClick={() => onUpdateGroup(group.id, { color: c })}
                         className={`w-4 h-4 rounded-full border ${group.color === c ? 'border-white' : 'border-transparent'}`}
                         style={{ backgroundColor: c }}
                       />
                     ))}
                   </div>
                   <button onClick={() => saveEditingGroup(group.id)} className="p-1 bg-green-500/20 text-green-500 rounded"><Check size={14} /></button>
                </div>
              ) : (
                <div className="flex items-center gap-2">
                  <Folder size={14} style={{ color: group.color }} />
                  <span className="text-xs font-bold uppercase tracking-wider">{group.title}</span>
                  <span className="text-[10px] text-white/40 font-bold">({tabs.length})</span>
                </div>
              )}
              
              <div className="flex gap-2">
                 {editingGroupId !== group.id && (
                    <button onClick={() => startEditingGroup(group)} className="p-1.5 text-white/40 hover:text-white bg-white/5 rounded-lg"><Edit3 size={12} /></button>
                 )}
                 <button onClick={() => onDeleteGroup(group.id)} className="p-1.5 text-white/40 hover:text-red-400 bg-white/5 rounded-lg"><Trash2 size={12} /></button>
              </div>
            </div>
            
            <div className="grid grid-cols-2 gap-3 min-h-[80px]">
              {tabs.map(renderTabCard)}
              {/* Empty Group Drop Zone */}
              {tabs.length === 0 && (
                <div className="col-span-2 flex flex-col items-center justify-center p-6 border-2 border-dashed border-white/10 rounded-2xl bg-white/5 opacity-50">
                   <span className="text-[9px] font-black uppercase tracking-widest text-slate-400">Empty Group</span>
                   <span className="text-[8px] font-bold text-slate-600">Drag tabs here</span>
                </div>
              )}
            </div>
          </div>
        ))}

        {/* Ungrouped Tabs Drop Zone */}
        <div 
          onDragOver={handleDragOver}
          onDrop={(e) => handleDrop(e, undefined)}
          className={`grid grid-cols-2 gap-3 min-h-[100px] ${draggedTabId ? 'bg-white/5 rounded-[1.5rem] border-2 border-dashed border-white/10' : ''}`}
        >
          {groupedTabs.ungrouped.map(renderTabCard)}
        </div>

        {/* Empty State */}
        {filteredTabs.length === 0 && (
          <div className="flex flex-col items-center justify-center py-20 opacity-30">
            <LayoutGrid size={48} className="mb-4" />
            <p className="text-sm font-bold uppercase tracking-widest">No Tabs Open</p>
          </div>
        )}
      </div>

      {/* New Group Input Overlay */}
      {isCreatingGroup && (
        <div className="absolute bottom-24 left-4 right-4 z-50 bg-[#1a1a1a] p-4 rounded-2xl shadow-2xl border border-white/10 animate-slide-up">
          <div className="flex gap-2">
            <input 
              autoFocus
              value={newGroupTitle}
              onChange={(e) => setNewGroupTitle(e.target.value)}
              placeholder="Enter group name..."
              className="flex-1 bg-black/40 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-purple-500"
            />
            <button onClick={handleCreateGroup} className="px-4 py-2 bg-purple-600 text-white rounded-xl text-xs font-bold">Create</button>
            <button onClick={() => setIsCreatingGroup(false)} className="px-3 py-2 bg-white/5 text-slate-400 rounded-xl"><X size={16} /></button>
          </div>
        </div>
      )}

      {/* Bottom Floating Bar - Exact Match to Requirement */}
      <div className="absolute bottom-6 left-6 right-6 h-[72px] bg-[#1e1e24] rounded-full flex items-center justify-between px-6 shadow-2xl border border-white/5 z-40">
        
        {/* Left Actions - Grid (Return to Browser) & History */}
        <div className="flex items-center gap-1">
          <button 
            onClick={onClose} 
            className="p-3 text-white/50 hover:text-white transition-colors"
            title="Return to Browser"
          >
            <LayoutGrid size={22} />
          </button>
          <button 
            onClick={onOpenHistory} 
            className="p-3 text-white/50 hover:text-white transition-colors"
            title="History"
          >
            <Clock size={22} />
          </button>
        </div>

        {/* Center Primary Action - New Tab */}
        <div className="absolute left-1/2 -translate-x-1/2 -top-6">
          <button 
            onClick={() => onCreateTab(activeSection === 'private')}
            className="w-16 h-16 rounded-full bg-[#8b5cf6] text-white flex items-center justify-center shadow-[0_0_20px_rgba(139,92,246,0.4)] hover:scale-105 active:scale-95 transition-all border-4 border-[#1e1e24]"
          >
            <Plus size={32} strokeWidth={2.5} />
          </button>
        </div>

        {/* Right Actions - Tab Count & Context Menu */}
        <div className="flex items-center gap-4">
          <div className="w-8 h-8 rounded-lg border-2 border-white/20 flex items-center justify-center">
            <span className="text-xs font-black text-white">{filteredTabs.length}</span>
          </div>
          
          <div className="relative">
            <button 
              onClick={() => setShowMenu(!showMenu)}
              className="p-3 text-white/50 hover:text-white transition-colors"
            >
              <MoreVertical size={22} />
            </button>

            {/* Context Menu - New Group & Close All */}
            {showMenu && (
              <>
                <div className="fixed inset-0 z-40" onClick={() => setShowMenu(false)} />
                <div className="absolute bottom-[calc(100%+10px)] right-0 w-48 bg-[#1e1e24] border border-white/5 rounded-2xl shadow-2xl overflow-hidden z-50 animate-fade-in flex flex-col p-2">
                  <button 
                    onClick={() => { setIsCreatingGroup(true); setShowMenu(false); }}
                    className="flex items-center gap-3 px-4 py-3.5 text-left hover:bg-white/5 rounded-xl transition-colors"
                  >
                    <FolderPlus size={18} className="text-purple-400" />
                    <span className="text-[11px] font-black text-slate-200 uppercase tracking-widest">New Group</span>
                  </button>
                  <div className="h-px bg-white/5 my-1 mx-2" />
                  <button 
                    onClick={() => { onCloseAll(); setShowMenu(false); }}
                    className="flex items-center gap-3 px-4 py-3.5 text-left hover:bg-red-500/10 rounded-xl transition-colors group"
                  >
                    <Trash2 size={18} className="text-red-500" />
                    <span className="text-[11px] font-black text-red-500 uppercase tracking-widest">Close All</span>
                  </button>
                </div>
              </>
            )}
          </div>
        </div>
      </div>
    </div>
  );
};
