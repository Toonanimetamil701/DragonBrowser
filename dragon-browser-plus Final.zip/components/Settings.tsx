import React from 'react';
import { useDragon } from '../DragonContext';
import { 
  Shield, User, Palette, Globe, Lock, Trash2, 
  Monitor, Search, ChevronRight, Check, Sparkles, Info,
  Zap, EyeOff, ZapOff, Fingerprint, Activity, MousePointer2, Code, PictureInPicture
} from 'lucide-react';
import { ThemeColor, SearchEngine, AppSettings } from '../types';

export const Settings: React.FC = () => {
  const { settings, updateSettings, clearHistory, setViewMode } = useDragon();

  const sections = [
    {
      title: 'Visual Core',
      icon: <Palette className="w-5 h-5 text-dragon-cyan" />,
      items: [
        { label: 'Dragon Essence', type: 'color-picker' },
        { label: 'Dragon Strength', key: 'isDesktopMode', type: 'toggle', desc: 'Override Mobile View (Desktop Mode)' },
      ]
    },
    {
      title: 'Shield Protocols',
      icon: <Shield className="w-5 h-5 text-dragon-ember" />,
      items: [
        { label: 'Dragon Breath', key: 'dragonBreath', type: 'toggle', desc: 'Block high-latency scripts' },
        { label: 'Stealth Flight', key: 'stealthFlight', type: 'toggle', desc: 'Advanced biometric anonymity' },
        { label: 'Neural Map', key: 'safeBrowsing', type: 'toggle', desc: 'Heuristic site analysis' },
        { label: 'Void Mode Lock', key: 'incognitoLockEnabled', type: 'toggle', desc: 'Lock incognito tabs on exit' },
        { label: 'JavaScript Execution', key: 'javaScriptEnabled', type: 'toggle', desc: 'Allow sites to run scripts' },
      ]
    },
    {
      title: 'Search Algorithms',
      icon: <Search className="w-5 h-5 text-blue-400" />,
      items: [
        { label: 'Dragon Neural (AI)', value: 'dragon', desc: 'Gemini-3 Pro Powered' },
        { label: 'Google Quantum', value: 'google', desc: 'Standard Search Engine' },
        { label: 'Bing Matrix', value: 'bing', desc: 'Microsoft Search Link' },
        { label: 'DuckDuckGo Stealth', value: 'duckduckgo', desc: 'High Privacy engine' },
      ],
      type: 'radio',
      key: 'searchEngine'
    }
  ];

  const colors: { id: ThemeColor; hex: string }[] = [
    { id: 'ember', hex: '#f97316' },
    { id: 'frost', hex: '#06b6d4' },
    { id: 'midas', hex: '#eab308' },
    { id: 'venom', hex: '#22c55e' },
  ];

  return (
    <div className="flex flex-col h-full bg-dragon-dark text-slate-100 overflow-y-auto no-scrollbar animate-fade-in pb-safe-bottom">
      <div className="p-8 pt-safe-top bg-gradient-to-b from-dragon-navy to-dragon-dark backdrop-blur-2xl sticky top-0 z-10 border-b border-white/5 flex items-center justify-between">
        <div className="flex items-center gap-3">
           <div className="p-3 bg-dragon-cyan/10 rounded-2xl border border-dragon-cyan/20">
             <Monitor className="w-6 h-6 text-dragon-cyan" />
           </div>
           <div>
             <h2 className="text-2xl font-black tracking-tight">GLOBAL MATRIX</h2>
             <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Architect: Amudhan T</p>
           </div>
        </div>
        <button 
          onClick={() => setViewMode(0 as any)}
          className="px-6 py-2.5 bg-white/5 hover:bg-white/10 rounded-2xl text-sm font-black tracking-widest text-dragon-cyan transition-all border border-white/5"
        >
          DONE
        </button>
      </div>

      <div className="p-6 space-y-10">
        {/* Profile Card */}
        <div className="relative group">
          <div className="absolute -inset-1 bg-gradient-to-r from-dragon-ember to-dragon-cyan blur opacity-20 group-hover:opacity-40 transition-opacity rounded-3xl" />
          <div className="relative bg-dragon-navy/50 rounded-3xl p-8 border border-white/10 shadow-2xl flex items-center gap-6">
            <div className="w-20 h-20 rounded-3xl bg-gradient-to-br from-dragon-ember to-slate-900 flex items-center justify-center text-3xl font-black shadow-[0_15px_30px_rgba(249,115,22,0.3)] ring-4 ring-black/20">
              AT
            </div>
            <div>
              <h3 className="text-xl font-black text-white tracking-tight">Amudhan T</h3>
              <p className="text-sm text-slate-400 font-bold">Lead Browser Architect</p>
              <div className="flex gap-2 mt-3">
                <span className="px-2 py-0.5 bg-dragon-cyan/20 text-dragon-cyan text-[10px] font-black rounded-full border border-dragon-cyan/30">PREMIUM</span>
                <span className="px-2 py-0.5 bg-white/10 text-slate-400 text-[10px] font-black rounded-full border border-white/10">STABLE</span>
              </div>
            </div>
          </div>
        </div>

        {sections.map((section, idx) => (
          <div key={idx} className="space-y-4">
            <h4 className="px-3 text-[11px] font-black text-slate-500 uppercase tracking-[0.3em] flex items-center gap-3">
              {section.icon} {section.title}
            </h4>
            <div className="bg-white/5 rounded-[2.5rem] border border-white/5 overflow-hidden shadow-2xl">
              {section.items.map((item, itemIdx) => {
                if (section.type === 'radio') {
                  const isSelected = settings.searchEngine === item.value;
                  return (
                    <button
                      key={itemIdx}
                      onClick={() => updateSettings({ searchEngine: item.value as SearchEngine })}
                      className={`
                        w-full flex items-center justify-between p-6 hover:bg-white/5 transition-all border-b border-white/5 last:border-0
                        ${isSelected ? 'bg-white/5' : ''}
                      `}
                    >
                      <div className="text-left">
                        <span className={`text-sm font-black block ${isSelected ? 'text-white' : 'text-slate-500'}`}>
                          {item.label}
                        </span>
                        <span className="text-[10px] text-slate-600 font-bold uppercase tracking-widest">{item.desc}</span>
                      </div>
                      <div className={`w-6 h-6 rounded-full border-2 flex items-center justify-center transition-all ${isSelected ? 'border-dragon-cyan bg-dragon-cyan shadow-[0_0_15px_rgba(6,182,212,0.5)]' : 'border-slate-700'}`}>
                        {isSelected && <Check className="w-4 h-4 text-dragon-dark stroke-[3px]" />}
                      </div>
                    </button>
                  );
                }

                if (item.type === 'color-picker') {
                  return (
                    <div key={itemIdx} className="p-6 flex items-center justify-between border-b border-white/5">
                      <div className="text-left">
                        <span className="text-sm font-black text-slate-300 block">System Essence</span>
                        <span className="text-[10px] text-slate-600 font-bold uppercase tracking-widest">Global Accent Interface</span>
                      </div>
                      <div className="flex gap-3">
                        {colors.map(c => (
                          <button
                            key={c.id}
                            onClick={() => updateSettings({ themeColor: c.id })}
                            className={`w-10 h-10 rounded-2xl border-2 transition-all shadow-xl active:scale-90 ${settings.themeColor === c.id ? 'scale-110 border-white ring-4 ring-black/20' : 'border-transparent opacity-50'}`}
                            style={{ backgroundColor: c.hex }}
                          />
                        ))}
                      </div>
                    </div>
                  );
                }

                return (
                  <div key={itemIdx} className="flex items-center justify-between p-6 border-b border-white/5 last:border-0 hover:bg-white/5 transition-colors">
                    <div className="text-left">
                      <span className="text-sm font-black text-slate-300 block">{item.label}</span>
                      <span className="text-[10px] text-slate-600 font-bold uppercase tracking-widest">{item.desc}</span>
                    </div>
                    <button
                      onClick={() => updateSettings({ [item.key!]: !settings[item.key as keyof AppSettings] })}
                      className={`w-14 h-8 rounded-2xl relative transition-all shadow-inner ${settings[item.key as keyof AppSettings] ? 'bg-dragon-cyan' : 'bg-slate-800'}`}
                    >
                      <div className={`absolute top-1 w-6 h-6 rounded-xl bg-white shadow-xl transition-all ${settings[item.key as keyof AppSettings] ? 'translate-x-7' : 'translate-x-1'}`} />
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        ))}

        <div className="space-y-4">
          <h4 className="px-3 text-[11px] font-black text-slate-500 uppercase tracking-[0.3em] flex items-center gap-3">
            <Trash2 className="w-4 h-4" /> Danger Protocol
          </h4>
          <button 
            onClick={() => {
              if (window.confirm('Initiate global history purge?')) clearHistory();
            }}
            className="w-full bg-red-500/10 border border-red-500/20 text-red-500 rounded-3xl p-6 text-sm font-black uppercase tracking-[0.2em] hover:bg-red-500/20 active:scale-95 transition-all shadow-2xl"
          >
            Purge Neural Fragments
          </button>
        </div>

        <div className="pt-16 pb-20 text-center space-y-4">
          <div className="flex justify-center">
             <div className="p-6 bg-dragon-navy/50 rounded-[2.5rem] border border-white/10 shadow-2xl animate-float">
               <Sparkles className="w-10 h-10 text-dragon-cyan" />
             </div>
          </div>
          <div className="space-y-1">
            <p className="text-lg font-black text-white tracking-widest uppercase">Dragon Browser Pro+</p>
            <p className="text-xs text-slate-500 font-black uppercase tracking-[0.4em]">Neural Engine v1.2.4</p>
          </div>
          <p className="text-[10px] text-slate-700 font-black uppercase tracking-[0.5em] mt-6">
            The Architect of the Dragon Browser
          </p>
          <p className="text-[9px] text-slate-800 font-mono">Build Hash: 0xDragonHeart_AT_2024</p>
        </div>
      </div>
    </div>
  );
};
