
import React, { useRef, useState } from 'react';
import { useDragon } from '../DragonContext';
import DragonHeader from '../components/DragonHeader';
import { 
  Palette, Search, Check, Monitor, 
  ChevronRight, Zap, Fingerprint, Lock, ShieldCheck,
  Download, Upload, Send, Mail, ShieldAlert,
  Clock, Trash2, LayoutGrid, Sun, Moon,
  Info, Mic, Pencil, FolderOpen, Heart, AlertTriangle,
  Globe, Server, Sparkles, Star, Layers, Plus, Image as ImageIcon, Code, BellOff, PictureInPicture,
  ExternalLink, Camera, Shield
} from 'lucide-react';
import { SearchEngine, AppSettings, BrowserViewMode, ToolbarConfig } from '../types';
import { AppLockScreen } from '../components/AppLockScreen';

export const Settings: React.FC = () => {
  const { settings, updateSettings, clearHistory, setViewMode, architect, purgeAllData } = useDragon();
  const fileInputRef = useRef<HTMLInputElement>(null);
  const wallpaperInputRef = useRef<HTMLInputElement>(null);
  const folderInputRef = useRef<HTMLInputElement>(null);
  
  const [searchQuery, setSearchQuery] = useState('');
  const [showPinSetup, setShowPinSetup] = useState(false);
  
  const handleToggle = (key: keyof AppSettings) => {
    updateSettings({ [key]: !settings[key] });
  };

  const handleToolbarToggle = (key: keyof ToolbarConfig) => {
    updateSettings({
      toolbarConfig: {
        ...settings.toolbarConfig,
        [key]: !settings.toolbarConfig[key]
      }
    });
  };

  const handleAppLockToggle = () => {
    if (settings.security.appLockEnabled) {
      updateSettings({
        security: { ...settings.security, appLockEnabled: false }
      });
    } else {
      setShowPinSetup(true);
    }
  };

  const handlePinSetupComplete = (pin: string) => {
    updateSettings({
      security: {
        ...settings.security,
        appLockEnabled: true,
        pin: pin
      }
    });
    setShowPinSetup(false);
  };

  const exportDragonConfig = () => {
    const config = JSON.stringify(localStorage);
    const blob = new Blob([config], { type: 'application/json' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = 'dragon_config_v1.json';
    link.click();
    URL.revokeObjectURL(url);
  };

  if (showPinSetup) {
    return (
      <AppLockScreen 
        isSetupMode={true} 
        onSetupComplete={handlePinSetupComplete} 
        onCancelSetup={() => setShowPinSetup(false)} 
      />
    );
  }

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-dragon-dark text-slate-900 dark:text-slate-100 overflow-hidden relative">
      <DragonHeader 
        title="SETTINGS" 
        subtitle="SYSTEM CONTROL CENTER"
        onBack={() => setViewMode(BrowserViewMode.BROWSER)}
      />

      <div className="px-4 pb-2 pt-2 bg-slate-50 dark:bg-dragon-dark/95 backdrop-blur-xl z-40">
        <div className="relative group">
          <Search className="absolute left-4 top-1/2 -translate-y-1/2 w-4 h-4 text-slate-400 dark:text-slate-500" />
          <input
            type="text"
            placeholder="Search settings..."
            value={searchQuery}
            onChange={(e) => setSearchQuery(e.target.value)}
            className="w-full bg-white dark:bg-dragon-navy/50 border border-slate-200 dark:border-white/10 rounded-2xl py-3 pl-11 pr-4 text-sm font-medium focus:outline-none focus:border-dragon-cyan/50"
          />
        </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar pb-safe-bottom p-4 space-y-6">
        <div className="bg-white dark:bg-black/20 rounded-3xl p-6 border border-slate-200 dark:border-white/5 space-y-4">
          <h3 className="text-[10px] font-black text-dragon-ember uppercase tracking-widest">General Protection</h3>
          <div className="flex items-center justify-between">
            <div className="flex items-center gap-3">
              <Shield size={18} className="text-dragon-cyan" />
              <span className="text-sm font-bold uppercase">Shield Active</span>
            </div>
            <button
              onClick={() => handleToggle('adBlockEnabled')}
              className={`w-12 h-7 rounded-full relative transition-all ${settings.adBlockEnabled ? 'bg-dragon-ember' : 'bg-slate-300 dark:bg-slate-700'}`}
            >
              <div className={`absolute top-1 w-5 h-5 bg-white rounded-full transition-all ${settings.adBlockEnabled ? 'translate-x-6' : 'translate-x-1'}`} />
            </button>
          </div>
        </div>

        <button 
          onClick={exportDragonConfig}
          className="w-full py-4 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-2xl text-[10px] font-black uppercase tracking-widest flex items-center justify-center gap-2"
        >
          <Download size={14} /> Export Neural Config
        </button>
      </div>
    </div>
  );
};
