
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { useDragon, Shortcut } from '../DragonContext';
import { Mic, Clock, Trash2, Globe, Layers, Search, Sparkles, Loader2, X, AlertCircle, Edit2, Plus, Save } from 'lucide-react';
import { normalizeUrl } from '../utils/urlUtils';
import { useVoiceSearch } from '../hooks/useVoiceSearch';
import { useDragonAI } from '../hooks/useDragonAI';

interface NewTabPageProps {
  onNavigate: (url: string) => void;
  onOpenInNewTab: (url: string) => void;
}

const presets = [
    { id: 'default', name: 'Dragon Default', url: 'https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg' },
    { id: 'void', name: 'Void Black', url: '' },
    { id: 'cyber', name: 'Cyber Grid', url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1000' },
    { id: 'abyssal', name: 'Abyssal Black', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=1000' },
];

export const NewTabPage: React.FC<NewTabPageProps> = ({ onNavigate, onOpenInNewTab }) => {
  const { speedDial, settings, updateSettings, history, clearHistory, removeHistoryItem, updateSpeedDial } = useDragon();
  const [mainSearch, setMainSearch] = useState('');
  const [isHistoryManageMode, setIsHistoryManageMode] = useState(false);
  const [showSuggestions, setShowSuggestions] = useState(false);
  
  const [contextMenu, setContextMenu] = useState<{ shortcut: Shortcut; x: number; y: number } | null>(null);
  const [editingItem, setEditingItem] = useState<Shortcut | null>(null);
  const [editForm, setEditForm] = useState({ name: '', url: '' });

  const longPressTimer = useRef<number | null>(null);
  const inputRef = useRef<HTMLInputElement>(null);

  const { suggestions, fetchSuggestions, isLoading } = useDragonAI();

  const { 
    isListening, 
    voiceState, 
    interimTranscript, 
    error: voiceError, 
    startListening, 
    stopListening, 
    reset: resetVoice 
  } = useVoiceSearch((transcript) => {
    setMainSearch(transcript);
    onNavigate(normalizeUrl(transcript, settings.searchEngine));
  });

  // Debounce suggestions fetch
  useEffect(() => {
    const timer = setTimeout(() => {
      if (mainSearch && document.activeElement === inputRef.current) {
        fetchSuggestions(mainSearch);
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [mainSearch, fetchSuggestions]);

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mainSearch.trim()) return;
    setShowSuggestions(false);
    onNavigate(normalizeUrl(mainSearch, settings.searchEngine));
  };

  const getCleanDomain = (url: string) => {
    try {
      const u = url.startsWith('http') ? url : `https://${url}`;
      return new URL(u).hostname.replace('www.', '');
    } catch {
      return url.replace(/^(?:https?:\/\/)?(?:www\.)?/i, "").split('/')[0];
    }
  };

  const startLongPress = (shortcut: Shortcut, x: number, y: number) => {
    longPressTimer.current = window.setTimeout(() => {
      setContextMenu({ shortcut, x, y });
      if (navigator.vibrate) navigator.vibrate(40);
    }, 600);
  };

  const cancelLongPress = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const MAX_SLOTS = 8;
  const shortcuts = speedDial.slice(0, MAX_SLOTS);
  const recentHistory = history.slice(0, 5);

  const getSearchPlaceholder = () => {
    const engine = settings.searchEngine;
    if (engine === 'dragon') return "Search Dragon...";
    if (engine === 'google') return "Search Google...";
    return "Search...";
  };

  const wallpaperUrl = useMemo(() => {
    if (settings.wallpaper?.startsWith('data:')) return settings.wallpaper;
    const preset = presets.find(p => p.id === settings.wallpaper);
    if (preset?.id === 'void') return null;
    return preset ? preset.url : null;
  }, [settings.wallpaper]);

  const handleEditClick = () => {
    if (contextMenu) {
      setEditingItem(contextMenu.shortcut);
      setEditForm({ name: contextMenu.shortcut.name, url: contextMenu.shortcut.url });
      setContextMenu(null);
    }
  };

  const handleDeleteClick = () => {
    if (contextMenu) {
      const updated = speedDial.filter(s => s.id !== contextMenu.shortcut.id);
      updateSpeedDial(updated);
      setContextMenu(null);
    }
  };

  const saveEdit = () => {
    if (editingItem && editForm.name && editForm.url) {
      const updated = speedDial.map(s => 
        s.id === editingItem.id 
          ? { ...s, name: editForm.name, url: editForm.url } 
          : s
      );
      updateSpeedDial(updated);
      setEditingItem(null);
    }
  };

  return (
    <div 
      className="flex flex-col h-full bg-black overflow-y-auto no-scrollbar pb-32 relative"
      onClick={() => {
        setContextMenu(null);
        setShowSuggestions(false);
      }}
    >
      {/* Background */}
      {wallpaperUrl && (
        <>
           <div 
             className="fixed inset-0 z-0 bg-cover bg-center transition-all duration-700 animate-fade-in opacity-40"
             style={{ backgroundImage: `url(${wallpaperUrl})` }}
           />
           <div className="fixed inset-0 z-0 bg-black/60 backdrop-blur-[2px]" />
        </>
      )}

      {/* Voice Search Overlay */}
      {voiceState !== 'idle' && (
        <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center animate-fade-in p-6 text-center">
          <div className="relative mb-8">
            <div className={`absolute inset-0 blur-[60px] rounded-full transition-all duration-500 ${voiceState === 'error' ? 'bg-red-500/30' : 'bg-orange-500/30'}`} />
            <div className={`w-24 h-24 rounded-full border-2 flex items-center justify-center relative transition-all duration-300 ${
              voiceState === 'listening' ? 'border-orange-500 scale-110 shadow-[0_0_30px_rgba(249,115,22,0.4)]' : 
              voiceState === 'error' ? 'border-red-500 bg-red-900/20' : 
              'border-white/20 bg-white/5'
            }`}>
              {voiceState === 'listening' && (
                 <div className="absolute inset-0 bg-orange-500 rounded-full animate-ping opacity-20" />
              )}
              {voiceState === 'error' ? (
                <AlertCircle size={40} className="text-red-500" />
              ) : (
                <Mic size={40} className={`transition-colors ${voiceState === 'listening' ? 'text-orange-500' : 'text-slate-400'}`} />
              )}
            </div>
          </div>

          <h2 className="text-2xl font-black text-white uppercase tracking-tight mb-2">
            {voiceState === 'listening' ? 'Listening...' : 
             voiceState === 'processing' ? 'Processing...' : 
             voiceState === 'success' ? 'Navigating...' : 
             'Connection Failed'}
          </h2>
          
          <div className="h-16 flex items-center justify-center w-full max-w-sm">
             {voiceState === 'error' ? (
               <p className="text-red-400 text-sm font-medium">{voiceError}</p>
             ) : (
               <p className="text-slate-300 text-lg font-medium leading-tight">
                 {interimTranscript || (voiceState === 'listening' ? "Speak now..." : "")}
               </p>
             )}
          </div>

          <button 
            onClick={resetVoice}
            className="mt-12 p-4 rounded-full bg-white/10 hover:bg-white/20 text-white transition-all active:scale-90"
          >
            <X size={24} />
          </button>
        </div>
      )}

      {/* Edit Shortcut Modal */}
      {editingItem && (
        <div 
          className="fixed inset-0 z-[150] flex items-center justify-center bg-black/80 backdrop-blur-md animate-fade-in p-6"
          onClick={(e) => e.stopPropagation()}
        >
          <div className="w-full max-w-sm bg-[#111315] border border-white/10 rounded-[2rem] p-6 shadow-2xl relative">
            <h3 className="text-lg font-black text-white uppercase tracking-wider mb-6 flex items-center gap-2">
              <Edit2 size={18} className="text-orange-500" /> Edit Shortcut
            </h3>
            
            <div className="space-y-4">
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-2">Name</label>
                <input 
                  value={editForm.name}
                  onChange={(e) => setEditForm({ ...editForm, name: e.target.value })}
                  className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-orange-500 focus:outline-none"
                  placeholder="Website Name"
                />
              </div>
              
              <div className="space-y-1">
                <label className="text-[10px] font-bold text-slate-500 uppercase tracking-widest pl-2">URL</label>
                <input 
                  value={editForm.url}
                  onChange={(e) => setEditForm({ ...editForm, url: e.target.value })}
                  className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-sm text-white focus:border-orange-500 focus:outline-none"
                  placeholder="https://example.com"
                />
              </div>

              <div className="flex gap-3 pt-4">
                <button 
                  onClick={() => setEditingItem(null)}
                  className="flex-1 py-3 bg-white/5 hover:bg-white/10 text-slate-400 rounded-xl text-xs font-bold uppercase tracking-widest"
                >
                  Cancel
                </button>
                <button 
                  onClick={saveEdit}
                  className="flex-1 py-3 bg-orange-500 text-white rounded-xl text-xs font-bold uppercase tracking-widest shadow-lg shadow-orange-500/20 active:scale-95 transition-transform"
                >
                  Save
                </button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 flex flex-col items-center pt-16 px-6 relative z-10">
        
        {/* 1. BRANDING CENTERED */}
        <div className="mb-10 text-center animate-fade-in flex flex-col items-center">
          <div className="relative mb-6">
            <div className="absolute -inset-4 bg-orange-600/20 blur-2xl rounded-full" />
            <img 
              src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" 
              alt="Dragon Logo" 
              className="w-24 h-24 rounded-[2rem] object-cover shadow-2xl relative z-10 border border-white/10"
            />
          </div>

          <h1 className="text-[32px] font-black text-white italic tracking-tighter uppercase leading-none mb-2 drop-shadow-lg">
            Dragon Browser
          </h1>
          <p className="text-orange-500 text-[9px] tracking-[0.45em] font-black uppercase opacity-90 drop-shadow-md">
            Make Some Difference
          </p>
        </div>

        {/* 2. SEARCH BAR CENTERED */}
        <div className="w-full max-w-md mb-12 relative z-20">
          <form 
            onSubmit={handleSearchSubmit}
            className="relative bg-[#111315]/90 backdrop-blur-md border border-white/10 rounded-[2rem] px-5 shadow-2xl flex items-center h-[56px] group focus-within:ring-2 focus-within:ring-orange-500/50 transition-all z-20"
          >
            <input 
              ref={inputRef}
              value={mainSearch}
              onChange={(e) => {
                setMainSearch(e.target.value);
                setShowSuggestions(true);
              }}
              onFocus={() => setShowSuggestions(true)}
              placeholder={getSearchPlaceholder()}
              className="bg-transparent flex-1 outline-none text-base text-white placeholder-slate-400 font-medium px-2"
              autoCapitalize="off"
              autoComplete="off"
            />
            
            <div className="flex items-center gap-2">
              {isLoading && (
                <Loader2 className="w-4 h-4 text-orange-500 animate-spin" />
              )}
              <button 
                type="button" 
                onClick={startListening} 
                className={`p-2 transition-all rounded-full hover:bg-white/5 active:scale-90 text-slate-400 hover:text-white`}
                title="Voice Search"
              >
                <Mic size={18} />
              </button>
            </div>
          </form>

          {/* Search Suggestions Dropdown */}
          {showSuggestions && suggestions.length > 0 && (
            <div className="absolute top-[64px] left-0 right-0 bg-[#111315]/95 backdrop-blur-xl border border-white/10 rounded-[1.5rem] shadow-2xl overflow-hidden animate-fade-in z-10">
              <div className="px-5 py-3 text-[10px] font-black text-slate-500 uppercase tracking-widest bg-white/5 flex items-center gap-2">
                <Sparkles size={12} className="text-orange-500" /> Suggested
              </div>
              {suggestions.map((s, idx) => (
                <button
                  key={idx}
                  className="w-full text-left px-5 py-3.5 hover:bg-white/10 flex items-center gap-4 transition-colors group border-b border-white/5 last:border-0"
                  onMouseDown={(e) => {
                    e.preventDefault(); // Prevent blur
                    setMainSearch(s);
                    onNavigate(normalizeUrl(s, settings.searchEngine));
                    setShowSuggestions(false);
                  }}
                >
                  {s.includes('.') && !s.includes(' ') ? (
                    <Globe size={16} className="text-cyan-500 group-hover:text-white transition-colors" />
                  ) : (
                    <Search size={16} className="text-slate-500 group-hover:text-orange-500 transition-colors" />
                  )}
                  <span className="text-sm font-medium text-slate-200 group-hover:text-white truncate">{s}</span>
                </button>
              ))}
            </div>
          )}
        </div>

        {/* 3. DASHBOARD SHORTCUTS */}
        <div className="w-full max-w-sm mb-14 relative z-0">
          <div className="flex items-center gap-2 mb-6 px-2 opacity-100">
            <div className="w-0.5 h-3 bg-orange-500 mr-2" />
            <h3 className="text-[9px] font-black text-white uppercase tracking-[0.3em]">Dashboard</h3>
          </div>

          <div className="grid grid-cols-4 gap-y-8 gap-x-4 animate-fade-in">
            {shortcuts.map((site) => (
              <div key={site.id} className="relative flex flex-col items-center gap-2">
                <button 
                  onClick={() => onNavigate(normalizeUrl(site.url))}
                  onPointerDown={(e) => startLongPress(site, e.clientX, e.clientY)}
                  onPointerUp={cancelLongPress}
                  onPointerLeave={cancelLongPress}
                  onContextMenu={(e) => e.preventDefault()}
                  className="w-14 h-14 bg-white/95 backdrop-blur-sm rounded-[1.2rem] flex items-center justify-center shadow-xl transition-transform active:scale-90 relative overflow-hidden group border border-white/10"
                >
                  <img 
                    src={`https://www.google.com/s2/favicons?sz=64&domain=${getCleanDomain(site.url)}`} 
                    alt={site.name}
                    className="w-7 h-7 object-contain relative z-10"
                    onError={(e) => {
                      const img = e.target as HTMLImageElement;
                      img.style.display = 'none';
                      img.parentElement!.innerHTML = '<div class="text-slate-900"><Globe size={24} /></div>';
                    }}
                  />
                  <div className="absolute inset-0 bg-gradient-to-br from-white via-white to-slate-200 opacity-100 z-0" />
                </button>
                <span className="text-[10px] font-bold text-slate-300 truncate w-16 text-center tracking-tight shadow-black drop-shadow-md">{site.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* RECENTLY VIEWED */}
        {recentHistory.length > 0 && (
          <div className="w-full max-w-sm animate-fade-in relative z-0">
            <div className="flex items-center justify-between mb-4 px-2">
              <div className="flex items-center gap-2 text-slate-400">
                <Clock size={12} className="text-orange-500" />
                <h3 className="text-[9px] font-black uppercase tracking-[0.3em]">Recently Viewed</h3>
              </div>
              
              <div className="flex items-center gap-3">
                 <button 
                  onClick={() => setIsHistoryManageMode(!isHistoryManageMode)}
                  className="text-[9px] font-black uppercase tracking-widest text-slate-500 hover:text-white"
                 >
                   {isHistoryManageMode ? 'Done' : 'Manage'}
                 </button>
                 {isHistoryManageMode && (
                   <button onClick={clearHistory} className="text-[9px] font-black uppercase tracking-widest text-red-500">
                     Clear
                   </button>
                 )}
              </div>
            </div>

            <div className="bg-[#111315]/80 backdrop-blur-md rounded-[1.5rem] border border-white/5 overflow-hidden shadow-xl">
              {recentHistory.map((h, idx) => (
                <div key={h.id} className="relative">
                  <button 
                    onClick={() => !isHistoryManageMode && onNavigate(h.url)}
                    className={`w-full flex items-center gap-4 p-4 hover:bg-white/5 transition-all text-left group ${idx !== recentHistory.length - 1 ? 'border-b border-white/5' : ''}`}
                  >
                    <div className="w-8 h-8 rounded-lg bg-black flex items-center justify-center border border-white/5 shrink-0">
                      <img 
                        src={`https://www.google.com/s2/favicons?sz=64&domain=${getCleanDomain(h.url)}`}
                        className="w-4 h-4 object-contain opacity-80"
                        alt=""
                        onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }}
                      />
                    </div>
                    <div className="flex-1 min-w-0">
                      <h4 className="text-[11px] font-bold text-slate-300 truncate">{h.title || 'Untitled'}</h4>
                      <span className="text-[9px] text-slate-600 truncate block mt-0.5">{h.url}</span>
                    </div>
                    
                    {isHistoryManageMode && (
                      <div 
                        onClick={(e) => { e.stopPropagation(); removeHistoryItem(h.id); }}
                        className="p-2 text-red-500"
                      >
                        <Trash2 size={14} />
                      </div>
                    )}
                  </button>
                </div>
              ))}
            </div>
          </div>
        )}

        <div className="h-20" /> {/* Spacer */}
      </div>

      {/* CONTEXT MENU */}
      {contextMenu && (
        <div 
          className="fixed z-[100] bg-[#111315] border border-white/10 rounded-2xl p-2 shadow-2xl animate-fade-in w-48"
          style={{ top: contextMenu.y, left: contextMenu.x }}
          onClick={(e) => e.stopPropagation()}
        >
          <button 
            onClick={() => { onOpenInNewTab(contextMenu.shortcut.url); setContextMenu(null); }}
            className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 rounded-xl w-full text-left"
          >
            <Layers size={14} className="text-orange-500" />
            <span className="text-[10px] font-bold text-white uppercase tracking-wider">Open in New Tab</span>
          </button>
          
          <button 
            onClick={handleEditClick}
            className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 rounded-xl w-full text-left"
          >
            <Edit2 size={14} className="text-blue-500" />
            <span className="text-[10px] font-bold text-white uppercase tracking-wider">Edit Shortcut</span>
          </button>

          {!contextMenu.shortcut.isProtected && (
            <button 
              onClick={handleDeleteClick}
              className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 rounded-xl w-full text-left"
            >
              <Trash2 size={14} className="text-red-500" />
              <span className="text-[10px] font-bold text-red-400 uppercase tracking-wider">Remove</span>
            </button>
          )}
        </div>
      )}
    </div>
  );
};
