
import React, { useState, useRef, useMemo, useEffect } from 'react';
import { useDragon, Shortcut } from '../DragonContext';
import { Mic, Clock, Trash2, Globe, Layers, Search, Loader2, X, AlertCircle, Edit2, Plus, Pencil, Menu } from 'lucide-react';
import { normalizeUrl } from '../utils/urlUtils';
import { useVoiceSearch } from '../hooks/useVoiceSearch';
import { BrowserViewMode } from '../types';

interface NewTabPageProps {
  onNavigate: (url: string) => void;
  onOpenInNewTab: (url: string) => void;
  onTriggerSearch: () => void;
}

const presets = [
    { id: 'default', name: 'Dragon Default', url: 'https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg' },
    { id: 'void', name: 'Plain Black', url: '' },
    { id: 'cyber', name: 'Cyber Grid', url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1000' },
    { id: 'abyssal', name: 'Deep Black', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=1000' },
];

export const NewTabPage: React.FC<NewTabPageProps> = ({ onNavigate, onOpenInNewTab, onTriggerSearch }) => {
  const { speedDial, settings, history, clearHistory, removeHistoryItem, updateSpeedDial, addShortcut, removeShortcut, setViewMode } = useDragon();
  const [contextMenu, setContextMenu] = useState<{ shortcut: Shortcut; x: number; y: number } | null>(null);
  
  const [modalConfig, setModalConfig] = useState<{ mode: 'add' | 'edit'; data?: Shortcut } | null>(null);
  const [formData, setFormData] = useState({ name: '', url: '' });
  const [isChecking, setIsChecking] = useState(false);

  const longPressTimer = useRef<number | null>(null);

  const { 
    voiceState, 
    interimTranscript, 
    startListening, 
    reset: resetVoice 
  } = useVoiceSearch((transcript) => {
    const targetUrl = normalizeUrl(transcript, settings.searchEngine);
    onNavigate(targetUrl);
  });

  const handleSearchPlaceholderClick = () => {
    onTriggerSearch();
  };

  const getCleanDomain = (url: string) => {
    try {
      const u = url.startsWith('http') ? url : `https://${url}`;
      return new URL(u).hostname.replace('www.', '');
    } catch {
      return url.replace(/^(?:https?:\/\/)?(?:www\.)?/i, "").split('/')[0];
    }
  };

  const startLongPress = (shortcut: Shortcut, x: number, y: number) => {
    longPressTimer.current = window.setTimeout(() => {
      setContextMenu({ shortcut, x, y });
      if (navigator.vibrate) navigator.vibrate(40);
    }, 600);
  };

  const cancelLongPress = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const MAX_SLOTS = 8;
  const shortcuts = speedDial.slice(0, MAX_SLOTS);
  const recentHistory = history.slice(0, 5);

  const getSearchPlaceholder = () => {
    const engine = settings.searchEngine;
    if (engine === 'dragon') return "Search with Dragon...";
    if (engine === 'google') return "Search Google...";
    return "Search...";
  };

  const getEngineLogo = () => {
    switch (settings.searchEngine) {
      case 'dragon':
        return <img src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" className="w-6 h-6 rounded-full object-cover" alt="Dragon" />;
      case 'google':
        return (
          <svg viewBox="0 0 24 24" className="w-6 h-6">
            <path fill="#4285F4" d="M22.56 12.25c0-.78-.07-1.53-.2-2.25H12v4.26h5.92c-.26 1.37-1.04 2.53-2.21 3.31v2.77h3.57c2.08-1.92 3.28-4.74 3.28-8.09z" />
            <path fill="#34A853" d="M12 23c2.97 0 5.46-.98 7.28-2.66l-3.57-2.77c-.98.66-2.23 1.06-3.71 1.06-2.86 0-5.29-1.93-6.16-4.53H2.18v2.84C3.99 20.53 7.7 23 12 23z" />
            <path fill="#FBBC05" d="M5.84 14.09c-.22-.66-.35-1.36-.35-2.09s.13-1.43.35-2.09V7.07H2.18C1.43 8.55 1 10.22 1 12s.43 3.45 1.18 4.93l3.66-2.84z" />
            <path fill="#EA4335" d="M12 5.38c1.62 0 3.06.56 4.21 1.66l3.15-3.15C17.45 2.09 14.97 1 12 1 7.7 1 3.99 3.47 2.18 7.07l3.66 2.84c.87-2.6 3.3-4.53 6.16-4.53z" />
          </svg>
        );
      case 'bing':
        return (
          <svg viewBox="0 0 24 24" className="w-6 h-6">
            <path fill="#008373" d="M15.44 2.1L8.5 4.54V17.08L5.56 15.42V5.5L2 6.75V19.75L8.5 22.5L18.44 16.9V13.8L15.44 12.35V2.1H15.44Z" />
          </svg>
        );
      default:
        return <Search size={22} className="text-orange-500" />;
    }
  };

  const wallpaperUrl = useMemo(() => {
    if (settings.wallpaper?.startsWith('data:')) return settings.wallpaper;
    const preset = presets.find(p => p.id === settings.wallpaper);
    if (preset?.id === 'void') return null;
    return preset ? preset.url : null;
  }, [settings.wallpaper]);

  const handleEditClick = () => {
    if (contextMenu) {
      setFormData({ name: contextMenu.shortcut.name, url: contextMenu.shortcut.url });
      setModalConfig({ mode: 'edit', data: contextMenu.shortcut });
      setContextMenu(null);
    }
  };

  const handleAddClick = () => {
    setFormData({ name: '', url: '' });
    setModalConfig({ mode: 'add' });
  };

  const handleDeleteClick = () => {
    if (contextMenu) {
      removeShortcut(contextMenu.shortcut.id);
      setContextMenu(null);
    }
  };

  const handleSave = async () => {
    if (!formData.name || !formData.url) return;
    setIsChecking(true);
    let finalUrl = formData.url.trim();
    if (!/^https?:\/\//i.test(finalUrl)) finalUrl = 'https://' + finalUrl;

    if (modalConfig?.mode === 'edit' && modalConfig.data) {
      const updated = speedDial.map(s => 
        s.id === modalConfig.data!.id ? { ...s, name: formData.name, url: finalUrl } : s
      );
      updateSpeedDial(updated);
    } else if (modalConfig?.mode === 'add') {
      addShortcut(formData.name, finalUrl);
    }
    
    setIsChecking(false);
    setModalConfig(null);
  };

  return (
    <div 
      className="flex flex-col h-full bg-black overflow-y-auto no-scrollbar pb-32 relative"
      onClick={() => setContextMenu(null)}
    >
      {wallpaperUrl && (
        <>
           <div 
             className="fixed inset-0 z-0 bg-cover bg-center transition-all duration-700 animate-fade-in opacity-40"
             style={{ backgroundImage: `url(${wallpaperUrl})` }}
           />
           <div className="fixed inset-0 z-0 bg-black/60 backdrop-blur-[2px]" />
        </>
      )}

      {voiceState !== 'idle' && (
        <div className="fixed inset-0 z-[100] bg-black/90 backdrop-blur-xl flex flex-col items-center justify-center animate-fade-in p-6 text-center">
          <h2 className="text-2xl font-black text-white uppercase mb-4">{voiceState.toUpperCase()}</h2>
          <p className="text-slate-300">{interimTranscript || "Listening..."}</p>
          <button onClick={resetVoice} className="mt-8 p-4 bg-white/10 rounded-full text-white">
            <X size={24} />
          </button>
        </div>
      )}

      {modalConfig && (
        <div className="fixed inset-0 z-[150] flex items-center justify-center bg-black/80 backdrop-blur-md p-6" onClick={(e) => e.stopPropagation()}>
          <div className="w-full max-w-sm bg-[#111315] border border-white/10 rounded-[2rem] p-6 shadow-2xl">
            <h3 className="text-lg font-black text-white uppercase mb-6">Shortcut Settings</h3>
            <div className="space-y-4">
              <input value={formData.name} onChange={(e) => setFormData({ ...formData, name: e.target.value })} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white" placeholder="Website Name" />
              <input value={formData.url} onChange={(e) => setFormData({ ...formData, url: e.target.value })} className="w-full bg-black/50 border border-white/10 rounded-xl px-4 py-3 text-white" placeholder="URL (e.g. google.com)" />
              <div className="flex gap-3">
                <button onClick={() => setModalConfig(null)} className="flex-1 py-3 bg-white/5 text-slate-400 rounded-xl font-bold uppercase tracking-widest">Cancel</button>
                <button onClick={handleSave} className="flex-1 py-3 bg-dragon-ember text-white rounded-xl font-bold uppercase tracking-widest shadow-lg">Save</button>
              </div>
            </div>
          </div>
        </div>
      )}

      <div className="flex-1 flex flex-col items-center pt-24 px-6 relative z-10">
        <div className="mb-10 text-center flex flex-col items-center">
          <div className="relative mb-6">
            <div className="absolute -inset-4 bg-orange-600/20 blur-2xl rounded-full" />
            <img src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" alt="Logo" className="w-24 h-24 rounded-[2rem] object-cover shadow-2xl relative z-10 border border-white/10" />
          </div>
          <h1 className="text-[32px] font-black text-white italic tracking-tighter uppercase leading-none mb-2">Dragon Browser</h1>
          <p className="text-orange-500 text-[9px] tracking-[0.45em] font-black uppercase opacity-90">Faster. Smarter. Private.</p>
        </div>

        <div className="w-full max-w-md mb-12 relative z-20">
          <div onClick={handleSearchPlaceholderClick} className="relative bg-[#111315]/90 backdrop-blur-md border border-white/10 rounded-[2rem] px-6 shadow-2xl flex items-center h-[60px] group hover:border-orange-500/50 cursor-text transition-all z-20">
            <div className="mr-4 shrink-0">{getEngineLogo()}</div>
            <span className="flex-1 text-base text-slate-400 font-medium select-none">{getSearchPlaceholder()}</span>
            <button onClick={(e) => { e.stopPropagation(); startListening(); }} className="p-2 text-slate-400 hover:text-white"><Mic size={18} /></button>
          </div>
        </div>

        <div className="w-full max-w-sm mb-14 relative z-0">
          <div className="grid grid-cols-4 gap-y-8 gap-x-4">
            {shortcuts.map((site) => (
              <div key={site.id} className="relative flex flex-col items-center gap-2">
                <button 
                  onClick={() => onNavigate(normalizeUrl(site.url))}
                  onPointerDown={(e) => startLongPress(site, e.clientX, e.clientY)}
                  onPointerUp={cancelLongPress}
                  className="w-14 h-14 bg-white rounded-[1.2rem] flex items-center justify-center shadow-xl transition-transform active:scale-90"
                >
                  <img src={`https://www.google.com/s2/favicons?sz=64&domain=${getCleanDomain(site.url)}`} alt={site.name} className="w-7 h-7" />
                </button>
                <span className="text-[10px] font-bold text-slate-300 truncate w-16 text-center">{site.name}</span>
              </div>
            ))}
            {shortcuts.length < MAX_SLOTS && (
                <div className="flex flex-col items-center gap-2">
                    <button onClick={handleAddClick} className="w-14 h-14 bg-white/5 border border-dashed border-white/20 rounded-[1.2rem] flex items-center justify-center shadow-xl"><Plus size={24} className="text-slate-500" /></button>
                    <span className="text-[10px] font-bold text-slate-500">Add</span>
                </div>
            )}
          </div>
        </div>

        {recentHistory.length > 0 && (
          <div className="w-full max-w-sm relative z-0">
            <div className="flex items-center justify-between mb-4 px-2 text-slate-400">
              <h3 className="text-[9px] font-black uppercase tracking-[0.3em]">Recent History</h3>
              <button onClick={clearHistory} className="text-[9px] font-black uppercase">Clear All</button>
            </div>
            <div className="bg-[#111315]/80 backdrop-blur-md rounded-[1.5rem] border border-white/5 overflow-hidden shadow-xl">
              {recentHistory.map((h, idx) => (
                <button key={h.id} onClick={() => onNavigate(h.url)} className={`w-full flex items-center gap-4 p-4 hover:bg-white/5 text-left ${idx !== recentHistory.length - 1 ? 'border-b border-white/5' : ''}`}>
                  <div className="w-8 h-8 rounded-lg bg-black flex items-center justify-center border border-white/5 shrink-0">
                    <img src={`https://www.google.com/s2/favicons?sz=64&domain=${getCleanDomain(h.url)}`} className="w-4 h-4" alt="" />
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-[11px] font-bold text-slate-300 truncate">{h.title || 'Untitled Site'}</h4>
                    <span className="text-[9px] text-slate-600 truncate block">{h.url}</span>
                  </div>
                </button>
              ))}
            </div>
          </div>
        )}
      </div>

      {contextMenu && (
        <div className="fixed z-[100] bg-[#111315] border border-white/10 rounded-2xl p-2 shadow-2xl animate-fade-in w-48" style={{ top: contextMenu.y, left: contextMenu.x }} onClick={(e) => e.stopPropagation()}>
          <button onClick={() => { onOpenInNewTab(contextMenu.shortcut.url); setContextMenu(null); }} className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 rounded-xl w-full text-left text-white text-[10px] font-bold uppercase tracking-wider"><Layers size={14} className="text-orange-500" /> Open New Tab</button>
          <button onClick={handleEditClick} className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 rounded-xl w-full text-left text-white text-[10px] font-bold uppercase tracking-wider"><Edit2 size={14} className="text-blue-500" /> Edit Shortcut</button>
          <button onClick={handleDeleteClick} className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 rounded-xl w-full text-left text-red-400 text-[10px] font-bold uppercase tracking-wider"><Trash2 size={14} /> Delete</button>
        </div>
      )}
    </div>
  );
};
