
import React, { useState, useRef, useMemo } from 'react';
import { useDragon } from '../DragonContext';
import { Monitor, Mic, Clock, Trash2, Globe, Layers } from 'lucide-react';
import { normalizeUrl } from '../utils/urlUtils';
import { useVoiceSearch } from '../hooks/useVoiceSearch';

interface NewTabPageProps {
  onNavigate: (url: string) => void;
  onOpenInNewTab: (url: string) => void;
}

const presets = [
    { id: 'default', name: 'Dragon Default', url: 'https://images.unsplash.com/photo-1614850523296-d8c1af93d400?q=80&w=1000' },
    { id: 'void', name: 'Void Black', url: '' },
    { id: 'cyber', name: 'Cyber Grid', url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1000' },
    { id: 'abyssal', name: 'Abyssal Black', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=1000' },
    { id: 'magma', name: 'Magma Flow', url: 'https://images.unsplash.com/photo-1518558997970-4ddc236affcd?q=80&w=1000' },
    { id: 'nebula', name: 'Cosmic Nebula', url: 'https://images.unsplash.com/photo-1534796636912-3b95b3ab5986?q=80&w=1000' },
    { id: 'zen', name: 'Zen Garden', url: 'https://images.unsplash.com/photo-1528353518132-131198096b63?q=80&w=1000' },
    { id: 'grid', name: 'Retro Grid', url: 'https://images.unsplash.com/photo-1550751827-4bd374c3f58b?q=80&w=1000' },
    { id: 'sky', name: 'Dream Sky', url: 'https://images.unsplash.com/photo-1499002238440-d264edd596ec?q=80&w=1000' },
    { id: 'tokyo', name: 'Neon Tokyo', url: 'https://images.unsplash.com/photo-1540959733332-eab4deabeeaf?q=80&w=1000' },
    { id: 'aurora', name: 'Northern Lights', url: 'https://images.unsplash.com/photo-1531366936337-7c912a4589a7?q=80&w=1000' }
];

export const NewTabPage: React.FC<NewTabPageProps> = ({ onNavigate, onOpenInNewTab }) => {
  const { speedDial, settings, updateSettings, history, clearHistory, removeHistoryItem } = useDragon();
  const [mainSearch, setMainSearch] = useState('');
  const [isHistoryManageMode, setIsHistoryManageMode] = useState(false);
  
  // Context Menu State
  const [contextMenu, setContextMenu] = useState<{ url: string; x: number; y: number } | null>(null);
  const longPressTimer = useRef<number | null>(null);

  const { isListening, startListening } = useVoiceSearch((transcript) => {
    setMainSearch(transcript);
    onNavigate(normalizeUrl(transcript, settings.searchEngine));
  });

  const handleSearchSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!mainSearch.trim()) return;
    onNavigate(normalizeUrl(mainSearch, settings.searchEngine));
  };

  const getCleanDomain = (url: string) => {
    try {
      const u = url.startsWith('http') ? url : `https://${url}`;
      return new URL(u).hostname.replace('www.', '');
    } catch {
      return url.replace(/^(?:https?:\/\/)?(?:www\.)?/i, "").split('/')[0];
    }
  };

  // Long Press Handlers
  const startLongPress = (url: string, x: number, y: number) => {
    longPressTimer.current = window.setTimeout(() => {
      setContextMenu({ url, x, y });
      if (navigator.vibrate) navigator.vibrate(40);
    }, 600);
  };

  const cancelLongPress = () => {
    if (longPressTimer.current) {
      clearTimeout(longPressTimer.current);
      longPressTimer.current = null;
    }
  };

  const MAX_SLOTS = 8;
  const shortcuts = speedDial.slice(0, MAX_SLOTS);
  const recentHistory = history.slice(0, 5);

  const getSearchPlaceholder = () => {
    const engine = settings.searchEngine;
    if (engine === 'dragon') return "Search Dragon...";
    if (engine === 'google') return "Search Google...";
    if (engine === 'bing') return "Search Bing...";
    return "Search...";
  };

  const wallpaperUrl = useMemo(() => {
    if (settings.wallpaper?.startsWith('data:')) return settings.wallpaper;
    const preset = presets.find(p => p.id === settings.wallpaper);
    if (preset?.id === 'void') return null; // Explicit no wallpaper
    return preset ? preset.url : null;
  }, [settings.wallpaper]);

  return (
    <div 
      className="flex flex-col h-full bg-black overflow-y-auto no-scrollbar pb-32 relative"
      onClick={() => setContextMenu(null)}
    >
      {/* Dynamic Background */}
      {wallpaperUrl && (
        <>
           <div 
             className="fixed inset-0 z-0 bg-cover bg-center transition-all duration-700 animate-fade-in"
             style={{ backgroundImage: `url(${wallpaperUrl})` }}
           />
           <div className="fixed inset-0 z-0 bg-black/60 backdrop-blur-[2px]" />
        </>
      )}

      <div className="flex-1 flex flex-col items-center pt-10 px-6 relative z-10">
        
        {/* Branding Section */}
        <div className="mb-10 text-center animate-fade-in">
          <div className="relative inline-block mb-6">
            <div className="absolute -inset-4 bg-orange-600/5 blur-3xl rounded-full" />
            <img 
              src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" 
              alt="Dragon Logo" 
              className="w-24 h-24 rounded-[2rem] object-cover shadow-2xl relative z-10 border border-white/10"
            />
          </div>

          <h1 className="text-[38px] font-black text-white italic tracking-tighter uppercase leading-none mb-1 drop-shadow-lg">
            Dragon Browser
          </h1>
          <p className="text-orange-500 text-[9px] tracking-[0.45em] font-black uppercase opacity-90 drop-shadow-md">
            Make Some Difference
          </p>
        </div>

        {/* Search Bar Area */}
        <div className="w-full max-w-md mb-12">
          <form 
            onSubmit={handleSearchSubmit}
            className="relative bg-[#111315]/80 backdrop-blur-md border border-white/10 rounded-full px-5 shadow-2xl flex items-center h-[58px]"
          >
            <input 
              value={mainSearch}
              onChange={(e) => setMainSearch(e.target.value)}
              placeholder={getSearchPlaceholder()}
              className="bg-transparent flex-1 outline-none text-base text-white placeholder-slate-400 font-medium px-1"
            />
            
            <div className="flex items-center gap-1">
              <button 
                type="button" 
                onClick={() => updateSettings({ dragonStrength: !settings.dragonStrength })} 
                className={`p-2 transition-colors ${settings.dragonStrength ? 'text-orange-500' : 'text-slate-400 hover:text-white'}`}
              >
                <Monitor size={20} />
              </button>
              <button 
                type="button" 
                onClick={startListening} 
                className={`p-2 transition-all ${isListening ? 'text-orange-500 animate-pulse' : 'text-slate-400 hover:text-white'}`}
              >
                <Mic size={20} />
              </button>
            </div>
          </form>
        </div>

        {/* Dashboard Section */}
        <div className="w-full max-w-sm mb-14">
          <div className="flex items-center mb-7 px-1">
            <div className="w-1 h-3 bg-orange-600 mr-3 rounded-full" />
            <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-[0.3em] drop-shadow-md">Dashboard</h3>
          </div>

          <div className="grid grid-cols-4 gap-y-12 gap-x-4">
            {shortcuts.map((site) => (
              <div key={site.id} className="relative flex flex-col items-center gap-3">
                <button 
                  onClick={() => onNavigate(normalizeUrl(site.url))}
                  onPointerDown={(e) => startLongPress(site.url, e.clientX, e.clientY)}
                  onPointerUp={cancelLongPress}
                  onPointerLeave={cancelLongPress}
                  onContextMenu={(e) => e.preventDefault()}
                  className="w-16 h-16 bg-white/90 backdrop-blur-sm rounded-full flex items-center justify-center shadow-2xl transition-all active:scale-90 overflow-hidden ring-4 ring-white/5 hover:ring-white/20"
                >
                  <img 
                    src={`https://www.google.com/s2/favicons?sz=128&domain=${getCleanDomain(site.url)}`} 
                    alt={site.name}
                    className="w-8 h-8 object-contain"
                    onError={(e) => {
                      const img = e.target as HTMLImageElement;
                      img.style.display = 'none';
                      img.parentElement!.innerHTML = '<div class="text-slate-900"><Globe size={28} /></div>';
                    }}
                  />
                </button>
                <span className="text-[11px] font-bold text-slate-300 truncate w-20 text-center tracking-tight drop-shadow-md">{site.name}</span>
              </div>
            ))}
          </div>
        </div>

        {/* Recently Viewed Section */}
        <div className="w-full max-w-sm animate-fade-in">
          <div className="flex items-center justify-between mb-5 px-1">
            <div className="flex items-center gap-2.5 text-slate-300">
              <Clock size={14} className="text-orange-500" />
              <h3 className="text-[10px] font-black uppercase tracking-[0.3em] drop-shadow-md">Recently Viewed</h3>
            </div>
            
            <div className="flex items-center gap-4">
              <button 
                onClick={() => setIsHistoryManageMode(!isHistoryManageMode)}
                className={`px-4 py-1.5 border rounded-lg text-[9px] font-black uppercase tracking-widest transition-all ${isHistoryManageMode ? 'bg-white text-black border-white shadow-lg' : 'border-slate-600 bg-black/40 text-slate-400 hover:text-white hover:border-slate-400'}`}
              >
                Manage
              </button>
              {recentHistory.length > 0 && (
                <button 
                  onClick={() => { clearHistory(); setIsHistoryManageMode(false); }}
                  className="flex items-center gap-1.5 text-slate-400 hover:text-red-500 transition-all group"
                >
                  <Trash2 size={14} className="group-hover:scale-110 transition-transform" />
                  <span className="text-[9px] font-black uppercase tracking-[0.2em]">Clear All</span>
                </button>
              )}
            </div>
          </div>

          <div className="space-y-3">
            {recentHistory.length === 0 ? (
              <div className="p-12 bg-[#0a0a0a]/60 backdrop-blur-md rounded-[2.5rem] border border-white/10 flex flex-col items-center justify-center gap-3">
                <div className="w-12 h-12 rounded-full bg-white/5 flex items-center justify-center opacity-20">
                  <Clock size={20} className="text-slate-400" />
                </div>
                <p className="text-[10px] font-black text-slate-400 uppercase tracking-[0.4em] italic">No Recent Activity</p>
              </div>
            ) : (
              <div className="bg-[#0a0a0a]/80 backdrop-blur-md rounded-[2.5rem] border border-white/10 overflow-hidden shadow-2xl">
                {recentHistory.map((h, idx) => (
                  <div key={h.id} className="relative">
                    <button 
                      onClick={() => !isHistoryManageMode && onNavigate(h.url)}
                      onPointerDown={(e) => !isHistoryManageMode && startLongPress(h.url, e.clientX, e.clientY)}
                      onPointerUp={cancelLongPress}
                      onPointerLeave={cancelLongPress}
                      onContextMenu={(e) => e.preventDefault()}
                      className={`w-full flex items-center gap-5 p-5 hover:bg-white/5 transition-all group ${idx !== recentHistory.length - 1 ? 'border-b border-white/5' : ''}`}
                    >
                      <div className="w-12 h-12 rounded-2xl bg-black flex items-center justify-center border border-white/5 group-hover:scale-105 transition-transform shrink-0 overflow-hidden shadow-inner">
                        <img 
                          src={`https://www.google.com/s2/favicons?sz=64&domain=${getCleanDomain(h.url)}`}
                          className="w-6 h-6 object-contain"
                          alt=""
                          onError={(e) => {
                            const img = e.target as HTMLImageElement;
                            img.style.display = 'none';
                            img.parentElement!.innerHTML = '<div class="text-slate-600"><Globe size={20} /></div>';
                          }}
                        />
                      </div>
                      <div className="flex-1 text-left min-w-0">
                        <h4 className="text-[12px] font-black text-slate-200 truncate group-hover:text-orange-500 transition-colors leading-none tracking-tight">{h.title || h.url}</h4>
                        <span className="text-[9px] font-bold text-slate-500 truncate block mt-2 leading-none">{h.url}</span>
                      </div>
                      
                      {isHistoryManageMode && (
                        <button 
                          onClick={(e) => { e.stopPropagation(); removeHistoryItem(h.id); }}
                          className="p-3 bg-red-500/10 text-red-500 rounded-xl hover:bg-red-500 transition-all active:scale-90"
                        >
                          <Trash2 size={16} />
                        </button>
                      )}
                    </button>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>

        {/* Footer Credit */}
        <div className="mt-16 pb-8 text-center opacity-30 pointer-events-none">
          <p className="text-[9px] font-black text-slate-500 tracking-[0.5em] uppercase italic drop-shadow-md">
            Architect: Amudhan T
          </p>
        </div>
      </div>

      {/* DASHBOARD CONTEXT MENU (Long Press) */}
      {contextMenu && (
        <div 
          className="fixed z-[100] bg-[#0d0f11]/95 backdrop-blur-xl border border-white/10 rounded-[1.8rem] p-2 shadow-[0_25px_70px_rgba(0,0,0,0.8)] animate-fade-in"
          style={{ 
            top: Math.min(contextMenu.y, window.innerHeight - 100), 
            left: Math.min(contextMenu.x, window.innerWidth - 180) 
          }}
          onClick={(e) => e.stopPropagation()}
        >
          <button 
            onClick={() => {
              onOpenInNewTab(contextMenu.url);
              setContextMenu(null);
            }}
            className="flex items-center gap-3 px-4 py-3 hover:bg-white/5 rounded-[1.4rem] transition-all group active:scale-95 text-left w-full min-w-[160px]"
          >
            <div className="p-2 bg-orange-600/10 rounded-xl text-orange-500 group-hover:bg-orange-600 group-hover:text-white transition-all">
              <Layers size={14} />
            </div>
            <div>
              <span className="text-[11px] font-black uppercase tracking-tight block text-slate-200">Open in New Tab</span>
              <span className="text-[7px] text-slate-500 font-bold uppercase tracking-widest block">Standard Background Session</span>
            </div>
          </button>
        </div>
      )}
    </div>
  );
};
