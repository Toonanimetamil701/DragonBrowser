
import React from 'react';
import { useDragon } from '../DragonContext';
import { 
  X, Shield, Lock, Globe, Video, Mic, MapPin, 
  Code, Cookie, Square, RotateCcw, ShieldCheck, ExternalLink
} from 'lucide-react';
import { SitePermissions } from '../types';

interface SiteSettingsPopupProps {
  isOpen: boolean;
  onClose: () => void;
  url: string;
}

export const SiteSettingsPopup: React.FC<SiteSettingsPopupProps> = ({ isOpen, onClose, url }) => {
  const { getSitePermissions, updateSitePermissions, resetSitePermissions } = useDragon();
  
  if (!isOpen) return null;

  let domain = "Local Fragment";
  try { domain = new URL(url).hostname; } catch (e) {}
  
  const permissions = getSitePermissions(url);

  const togglePermission = (key: keyof SitePermissions) => {
    updateSitePermissions(url, { [key]: !permissions[key] });
  };

  const items: { key: keyof SitePermissions; label: string; sub: string; icon: React.ReactNode }[] = [
    { key: 'javascript', label: 'JavaScript', sub: 'Enable core interaction scripts', icon: <Code size={18} /> },
    { key: 'cookies', label: 'Cookies & Storage', sub: 'Save sessions and site data', icon: <Cookie size={18} /> },
    { key: 'location', label: 'Location Access', sub: 'Share precise coordinates', icon: <MapPin size={18} /> },
    { key: 'camera', label: 'Camera', sub: 'Allow hardware video capture', icon: <Video size={18} /> },
    { key: 'microphone', label: 'Microphone', sub: 'Allow hardware audio capture', icon: <Mic size={18} /> },
    { key: 'popups', label: 'Pop-ups & Redirects', sub: 'Allow new windows and dialogs', icon: <Square size={18} /> },
  ];

  return (
    <div className="fixed inset-0 z-[250] flex items-end sm:items-center justify-center sm:p-4 animate-fade-in">
      <div className="absolute inset-0 bg-black/80 backdrop-blur-md" onClick={onClose} />
      
      <div className="relative w-full max-w-sm bg-[#0a0a0a] rounded-t-[2.5rem] sm:rounded-[2.5rem] border border-white/10 shadow-2xl overflow-hidden flex flex-col max-h-[85vh] ring-1 ring-white/5">
        {/* Header */}
        <div className="p-8 pb-4 border-b border-white/5 bg-black/40">
          <div className="flex items-center gap-4 mb-1">
            <div className="w-12 h-12 rounded-2xl bg-dragon-ember/10 flex items-center justify-center border border-dragon-ember/20 shadow-lg shadow-dragon-ember/10">
              <ShieldCheck size={26} className="text-dragon-ember" />
            </div>
            <div className="flex-1 min-w-0">
              <h3 className="text-lg font-black text-white uppercase tracking-tight leading-tight">Site Security</h3>
              <p className="text-[10px] font-black text-dragon-cyan uppercase tracking-widest truncate">{domain}</p>
            </div>
            <button onClick={onClose} className="p-3 bg-white/5 hover:bg-white/10 rounded-2xl text-slate-400 transition-all active:scale-90">
              <X size={20} />
            </button>
          </div>
        </div>

        {/* Permissions List */}
        <div className="flex-1 p-4 space-y-2 overflow-y-auto no-scrollbar">
          <div className="px-4 py-2">
             <span className="text-[9px] font-black text-slate-500 uppercase tracking-[0.3em]">Access Permissions</span>
          </div>
          
          {items.map((item) => (
            <button
              key={item.key}
              onClick={() => togglePermission(item.key)}
              className={`w-full flex items-center justify-between p-5 rounded-2xl transition-all border group ${permissions[item.key] ? 'bg-white/5 border-white/10' : 'bg-transparent border-transparent opacity-60'}`}
            >
              <div className="flex items-center gap-4">
                <div className={`p-3 rounded-xl transition-all duration-300 ${permissions[item.key] ? 'text-dragon-cyan bg-dragon-cyan/10' : 'text-slate-600 bg-white/5'}`}>
                  {item.icon}
                </div>
                <div className="text-left">
                  <span className={`text-sm font-black uppercase tracking-tight block transition-colors ${permissions[item.key] ? 'text-white' : 'text-slate-500'}`}>
                    {item.label}
                  </span>
                  <span className="text-[9px] text-slate-500 font-bold uppercase tracking-widest block mt-0.5">{item.sub}</span>
                </div>
              </div>
              
              <div className={`w-12 h-7 rounded-full relative transition-all duration-500 shadow-inner ${permissions[item.key] ? 'bg-dragon-cyan' : 'bg-slate-800'}`}>
                <div className={`absolute top-1 w-5 h-5 bg-white rounded-full shadow-xl transition-all duration-500 ${permissions[item.key] ? 'translate-x-6' : 'translate-x-1'}`} />
              </div>
            </button>
          ))}
        </div>

        {/* Footer Actions */}
        <div className="p-6 bg-black/60 border-t border-white/5 flex gap-3">
          <button 
            onClick={() => { resetSitePermissions(url); onClose(); }}
            className="flex-1 py-4 flex items-center justify-center gap-2 text-[10px] font-black text-slate-400 hover:text-red-500 bg-white/5 rounded-2xl transition-all uppercase tracking-widest border border-white/5"
          >
            <RotateCcw size={14} /> Reset
          </button>
          <button 
            onClick={onClose}
            className="flex-1 py-4 flex items-center justify-center gap-2 text-[10px] font-black text-white bg-dragon-ember rounded-2xl transition-all uppercase tracking-widest shadow-xl shadow-dragon-ember/20 active:scale-95"
          >
            Apply Sync
          </button>
        </div>
      </div>
    </div>
  );
};
