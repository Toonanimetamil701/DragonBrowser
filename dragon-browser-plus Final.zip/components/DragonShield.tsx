
import React, { useState, useEffect } from 'react';
import { 
  Shield, ShieldOff, Activity, 
  Fingerprint, Globe, AlertTriangle, Trash2, CheckCircle 
} from 'lucide-react';
import { AppSettings } from '../types';
import { useDragon } from '../DragonContext';

interface DragonShieldProps {
  active: boolean; 
  settings: AppSettings;
  onToggleSetting: (key: keyof AppSettings) => void;
  currentUrl?: string;
}

export const DragonShield: React.FC<DragonShieldProps> = ({ settings, onToggleSetting, currentUrl }) => {
  const { incrementTrackers, purgeAllData, updateSettings } = useDragon();
  const [sessionTrackers, setSessionTrackers] = useState(0);

  const isSuspicious = currentUrl?.includes('suspicious-site') || 
                       currentUrl?.includes('malware') || 
                       currentUrl?.includes('phishing');

  useEffect(() => {
    if (settings.adBlockEnabled) {
      const interval = setInterval(() => {
        if (Math.random() > 0.8) {
          setSessionTrackers(prev => prev + 1);
          incrementTrackers(1);
        }
      }, 5000);
      return () => clearInterval(interval);
    }
  }, [settings.adBlockEnabled, incrementTrackers]);

  const handleClearData = () => {
    if (window.confirm('Delete all history and site data? This action cannot be undone.')) {
      purgeAllData();
      alert('Browsing history and data have been cleared.');
    }
  };

  const toggleMasterShield = () => {
    const newState = !settings.adBlockEnabled;
    updateSettings({ 
      adBlockEnabled: newState,
      safeBrowsing: newState, 
      dragonBreath: newState 
    });
  };

  return (
    <div className={`
      relative overflow-hidden rounded-[2.5rem] border border-slate-200 dark:border-white/10 bg-white/90 dark:bg-dragon-navy/95 backdrop-blur-3xl p-7 transition-all duration-500 shadow-xl w-full max-w-md mx-auto
      ${settings.adBlockEnabled ? 'shadow-[0_0_50px_rgba(249,115,22,0.15)] dark:shadow-[0_0_50px_rgba(249,115,22,0.2)]' : 'shadow-sm opacity-90'}
    `}>
      <div className="flex items-center justify-between mb-8 p-5 bg-slate-100 dark:bg-black/40 rounded-[2rem] border border-slate-200 dark:border-white/5 transition-colors">
        <div className="flex items-center gap-4">
          <div className={`p-3 rounded-2xl transition-all duration-500 ${settings.adBlockEnabled ? 'bg-orange-100 dark:bg-dragon-ember/20 border-orange-200 dark:border-dragon-ember/30 scale-110 shadow-lg' : 'bg-slate-200 dark:bg-slate-800 border-transparent dark:border-white/5'}`}>
            {settings.adBlockEnabled ? 
              <Shield className="w-7 h-7 text-dragon-ember animate-pulse-slow" /> : 
              <ShieldOff className="w-7 h-7 text-slate-500" />
            }
          </div>
          <div>
            <span className="font-black text-xs text-slate-700 dark:text-slate-100 uppercase tracking-[0.2em] block leading-none">Dragon Security</span>
            <span className={`text-[10px] font-bold uppercase mt-1 ${settings.adBlockEnabled ? 'text-dragon-ember' : 'text-slate-500'}`}>
              {settings.adBlockEnabled ? 'Armed & Protected' : 'Protection Disabled'}
            </span>
          </div>
        </div>

        <button 
          onClick={toggleMasterShield}
          className={`w-14 h-8 rounded-full relative transition-all duration-500 shadow-inner ${settings.adBlockEnabled ? 'bg-dragon-ember' : 'bg-slate-300 dark:bg-slate-700'}`}
        >
          <div className={`absolute top-1 w-6 h-6 bg-white rounded-full transition-all duration-500 shadow-xl ${settings.adBlockEnabled ? 'translate-x-7' : 'translate-x-1'}`} />
        </button>
      </div>

      {settings.adBlockEnabled && (
        <div className="mb-6 p-6 rounded-[2rem] bg-gradient-to-br from-slate-50 to-white dark:from-black/40 dark:to-dragon-navy/50 border border-slate-200 dark:border-white/5 shadow-inner text-center animate-fade-in">
          <p className="text-[10px] text-slate-500 font-black uppercase tracking-[0.3em] mb-2 flex items-center justify-center gap-2">
            <Activity className="w-3 h-3 text-dragon-ember" /> Blocked Ads & Trackers
          </p>
          <p className="text-4xl font-black text-slate-800 dark:text-white tabular-nums tracking-tighter italic">
            {settings.trackersBlockedTotal + sessionTrackers}
          </p>
        </div>
      )}

      {isSuspicious && settings.adBlockEnabled && (
        <div className="mb-6 p-4 bg-red-50 dark:bg-red-500/20 border border-red-200 dark:border-red-500/30 rounded-[1.5rem] flex items-center gap-4 animate-pulse ring-2 ring-red-500/10">
          <AlertTriangle className="w-6 h-6 text-red-500" />
          <div className="flex-1 text-left">
            <span className="text-[11px] font-black text-red-600 dark:text-red-400 uppercase tracking-tight block">Dangerous Site Warning</span>
            <span className="text-[9px] text-red-500 dark:text-red-400/60 font-bold uppercase">Dragon AI recommends leaving</span>
          </div>
        </div>
      )}

      <div className="space-y-3 mb-8">
        <button 
          onClick={() => onToggleSetting('secureDns')}
          className={`flex items-center justify-between w-full p-4 rounded-[1.5rem] transition-all border group ${
            settings.secureDns
            ? 'bg-cyan-50 dark:bg-dragon-cyan/10 border-cyan-200 dark:border-dragon-cyan/20' 
            : 'bg-slate-50 dark:bg-white/5 border-slate-100 dark:border-white/5 hover:bg-slate-100 dark:hover:bg-white/10'
          }`}
        >
           <div className="flex items-center gap-3">
             <div className={`p-2 rounded-xl transition-all ${settings.secureDns ? 'bg-cyan-100 dark:bg-dragon-cyan/20' : 'bg-slate-200 dark:bg-slate-800'}`}>
               <Globe className={`w-5 h-5 ${settings.secureDns ? 'text-dragon-cyan' : 'text-slate-500'}`} />
             </div>
             <div className="text-left">
               <span className="text-xs font-black text-slate-700 dark:text-slate-200 uppercase">Secure DNS</span>
               <span className="text-[9px] text-slate-500 font-bold block uppercase tracking-tighter">Encrypted Connection</span>
             </div>
           </div>
           <CheckCircle className={`w-5 h-5 transition-colors ${settings.secureDns ? 'text-dragon-cyan' : 'text-slate-300 dark:text-slate-700'}`} />
        </button>

        <button 
          onClick={() => onToggleSetting('dragonBreath')}
          className={`flex items-center justify-between w-full p-4 rounded-[1.5rem] transition-all border group ${
            settings.dragonBreath 
            ? 'bg-orange-50 dark:bg-dragon-ember/10 border-orange-200 dark:border-dragon-ember/20' 
            : 'bg-slate-50 dark:bg-white/5 border-slate-100 dark:border-white/5 hover:bg-slate-100 dark:hover:bg-white/10'
          }`}
        >
          <div className="flex items-center gap-3">
            <div className={`p-2 rounded-xl transition-all ${settings.dragonBreath ? 'bg-orange-100 dark:bg-dragon-ember/20' : 'bg-slate-200 dark:bg-slate-800'}`}>
              <Fingerprint className={`w-5 h-5 ${settings.dragonBreath ? 'text-dragon-ember' : 'text-slate-500'}`} />
            </div>
            <div className="text-left">
              <div className="text-xs font-black text-slate-700 dark:text-slate-200 uppercase tracking-tight">Anti-Tracking</div>
              <div className="text-[9px] text-slate-500 font-bold uppercase tracking-tighter">Identity Protection</div>
            </div>
          </div>
          <div className={`w-11 h-6 rounded-full relative transition-all shadow-inner ${settings.dragonBreath ? 'bg-dragon-ember' : 'bg-slate-300 dark:bg-slate-700'}`}>
            <div className={`absolute top-1 w-4 h-4 rounded-full bg-white transition-all ${settings.dragonBreath ? 'left-6' : 'left-1'}`} />
          </div>
        </button>
      </div>

      <button 
        onClick={handleClearData}
        className="w-full flex items-center justify-center gap-3 py-5 bg-red-50 dark:bg-red-500/10 hover:bg-red-100 dark:hover:bg-red-500/20 text-red-500 rounded-[2rem] text-[11px] font-black uppercase tracking-[0.2em] transition-all border border-red-100 dark:border-red-500/10 shadow-lg group active:scale-95"
      >
        <Trash2 className="w-5 h-5 group-hover:animate-bounce" />
        Clear Browsing Data
      </button>

      <div className="absolute inset-x-0 bottom-0 h-1 bg-gradient-to-r from-transparent via-dragon-ember to-transparent opacity-30 animate-pulse" />
    </div>
  );
};
