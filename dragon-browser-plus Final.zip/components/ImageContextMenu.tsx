
import React, { useState } from 'react';
import { motion } from 'framer-motion';
import { Camera, Layers, Shield, Download, Copy, Share2, Globe, Sparkles, Info, ArrowUpRight, Eye, Check } from 'lucide-react';
import { Share } from '@capacitor/share';
import { useDragon } from '../DragonContext';

interface ImageContextMenuProps {
  url: string;
  onClose: () => void;
  onOpenInNewTab?: (url: string) => void;
  onOpenInBackgroundTab?: (url: string) => void;
}

export const ImageContextMenu: React.FC<ImageContextMenuProps> = ({ url, onClose, onOpenInNewTab, onOpenInBackgroundTab }) => {
  const { addDownload, openMediaInfo, playMedia } = useDragon();
  const [copied, setCopied] = useState(false);

  const getFileType = (urlString: string) => {
    const ext = urlString.split('.').pop()?.toLowerCase() || '';
    if (['jpg','jpeg','png','gif','webp','svg'].includes(ext)) return 'image';
    // Added m3u8
    if (['mp4','webm','mkv','mov','m3u8'].includes(ext)) return 'video';
    if (['mp3','wav','ogg','m4a'].includes(ext)) return 'audio';
    return 'unknown';
  };

  const fileType = getFileType(url);
  const isImage = fileType === 'image' || fileType === 'unknown'; // Default to image actions if unknown but context opened

  const handleOpenNewTab = () => {
    if (onOpenInNewTab) {
      onOpenInNewTab(url);
    } else {
      window.open(url, '_blank');
    }
    onClose();
  };

  const handleOpenBackgroundTab = () => {
    if (onOpenInBackgroundTab) {
      onOpenInBackgroundTab(url);
    }
    onClose();
  };

  const handlePreview = () => {
    const filename = url.split('/').pop() || 'Preview';
    // Use 'image' type for preview as it supports zoom/pan
    playMedia(url, filename, fileType === 'unknown' ? 'image' : fileType as any);
    onClose();
  };

  const handleSave = () => {
    const filename = url.split('/').pop()?.split('?')[0] || `${fileType}-${Date.now()}`;
    addDownload(url, filename);
    onClose();
  };

  const handleCopyImage = async () => {
    try {
      // First attempt to write to clipboard as an image blob
      const response = await fetch(url);
      const blob = await response.blob();
      
      try {
        await navigator.clipboard.write([
          new ClipboardItem({
            [blob.type]: blob
          })
        ]);
        setCopied(true);
      } catch (err) {
        // Fallback to text copy if image write fails (common in non-secure contexts or some webviews)
        await navigator.clipboard.writeText(url);
        setCopied(true);
      }

      setTimeout(() => {
        setCopied(false);
        onClose();
      }, 1000);
    } catch (e) {
      console.error(e);
      // Ultimate fallback: copy URL
      navigator.clipboard.writeText(url);
      setCopied(true);
      setTimeout(() => { setCopied(false); onClose(); }, 1000);
    }
  };

  const handleShare = async () => {
    try {
      await Share.share({
        title: 'Share Image',
        url: url,
        dialogTitle: 'Share Image with...'
      });
    } catch (e) {
      console.warn('Share failed', e);
    }
    onClose();
  };

  const menuItems = [
    { 
      icon: <Download size={22} />, 
      label: "Download Image", 
      action: handleSave 
    },
    { 
      icon: <Eye size={22} />, 
      label: "Preview Image", 
      action: handlePreview 
    },
    { 
      icon: <ArrowUpRight size={22} />, 
      label: "Open Image in New Tab", 
      action: handleOpenNewTab 
    },
    { 
      icon: <Layers size={22} />, 
      label: "Open Image in Background Tab", 
      action: handleOpenBackgroundTab 
    },
    { 
      icon: copied ? <Check size={22} className="text-green-500" /> : <Copy size={22} />, 
      label: copied ? "Copied!" : "Copy Image", 
      action: handleCopyImage, 
      highlight: copied 
    },
    { 
      icon: <Share2 size={22} />, 
      label: "Share Image", 
      action: handleShare 
    }
  ];

  return (
    <div className="fixed inset-0 z-[250] flex items-end justify-center sm:items-center">
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="absolute inset-0 bg-black/60 backdrop-blur-md"
        onClick={onClose}
      />
      
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
        className="relative w-full max-w-sm bg-slate-50 dark:bg-[#1C1C1C] rounded-t-[28px] sm:rounded-[28px] shadow-2xl overflow-hidden mb-0 sm:mb-4 flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        <div className="w-full flex justify-center pt-3 pb-2 shrink-0" onClick={onClose}>
          <div className="w-12 h-1.5 bg-slate-300 dark:bg-white/20 rounded-full" />
        </div>

        <div className="flex-1 overflow-y-auto no-scrollbar">
          <div className="px-4 pb-4 pt-1">
             <div className="flex gap-4 p-4 bg-white dark:bg-white/5 rounded-[16px] border border-slate-200 dark:border-white/5 shadow-sm items-center">
                <div className="w-14 h-14 bg-slate-100 dark:bg-black/40 rounded-xl overflow-hidden shrink-0 border border-slate-100 dark:border-white/5 flex items-center justify-center relative">
                   {isImage ? (
                     <img 
                       src={url} 
                       alt="Preview" 
                       className="w-full h-full object-cover"
                       onError={(e) => {
                         (e.target as HTMLImageElement).style.display = 'none';
                       }} 
                     />
                   ) : (
                     <Globe className="text-slate-500" />
                   )}
                </div>
                <div className="flex-1 min-w-0">
                   <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">
                     Image Options
                   </h3>
                   <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5 font-medium">{new URL(url).hostname}</p>
                </div>
             </div>
          </div>

          <div className="px-2 pb-6 space-y-1">
            {menuItems.map((item, index) => (
              <button
                key={index}
                onClick={item.action}
                className={`w-full flex items-center gap-4 px-6 py-3.5 hover:bg-slate-200 dark:hover:bg-white/10 transition-colors ${item.highlight ? 'text-green-500' : 'text-slate-700 dark:text-slate-200'}`}
              >
                <div className={`${item.highlight ? 'text-green-500' : 'text-slate-500 dark:text-slate-400'} group-hover:text-slate-900 dark:group-hover:text-white transition-colors`}>
                  {item.icon}
                </div>
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
};
