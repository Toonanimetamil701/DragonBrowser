
import React from 'react';
import { motion } from 'framer-motion';
import { Camera, Layers, Shield, Download, Copy, Share2, Globe, Sparkles } from 'lucide-react';
import { Share } from '@capacitor/share';
import { useDragon } from '../DragonContext';

interface ImageContextMenuProps {
  url: string;
  onClose: () => void;
  onOpenInNewTab?: (url: string) => void;
}

export const ImageContextMenu: React.FC<ImageContextMenuProps> = ({ url, onClose, onOpenInNewTab }) => {
  const { addDownload } = useDragon();

  const handleLensSearch = () => {
    // Implicit intent via fallback URL which handles both App and Web
    const lensUrl = `https://lens.google.com/upload?url=${encodeURIComponent(url)}`;
    window.open(lensUrl, '_blank');
    onClose();
  };

  const handleOpenNewTab = () => {
    if (onOpenInNewTab) {
      onOpenInNewTab(url);
    } else {
      window.open(url, '_blank');
    }
    onClose();
  };

  const handleIncognito = () => {
    // Standard web behavior fallback, ideally handled by app router if prop provided
    // For now, opening in blank usually implies new session or system browser
    window.open(url, '_blank'); 
    onClose();
  };

  const handleSave = () => {
    const filename = url.split('/').pop()?.split('?')[0] || `image-${Date.now()}.jpg`;
    addDownload(url, filename);
    onClose();
  };

  const handleCopy = async () => {
    try {
      await navigator.clipboard.writeText(url);
      // Optional: Add toast here if context exposed it
    } catch (e) {
      console.error(e);
    }
    onClose();
  };

  const handleShare = async () => {
    try {
      await Share.share({
        title: 'Share Image',
        url: url,
        dialogTitle: 'Share with...'
      });
    } catch (e) {
      console.warn('Share failed', e);
    }
    onClose();
  };

  const menuItems = [
    { icon: <Layers size={22} />, label: "Open in new tab", action: handleOpenNewTab },
    { icon: <Shield size={22} />, label: "Open in incognito", action: handleIncognito },
    { icon: <Download size={22} />, label: "Save image", action: handleSave },
    { icon: <Copy size={22} />, label: "Copy image", action: handleCopy },
    { icon: <Share2 size={22} />, label: "Share image", action: handleShare },
  ];

  return (
    <div className="fixed inset-0 z-[250] flex items-end justify-center sm:items-center">
      {/* Backdrop with Blur */}
      <motion.div
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        exit={{ opacity: 0 }}
        transition={{ duration: 0.2 }}
        className="absolute inset-0 bg-black/60 backdrop-blur-md"
        onClick={onClose}
      />
      
      {/* Bottom Sheet */}
      <motion.div
        initial={{ y: "100%" }}
        animate={{ y: 0 }}
        exit={{ y: "100%" }}
        transition={{ type: "spring", damping: 25, stiffness: 300 }}
        className="relative w-full max-w-sm bg-slate-50 dark:bg-[#1C1C1C] rounded-t-[28px] sm:rounded-[28px] shadow-2xl overflow-hidden mb-0 sm:mb-4 flex flex-col max-h-[85vh]"
        onClick={(e) => e.stopPropagation()}
      >
        {/* Drag Handle */}
        <div className="w-full flex justify-center pt-3 pb-2 shrink-0" onClick={onClose}>
          <div className="w-12 h-1.5 bg-slate-300 dark:bg-white/20 rounded-full" />
        </div>

        <div className="flex-1 overflow-y-auto no-scrollbar">
          {/* Header Preview Card */}
          <div className="px-4 pb-4 pt-1">
             <div className="flex gap-4 p-4 bg-white dark:bg-white/5 rounded-[16px] border border-slate-200 dark:border-white/5 shadow-sm items-center">
                <div className="w-14 h-14 bg-slate-100 dark:bg-black/40 rounded-xl overflow-hidden shrink-0 border border-slate-100 dark:border-white/5 flex items-center justify-center relative">
                   <img 
                     src={url} 
                     alt="Preview" 
                     className="w-full h-full object-cover"
                     onError={(e) => {
                       (e.target as HTMLImageElement).style.display = 'none';
                       const parent = (e.target as HTMLImageElement).parentElement;
                       if (parent) parent.innerHTML = '<svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" stroke-width="2" class="text-slate-400"><rect width="18" height="18" x="3" y="3" rx="2" ry="2"/><circle cx="9" cy="9" r="2"/><path d="m21 15-3.086-3.086a2 2 0 0 0-2.828 0L6 21"/></svg>';
                     }} 
                   />
                </div>
                <div className="flex-1 min-w-0">
                   <h3 className="text-sm font-bold text-slate-900 dark:text-slate-100 truncate">Image Options</h3>
                   <p className="text-xs text-slate-500 dark:text-slate-400 truncate mt-0.5 font-medium">{new URL(url).hostname}</p>
                </div>
                <div className="p-2 bg-slate-100 dark:bg-white/10 rounded-full text-slate-500 dark:text-slate-400">
                   <Globe size={18} />
                </div>
             </div>
          </div>

          <div className="px-2 pb-6 space-y-1">
            {/* Primary Action: Google Lens */}
            <button 
              onClick={handleLensSearch}
              className="w-full flex items-center gap-4 px-4 py-4 hover:bg-slate-200 dark:hover:bg-white/10 rounded-2xl transition-colors group mx-2 mb-2 bg-blue-50 dark:bg-blue-500/10 text-blue-700 dark:text-blue-300"
            >
              <div className="p-0.5">
                <Camera size={24} />
              </div>
              <div className="flex-1 text-left">
                 <span className="text-sm font-bold block">Search with Google Lens</span>
              </div>
              <Sparkles size={18} className="opacity-70" />
            </button>

            <div className="h-px bg-slate-200 dark:bg-white/10 mx-4 my-2" />

            {/* Standard Actions */}
            {menuItems.map((item, index) => (
              <button
                key={index}
                onClick={item.action}
                className="w-full flex items-center gap-4 px-6 py-3.5 hover:bg-slate-200 dark:hover:bg-white/10 transition-colors text-slate-700 dark:text-slate-200"
              >
                <div className="text-slate-500 dark:text-slate-400 group-hover:text-slate-900 dark:group-hover:text-white transition-colors">
                  {item.icon}
                </div>
                <span className="text-sm font-medium">{item.label}</span>
              </button>
            ))}
          </div>
        </div>
      </motion.div>
    </div>
  );
};
