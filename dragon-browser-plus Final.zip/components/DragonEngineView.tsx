
import React, { useEffect, useRef } from 'react';

interface DragonEngineViewProps {
  url: string;
}

export const DragonEngineView: React.FC<DragonEngineViewProps> = ({ url }) => {
  const containerRef = useRef<HTMLDivElement>(null);

  // Extract query from internal protocol dragon://search?q=xyz
  const getQuery = () => {
    try {
      const searchParams = new URLSearchParams(url.split('?')[1]);
      return searchParams.get('q') || '';
    } catch {
      return '';
    }
  };

  const query = getQuery();

  useEffect(() => {
    let isMounted = true;

    const performSearch = () => {
      const gCse = (window as any).google?.search?.cse?.element;
      
      if (gCse) {
        try {
          const element = gCse.getElement('dragon-search-results');
          if (element) {
            element.execute(query);
          } else {
            gCse.go();
            setTimeout(() => {
              if (!isMounted) return;
              const el = gCse.getElement('dragon-search-results');
              if (el) el.execute(query);
            }, 500);
          }
        } catch (err) {
          console.warn('Dragon Engine: Search Execution Deferred', err);
        }
      }
    };

    if (query) {
      if ((window as any).google) {
        performSearch();
      } else {
        const checkInterval = setInterval(() => {
          if ((window as any).google?.search?.cse?.element) {
            performSearch();
            clearInterval(checkInterval);
          }
        }, 500);
        return () => {
          isMounted = false;
          clearInterval(checkInterval);
        };
      }
    }

    return () => {
      isMounted = false;
    };
  }, [query]);

  return (
    <div ref={containerRef} className="w-full h-full bg-black overflow-y-auto no-scrollbar">
      <div className="max-w-5xl mx-auto p-4 md:p-8">
        {/* Search Identity Header */}
        <div className="flex items-center gap-4 mb-6 animate-fade-in border-b border-white/5 pb-6">
          <img 
            src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" 
            alt="Dragon Engine" 
            className="w-12 h-12 rounded-2xl shadow-xl border border-white/10" 
          />
          <div>
            <h2 className="text-xl font-black text-white italic tracking-tighter uppercase leading-none">Dragon Engine</h2>
            <p className="text-dragon-ember text-[8px] font-black uppercase tracking-[0.3em] mt-1">Sovereign Google Search Protocol</p>
          </div>
        </div>
        
        {/* Google CSE Render Target */}
        <div className="animate-fade-in min-h-[600px]">
          <div 
            className="gcse-search" 
            data-gname="dragon-search-results"
            data-queryParameterName="q"
            data-mobileLayout="forced"
          ></div>
        </div>
      </div>

      <style>{`
        .gsc-control-cse {
          font-family: 'Inter', sans-serif !important;
          background-color: transparent !important;
          border: none !important;
          padding: 0 !important;
        }
        .gsc-webResult.gsc-result {
          background-color: #0a0a0a !important;
          border: 1px solid rgba(255,255,255,0.05) !important;
          border-radius: 1.5rem !important;
          padding: 1.25rem !important;
          margin-bottom: 1rem !important;
          transition: all 0.3s ease !important;
        }
        .gsc-webResult.gsc-result:hover {
          border-color: #f97316 !important;
          background-color: #111 !important;
          transform: translateY(-2px);
          box-shadow: 0 10px 30px -10px rgba(0,0,0,0.5);
        }
        .gs-title, .gs-title * {
          color: #f97316 !important;
          text-decoration: none !important;
          font-weight: 800 !important;
          font-size: 1.1rem !important;
        }
        .gs-snippet {
          color: #94a3b8 !important;
          line-height: 1.6 !important;
          font-size: 0.9rem !important;
        }
        .gsc-url-top, .gsc-url-bottom {
          color: #06b6d4 !important;
          font-size: 0.75rem !important;
          font-weight: 600 !important;
        }
        .gsc-cursor-box {
          margin-top: 2rem !important;
          border: none !important;
        }
        .gsc-cursor-page {
          background-color: #1a1a1a !important;
          color: #f97316 !important;
          border: 1px solid rgba(255,255,255,0.1) !important;
          border-radius: 0.75rem !important;
          padding: 0.5rem 1rem !important;
          margin-right: 0.5rem !important;
        }
        .gsc-cursor-current-page {
          background-color: #f97316 !important;
          color: white !important;
        }
        .gsc-search-box {
          display: none !important;
        }
        .gsc-loading-fade {
          background: #000 !important;
        }
        .gsc-adBlock {
          display: none !important;
        }
      `}</style>
    </div>
  );
};
