
import React, { useEffect, useState, useCallback } from 'react';
import { performDragonSearch, DragonSearchResponse } from '../services/geminiService';
import { Sparkles, Globe, Key, Search, ExternalLink, RefreshCcw, Cpu, ArrowRight, Camera as CameraIcon, Image as ImageIcon } from 'lucide-react';
import { FireProgressBar } from './FireProgressBar';
import { enforceSovereignProtocol } from '../utils/urlUtils';
import { Camera, CameraResultType, CameraSource } from '@capacitor/camera';
import { Share } from '@capacitor/share';

interface DragonEngineViewProps {
  url: string;
  onNavigate: (url: string) => void;
}

declare global {
  interface AIStudio {
    hasSelectedApiKey: () => Promise<boolean>;
    openSelectKey: () => Promise<void>;
  }
  interface Window {
    aistudio?: AIStudio;
  }
}

export const DragonEngineView: React.FC<DragonEngineViewProps> = ({ url, onNavigate }) => {
  const [activeTab, setActiveTab] = useState<'search' | 'lens'>('search');
  const [loading, setLoading] = useState(true);
  const [data, setData] = useState<DragonSearchResponse | null>(null);
  const [errorType, setErrorType] = useState<string | null>(null);
  
  const query = new URL(url).searchParams.get('q') || '';

  const fetchData = useCallback(async () => {
    setLoading(true);
    setErrorType(null);
    const result = await performDragonSearch(query);
    if (result.error) setErrorType(result.error);
    else setData(result);
    setLoading(false);
  }, [query]);

  useEffect(() => {
    if (query && activeTab === 'search') fetchData();
  }, [query, fetchData, activeTab]);

  const handleOpenKeyDialog = async () => {
    if (window.aistudio) {
      await window.aistudio.openSelectKey();
      fetchData();
    }
  };

  const handleGoogleFallback = () => {
    const googleUrl = `https://www.google.com/search?q=${encodeURIComponent(query)}`;
    onNavigate(enforceSovereignProtocol(googleUrl));
  };

  const handleLensCapture = async (source: CameraSource) => {
    try {
      const image = await Camera.getPhoto({
        quality: 90,
        allowEditing: false,
        resultType: CameraResultType.Uri,
        source: source
      });

      if (image.path) {
        await Share.share({
          title: 'Search with Lens',
          url: image.path,
          dialogTitle: 'Search image with...'
        });
      }
    } catch (error: any) {
       console.warn("Lens capture cancelled or failed", error);
    }
  };

  const renderError = () => {
    const isQuota = errorType === 'QUOTA_EXHAUSTED';
    return (
      <div className="w-full flex-1 flex items-center justify-center p-8 text-center animate-fade-in relative overflow-hidden min-h-[50vh]">
        <div className={`absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2 w-[500px] h-[500px] blur-[120px] rounded-full pointer-events-none opacity-20 ${isQuota ? 'bg-orange-500' : 'bg-red-500'}`} />
        <div className="max-w-md w-full space-y-8 relative z-10">
          <div className="relative mx-auto w-24 h-24">
            <div className={`absolute inset-0 blur-3xl rounded-full animate-pulse ${isQuota ? 'bg-orange-500/20' : 'bg-red-500/20'}`} />
            <div className={`relative w-full h-full bg-[#0f0f0f] border rounded-3xl flex items-center justify-center shadow-2xl ${isQuota ? 'border-orange-500/30' : 'border-red-500/30'}`}>
              <Cpu className={`w-10 h-10 ${isQuota ? 'text-orange-500' : 'text-red-500'}`} />
            </div>
          </div>
          <div className="space-y-4">
            <h2 className="text-2xl font-black text-white italic tracking-tighter uppercase">
              {isQuota ? 'AI Limit Reached' : 'Search Connection Error'}
            </h2>
            <p className="text-slate-400 text-[11px] font-bold leading-relaxed px-4">
              {isQuota 
                ? "The AI search limit has been reached. To continue using AI features, please add your own Gemini API key."
                : "Unable to connect to the AI search service. Please check your settings or use standard search."}
            </p>
          </div>
          <div className="space-y-4 pt-4">
            <button 
              onClick={handleOpenKeyDialog}
              className="w-full py-4 bg-orange-500 text-black font-black uppercase text-[11px] tracking-[0.2em] rounded-2xl shadow-[0_0_30px_rgba(249,115,22,0.3)] active:scale-95 transition-all flex items-center justify-center gap-3"
            >
              <Key size={14} /> Add API Key
            </button>
            <button 
              onClick={handleGoogleFallback}
              className="w-full py-4 bg-white/5 border border-white/10 text-slate-300 font-black uppercase text-[11px] tracking-[0.2em] rounded-2xl hover:bg-white/10 transition-all active:scale-95 flex items-center justify-center gap-3 group"
            >
              <Globe size={14} /> Search on Google
              <ArrowRight size={12} className="group-hover:translate-x-1 transition-transform" />
            </button>
            <div className="flex items-center justify-center gap-6 pt-4">
               <button onClick={fetchData} className="text-[9px] text-slate-500 hover:text-white font-black uppercase tracking-widest flex items-center gap-2 transition-colors">
                 <RefreshCcw size={12} /> Retry Search
               </button>
               <a href="https://ai.google.dev/gemini-api/docs/billing" target="_blank" rel="noopener noreferrer" className="text-[9px] text-slate-500 hover:text-orange-500 font-black uppercase tracking-widest transition-colors">
                 API Documentation
               </a>
            </div>
          </div>
        </div>
      </div>
    );
  };

  return (
    <div className="w-full h-full bg-[#050505] text-slate-100 flex flex-col relative overflow-hidden">
      {/* Loading Indicator */}
      {activeTab === 'search' && loading && <FireProgressBar isLoading={true} themeColor="#f97316" />}
      
      {/* Upper Tab Bar */}
      <div className="px-6 pt-6 pb-2 shrink-0 z-20 bg-[#050505]">
         <div className="flex p-1.5 bg-[#121212] rounded-2xl border border-white/5 relative">
            <button 
               onClick={() => setActiveTab('search')}
               className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all relative z-10 ${activeTab === 'search' ? 'bg-[#1a1a1a] text-dragon-ember shadow-lg border border-white/10' : 'text-slate-500 hover:text-slate-300'}`}
            >
               <Sparkles size={14} /> Dragon Search
            </button>
            <button 
               onClick={() => setActiveTab('lens')}
               className={`flex-1 flex items-center justify-center gap-2 py-3 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all relative z-10 ${activeTab === 'lens' ? 'bg-[#1a1a1a] text-blue-400 shadow-lg border border-white/10' : 'text-slate-500 hover:text-slate-300'}`}
            >
               <CameraIcon size={14} /> Google Lens
            </button>
         </div>
      </div>

      <div className="flex-1 overflow-y-auto no-scrollbar relative flex flex-col">
        {activeTab === 'search' && (
           <>
             {(errorType && !loading) ? renderError() : (
               <div className="max-w-4xl mx-auto p-6 md:p-8 flex flex-col w-full">
                 <div className="flex items-center gap-4 mb-8 animate-fade-in border-b border-white/5 pb-6">
                   <div className="relative shrink-0">
                      <div className="absolute inset-0 bg-orange-500/20 blur-xl rounded-full" />
                      <img src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" alt="Dragon Search" className="w-14 h-14 rounded-2xl shadow-2xl border border-white/10 relative z-10 object-cover" />
                   </div>
                   <div className="flex-1 min-w-0">
                     <h2 className="text-2xl font-black text-white italic tracking-tighter uppercase leading-none truncate">Dragon Search</h2>
                     <div className="flex items-center gap-2 mt-1.5">
                       <Sparkles className="w-3 h-3 text-orange-500" />
                       <p className="text-orange-500 text-[9px] font-black uppercase tracking-[0.3em]">AI-Powered Results</p>
                     </div>
                   </div>
                   <div className="flex items-center gap-2">
                     <button onClick={fetchData} className="p-2.5 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl text-slate-400 hover:text-white transition-all">
                       <RefreshCcw size={16} />
                     </button>
                     <button onClick={handleGoogleFallback} className="flex items-center gap-2 px-4 py-2 bg-white/5 hover:bg-white/10 border border-white/5 rounded-xl text-[10px] font-bold text-slate-400 hover:text-white transition-all shrink-0">
                       <Globe size={14} /> Use Google
                     </button>
                   </div>
                 </div>

                 {data ? (
                   <div className="animate-fade-in space-y-8 pb-20">
                     <div className="bg-[#0f0f0f] rounded-[2rem] p-6 md:p-8 border border-white/10 shadow-2xl relative overflow-hidden group">
                       <div className="absolute top-0 right-0 p-4 opacity-5 group-hover:opacity-10 transition-opacity">
                         <Sparkles size={40} className="text-orange-500" />
                       </div>
                       <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-widest mb-4 flex items-center gap-2">
                         <Search size={12} className="text-orange-500" /> AI Summary
                       </h3>
                       <div className="prose prose-invert prose-sm max-w-none text-slate-200 leading-relaxed font-medium">
                         <p className="whitespace-pre-wrap">{data.answer}</p>
                       </div>
                     </div>
                     {data.results.length > 0 && (
                       <div className="space-y-4">
                         <div className="flex items-center gap-2 px-2">
                           <Globe size={14} className="text-cyan-500" />
                           <h3 className="text-[10px] font-black text-slate-400 uppercase tracking-widest">Web Sources</h3>
                         </div>
                         <div className="grid gap-3">
                           {data.results.map((result, idx) => (
                             <button key={idx} onClick={() => onNavigate(enforceSovereignProtocol(result.url))} className="w-full text-left bg-[#0f0f0f] hover:bg-[#151515] border border-white/5 hover:border-orange-500/30 p-5 rounded-2xl transition-all group flex items-start gap-4 active:scale-[0.99]">
                               <div className="w-10 h-10 rounded-xl bg-black flex items-center justify-center shrink-0 border border-white/5 shadow-inner">
                                 <img src={`https://www.google.com/s2/favicons?sz=64&domain=${result.domain}`} alt="" className="w-5 h-5 opacity-70 group-hover:opacity-100" onError={(e) => { (e.target as HTMLImageElement).style.display = 'none'; }} />
                               </div>
                               <div className="flex-1 min-w-0">
                                 <span className="text-[9px] font-bold text-slate-500 uppercase tracking-wider block mb-1">{result.domain}</span>
                                 <h4 className="text-sm font-bold text-blue-400 group-hover:text-orange-400 transition-colors line-clamp-2 leading-snug">{result.title}</h4>
                               </div>
                               <ExternalLink className="w-4 h-4 text-slate-600 group-hover:text-white opacity-0 group-hover:opacity-100" />
                             </button>
                           ))}
                         </div>
                       </div>
                     )}
                     <div className="text-center pt-8 border-t border-white/5 space-y-4">
                        <p className="text-[9px] text-slate-600 font-bold uppercase tracking-widest">Need more info? Try a standard search</p>
                        <button onClick={handleGoogleFallback} className="px-8 py-4 bg-white/5 hover:bg-white/10 rounded-2xl text-[10px] font-black text-slate-400 uppercase tracking-widest border border-white/5 transition-all active:scale-95">
                          Search on Google
                        </button>
                     </div>
                   </div>
                 ) : !loading && (
                   <div className="flex-1 flex flex-col items-center justify-center py-20 opacity-50">
                     <p className="text-xs font-black uppercase tracking-[0.2em] text-slate-500">Connection Error</p>
                     <button onClick={fetchData} className="mt-4 px-6 py-2 bg-white/5 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/10 hover:bg-white/10 transition-colors">
                       Retry Search
                     </button>
                   </div>
                 )}
               </div>
             )}
           </>
        )}

        {activeTab === 'lens' && (
           <div className="flex-1 flex flex-col items-center justify-center p-8 animate-fade-in">
              <div className="relative mb-12">
                 <div className="absolute inset-0 bg-blue-500/20 blur-[80px] rounded-full animate-pulse-slow" />
                 <div className="relative w-32 h-32 bg-[#1a1a1a] rounded-[2.5rem] border border-white/10 flex items-center justify-center shadow-2xl">
                    <div className="w-16 h-16 rounded-xl border-4 border-blue-500 flex items-center justify-center relative">
                       <div className="absolute top-[-4px] left-[-4px] w-4 h-4 border-t-4 border-l-4 border-blue-500 rounded-tl-lg" />
                       <div className="absolute top-[-4px] right-[-4px] w-4 h-4 border-t-4 border-r-4 border-blue-500 rounded-tr-lg" />
                       <div className="absolute bottom-[-4px] left-[-4px] w-4 h-4 border-b-4 border-l-4 border-blue-500 rounded-bl-lg" />
                       <div className="absolute bottom-[-4px] right-[-4px] w-4 h-4 border-b-4 border-r-4 border-blue-500 rounded-br-lg" />
                       <CameraIcon size={32} className="text-blue-500" />
                    </div>
                 </div>
              </div>

              <h2 className="text-2xl font-black text-white uppercase tracking-tighter italic mb-3">Google Lens</h2>
              <p className="text-slate-400 text-[10px] font-bold uppercase tracking-widest mb-10 text-center max-w-xs leading-relaxed">
                 Search what you see. Identify plants, translate text, and find products instantly.
              </p>

              <div className="w-full max-w-sm space-y-4">
                 <button 
                    onClick={() => handleLensCapture(CameraSource.Camera)}
                    className="w-full py-5 bg-blue-600 hover:bg-blue-500 text-white rounded-2xl flex items-center justify-center gap-4 text-xs font-black uppercase tracking-[0.2em] shadow-lg shadow-blue-900/30 active:scale-95 transition-all group"
                 >
                    <CameraIcon size={18} className="group-hover:scale-110 transition-transform" />
                    Take Photo
                 </button>
                 <button 
                    onClick={() => handleLensCapture(CameraSource.Photos)}
                    className="w-full py-5 bg-[#1a1a1a] hover:bg-[#222] border border-white/10 text-slate-300 rounded-2xl flex items-center justify-center gap-4 text-xs font-black uppercase tracking-[0.2em] active:scale-95 transition-all group"
                 >
                    <ImageIcon size={18} className="text-slate-500 group-hover:text-white transition-colors" />
                    Upload Image
                 </button>
              </div>
           </div>
        )}
      </div>
    </div>
  );
};
