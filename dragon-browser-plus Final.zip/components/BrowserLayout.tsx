
import React, { useState } from 'react';
import { Shield, Sparkles, Menu, X } from 'lucide-react';
import { Tab, ThemeColor, AppSettings, SearchEngine, BrowserViewMode } from '../types';
import { DragonShield } from './DragonShield';
import { LairSidebar } from './LairSidebar';
import { TabStrip } from './TabStrip';
import { useDragonAI } from '../hooks/useDragonAI';

interface BrowserLayoutProps {
  activeTab: Tab;
  tabs: Tab[];
  theme: ThemeColor;
  settings: AppSettings;
  onThemeChange: (t: ThemeColor) => void;
  onToggleSetting: (k: keyof AppSettings) => void;
  onEngineChange: (e: SearchEngine) => void;
  onNavigateTo: (mode: BrowserViewMode) => void;
  onSelectTab: (id: string) => void;
  onCloseTab: (id: string) => void;
  onCreateTab: () => void;
  pageContentForAI: string;
  children: React.ReactNode;
}

export const BrowserLayout: React.FC<BrowserLayoutProps> = ({
  activeTab, tabs, theme, settings,
  onThemeChange, onToggleSetting, onEngineChange, onNavigateTo, onSelectTab, onCloseTab, onCreateTab,
  pageContentForAI, children
}) => {
  const [showShield, setShowShield] = useState(false);
  const [showLair, setShowLair] = useState(false);
  
  const { summary, isSummarizing, generateSummary, clearSummary } = useDragonAI();

  const handleSummarize = async () => {
    if (summary) {
      clearSummary();
      return;
    }
    await generateSummary(pageContentForAI);
  };

  const getThemeColors = () => {
    switch(theme) {
      case 'frost': return { main: '#06b6d4', glow: 'rgba(6, 182, 212, 0.5)' };
      case 'midas': return { main: '#eab308', glow: 'rgba(234, 179, 8, 0.5)' };
      case 'venom': return { main: '#22c55e', glow: 'rgba(34, 197, 94, 0.5)' };
      case 'ember': default: return { main: '#f97316', glow: 'rgba(249, 115, 22, 0.5)' };
    }
  };
  const themeColors = getThemeColors();

  return (
    <div 
      className="flex flex-col h-full w-full bg-dragon-dark text-slate-100 overflow-hidden relative"
      style={{ 
        '--theme-color': themeColors.main, 
        '--theme-color-glow': themeColors.glow 
      } as React.CSSProperties}
    >
      {/* Secondary Top Control (Tabs & AI) */}
      <div className="flex flex-col z-40 bg-dragon-navy/50 backdrop-blur-xl border-b border-white/5">
        <div className="flex items-center gap-2 px-3 py-1 bg-black/20">
          <button 
            onClick={() => setShowShield(!showShield)}
            className={`p-2 rounded-xl transition-all ${showShield ? 'text-[var(--theme-color)] bg-white/5' : 'text-slate-500 hover:text-white'}`}
          >
            <Shield className="w-4 h-4" />
          </button>

          <div className="flex-1 overflow-hidden">
            <TabStrip 
              tabs={tabs} 
              activeTabId={activeTab.id} 
              onSelectTab={onSelectTab} 
              onCloseTab={onCloseTab} 
              onCreateTab={onCreateTab}
              accentColor={themeColors.main}
            />
          </div>

          {!activeTab.url.includes('newtab') && (
            <button 
              onClick={handleSummarize}
              className={`p-2 rounded-xl transition-all ${summary ? 'text-[var(--theme-color)] bg-white/5' : 'text-slate-500'}`}
              disabled={isSummarizing}
            >
              {isSummarizing ? (
                 <Sparkles className="w-4 h-4 animate-spin opacity-50" />
              ) : (
                 <Sparkles className="w-4 h-4" />
              )}
            </button>
          )}

          <button 
            onClick={() => setShowLair(true)}
            className="p-2 text-slate-500 hover:text-white rounded-xl"
          >
            <Menu className="w-4 h-4" />
          </button>
        </div>
      </div>

      {/* Floating Shield Dashboard */}
      <div className={`
        absolute top-16 left-4 z-50 w-72 transition-all duration-300 transform origin-top-left
        ${showShield ? 'scale-100 opacity-100' : 'scale-95 opacity-0 pointer-events-none'}
      `}>
        <DragonShield active={true} settings={settings} onToggleSetting={onToggleSetting} currentUrl={activeTab.url} />
      </div>

      <LairSidebar 
        isOpen={showLair} 
        onClose={() => setShowLair(false)} 
        currentTheme={theme}
        onThemeChange={onThemeChange}
        settings={settings}
        onToggleSetting={onToggleSetting}
        onEngineChange={onEngineChange}
        shieldStats={settings.trackersBlockedTotal} 
      />

      {/* AI Insight HUD */}
      {summary && (
        <div className="absolute top-16 right-4 z-50 w-64 bg-dragon-navy/95 backdrop-blur-3xl border border-[var(--theme-color)]/30 rounded-3xl p-5 shadow-2xl animate-float ring-4 ring-black/40">
          <div className="flex justify-between items-start mb-3">
            <h3 className="text-[9px] font-black text-[var(--theme-color)] flex items-center gap-2 uppercase tracking-widest">
              <Sparkles className="w-3 h-3" /> Dragon Insight
            </h3>
            <button onClick={clearSummary} className="p-1 hover:bg-white/5 rounded-lg text-slate-500"><X className="w-3 h-3" /></button>
          </div>
          <div className="text-[11px] text-slate-300 leading-relaxed italic">
            {summary}
          </div>
        </div>
      )}

      {/* Page Content */}
      <div className="flex-1 relative overflow-hidden bg-dragon-dark">
        {children}
      </div>
    </div>
  );
};
