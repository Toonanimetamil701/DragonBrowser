
import React from 'react';
import { Search, X, ChevronUp, ChevronDown } from 'lucide-react';

interface FindInPageProps {
  isActive: boolean;
  query: string;
  onQueryChange: (text: string) => void;
  current: number;
  total: number;
  onNext: () => void;
  onPrev: () => void;
  onClose: () => void;
}

export const FindInPage: React.FC<FindInPageProps> = ({ 
  isActive, query, onQueryChange, current, total, onNext, onPrev, onClose 
}) => {
  if (!isActive) return null;

  return (
    <div className="fixed bottom-24 left-1/2 -translate-x-1/2 w-[90%] max-w-sm bg-dragon-navy/95 backdrop-blur-2xl border border-white/10 rounded-2xl p-2 shadow-2xl z-[100] flex items-center gap-2 animate-float">
      <Search className="w-4 h-4 text-dragon-cyan ml-2" />
      <input
        autoFocus
        value={query}
        onChange={(e) => onQueryChange(e.target.value)}
        placeholder="Find in page..."
        className="flex-1 bg-transparent border-none outline-none text-sm text-white py-2 placeholder-slate-500"
      />
      <div className="flex items-center gap-2 text-[10px] font-mono text-slate-400">
        {total > 0 && <span>{current}/{total}</span>}
      </div>
      <div className="flex items-center gap-1 border-l border-white/5 pl-2">
        <button onClick={onPrev} className="p-1 hover:bg-white/5 rounded-lg text-slate-400 hover:text-white"><ChevronUp className="w-4 h-4" /></button>
        <button onClick={onNext} className="p-1 hover:bg-white/5 rounded-lg text-slate-400 hover:text-white"><ChevronDown className="w-4 h-4" /></button>
        <button 
          onClick={onClose}
          className="p-1 hover:bg-red-500/20 rounded-lg text-slate-400 hover:text-red-400"
        >
          <X className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
};
