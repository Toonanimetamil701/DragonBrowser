
import React, { useState, useEffect, useRef } from 'react';
import { Search, Globe, Lock, Sparkles, ArrowRight, Loader2 } from 'lucide-react';
import { useDragonAI } from '../hooks/useDragonAI';
import { Tab, SearchEngine } from '../types';
import { useDragon } from '../DragonContext';

interface AddressBarProps {
  activeTab: Tab;
  urlInputValue: string;
  onUrlChange: (val: string) => void;
  onUrlSubmit: () => void;
  onReload: () => void;
  accentColor: string;
  onSummarize?: () => void;
  isSummarizing?: boolean;
}

export const AddressBar: React.FC<AddressBarProps> = ({
  activeTab,
  urlInputValue,
  onUrlChange,
  onUrlSubmit,
  onReload,
  accentColor,
  onSummarize,
  isSummarizing
}) => {
  const { suggestions: aiSuggestions, fetchSuggestions, setSuggestions } = useDragonAI();
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (urlInputValue && 
          document.activeElement === inputRef.current && 
          !urlInputValue.startsWith('http') && 
          !urlInputValue.includes('.')) {
        fetchSuggestions(urlInputValue);
      } else {
        setSuggestions([]);
      }
    }, 400);
    return () => clearTimeout(timer);
  }, [urlInputValue, fetchSuggestions, setSuggestions]);

  return (
    <div className="w-full relative">
      <form 
        onSubmit={(e) => { 
          e.preventDefault(); 
          setShowSuggestions(false);
          inputRef.current?.blur();
          onUrlSubmit(); 
        }}
        className={`
          relative flex items-center bg-[#111315] border rounded-full px-2.5 h-9 shadow-inner transition-all duration-300
          focus-within:bg-[#181a1d] focus-within:border-white/10
          ${activeTab.isPrivate ? 'border-purple-500/30' : 'border-white/5'}
        `}
      >
        <div className="flex items-center shrink-0">
          {activeTab.isPrivate ? (
            <Lock className="w-3.5 h-3.5 mr-2 text-purple-500 animate-pulse" />
          ) : (
            <div className="flex items-center gap-1.5 mr-2 shrink-0">
               <img 
                 src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" 
                 alt="Dragon" 
                 className="w-4 h-4 rounded-full object-cover border border-white/5"
               />
               <img 
                 src="https://www.google.com/favicon.ico"
                 className="w-3.5 h-3.5 opacity-80"
                 alt="Google"
               />
            </div>
          )}
        </div>

        <input
          ref={inputRef}
          className="flex-1 bg-transparent border-none outline-none text-[12px] text-white placeholder-slate-500 font-medium h-full px-0 focus:ring-0 min-w-0"
          value={urlInputValue}
          onChange={(e) => {
            onUrlChange(e.target.value);
            setShowSuggestions(true);
          }}
          onFocus={() => setShowSuggestions(true)}
          onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
          placeholder="Search or enter address"
          autoCapitalize="off"
          autoComplete="off"
          spellCheck="false"
        />

        <div className="flex items-center gap-1">
          {onSummarize && !activeTab.url.startsWith('dragon://') && (
            <button
              type="button"
              onClick={onSummarize}
              disabled={isSummarizing}
              className={`p-1.5 rounded-full transition-all ${isSummarizing ? 'bg-orange-500/10' : 'hover:bg-white/5'}`}
              title="Summarize with Dragon AI"
            >
              {isSummarizing ? (
                <Loader2 className="w-3.5 h-3.5 text-orange-500 animate-spin" />
              ) : (
                <Sparkles className="w-3.5 h-3.5 text-orange-500 hover:text-orange-400" />
              )}
            </button>
          )}

          {urlInputValue.length > 0 && (
             <button type="submit" className="text-slate-500 hover:text-white ml-1">
               <ArrowRight size={14} />
             </button>
          )}
        </div>
      </form>

      {showSuggestions && aiSuggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-[#0d0f11] backdrop-blur-3xl border border-white/10 rounded-2xl shadow-2xl overflow-hidden z-[100] animate-fade-in divide-y divide-white/5">
          <div className="px-4 py-2 text-[8px] text-slate-500 uppercase tracking-widest font-black flex items-center gap-2 bg-black/20">
            <Sparkles className="w-3 h-3 text-orange-500" /> Neural Suggestions
          </div>

          {aiSuggestions.map((s, idx) => (
            <button
              key={`ai-${idx}`}
              type="button"
              className="w-full text-left px-4 py-3 hover:bg-white/5 flex items-center gap-3 transition-all group"
              onMouseDown={(e) => {
                e.preventDefault();
                onUrlChange(s);
                onUrlSubmit();
                setShowSuggestions(false);
              }}
            >
              <Search className="w-3.5 h-3.5 opacity-40 group-hover:text-orange-500 group-hover:opacity-100" />
              <span className="text-[12px] text-slate-300 font-medium truncate">{s}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
