
import React, { useState, useEffect, useRef, useMemo } from 'react';
import { Search, Globe, Lock, Sparkles, Loader2, X, Clock, Star } from 'lucide-react';
import { useDragon } from '../DragonContext';
import { useDragonAI } from '../hooks/useDragonAI';
import { Tab } from '../types';

interface AddressBarProps {
  activeTab: Tab;
  urlInputValue: string;
  onUrlChange: (val: string) => void;
  onUrlSubmit: () => void;
  onReload: () => void;
  accentColor: string;
  onSiteSettingsClick?: () => void;
  onFocus?: () => void;
}

export const AddressBar: React.FC<AddressBarProps> = ({
  activeTab,
  urlInputValue,
  onUrlChange,
  onUrlSubmit,
  onReload,
  accentColor,
  onSiteSettingsClick,
  onFocus
}) => {
  const { suggestions: aiSuggestions, fetchSuggestions, setSuggestions } = useDragonAI();
  const { history, bookmarks } = useDragon();
  const [showSuggestions, setShowSuggestions] = useState(false);
  const [isInputFocused, setIsInputFocused] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  useEffect(() => {
    const timer = setTimeout(() => {
      if (urlInputValue && 
          document.activeElement === inputRef.current && 
          !urlInputValue.startsWith('http') && 
          !urlInputValue.includes('.')) {
        fetchSuggestions(urlInputValue);
      } else {
        setSuggestions([]);
      }
    }, 300); 
    return () => clearTimeout(timer);
  }, [urlInputValue, fetchSuggestions, setSuggestions]);

  const mergedSuggestions = useMemo(() => {
    if (!urlInputValue || urlInputValue.length < 1) return [];
    const lowerQuery = urlInputValue.toLowerCase();
    
    const matchedBookmarks = bookmarks
      .filter(b => b.title.toLowerCase().includes(lowerQuery) || b.url.toLowerCase().includes(lowerQuery))
      .slice(0, 3)
      .map(b => ({ type: 'bookmark', value: b.url, label: b.title || b.url }));

    const matchedHistory = history
      .filter(h => h.title.toLowerCase().includes(lowerQuery) || h.url.toLowerCase().includes(lowerQuery))
      .slice(0, 3)
      .map(h => ({ type: 'history', value: h.url, label: h.title || h.url }));

    const localUrls = new Set([...matchedBookmarks, ...matchedHistory].map(i => i.value));
    const cleanWebSuggestions = aiSuggestions
      .filter(s => !localUrls.has(s))
      .slice(0, 6) 
      .map(s => ({ type: 'web', value: s, label: s }));

    return [...matchedBookmarks, ...matchedHistory, ...cleanWebSuggestions];
  }, [urlInputValue, bookmarks, history, aiSuggestions]);

  const handleFocusInternal = () => {
    setIsInputFocused(true);
    if (onFocus) {
      onFocus();
    } else {
      setShowSuggestions(true);
      inputRef.current?.select();
    }
  };

  const handleBlurInternal = () => {
    setIsInputFocused(false);
    setTimeout(() => setShowSuggestions(false), 200);
  };

  const getSiteIcon = () => {
    if (activeTab.isPrivate) return <Lock className="w-4 h-4 text-purple-500 animate-pulse" />;
    
    const isInternal = activeTab.url.startsWith('dragon://');
    let domain = '';
    try {
      domain = isInternal ? 'dragon' : new URL(activeTab.url).hostname;
    } catch (e) {
      return <Globe className="w-4 h-4 text-slate-400" />;
    }
    
    if (isInternal) {
      return (
        <img 
          src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg"
          className="w-4 h-4 rounded-full object-cover"
          alt="D"
        />
      );
    }

    // Dynamic Favicon Fetcher
    return (
      <img 
        src={`https://www.google.com/s2/favicons?sz=64&domain=${domain}`}
        className="w-4 h-4 rounded-sm object-contain"
        onError={(e) => { (e.target as HTMLImageElement).src = 'data:image/svg+xml;base64,PHN2ZyB3aWR0aD0iMTYiIGhlaWdodD0iMTYiIHZpZXdCb3g9IjAgMCAyNCAyNCIgZmlsbD0ibm9uZSIgc3Ryb2tlPSIjOTQ5OThmIiBzdHJva2Utd2lkdGg9IjIiIHN0cm9rZS1saW5lY2FwPSJyb3VuZCIgc3Ryb2tlLWxpbmVqb2luPSJyb3VuZCI+PGNpcmNsZSBjeD0iMTIiIGN5PSIxMiIgcj0iMTAiLz48bGluZSB4MT0iMiIgeTE9IjEyIiB4Mj0iMjIiIHkyPSIxMiIvPjxwYXRoIGQ9Ik0xMiAyYzIuODU1IDAgNSAxMCA1IDEwcy0yLjE0NSA0LTUgNHMtNS0xMC01LTEwczIuMTQ1LTQgNS00eiIvPjwvc3ZnPg=='; }}
        alt=""
      />
    );
  };

  const getSuggestionIcon = (type: string) => {
    switch(type) {
      case 'bookmark': return <Star className="w-3.5 h-3.5 text-orange-400" fill="currentColor" />;
      case 'history': return <Clock className="w-3.5 h-3.5 text-slate-400" />;
      default: return <Search className="w-3.5 h-3.5 text-slate-400" />;
    }
  };

  return (
    <div className="w-full relative group">
      <form 
        onSubmit={(e) => { 
          e.preventDefault(); 
          setShowSuggestions(false);
          inputRef.current?.blur();
          onUrlSubmit(); 
        }}
        className={`
          relative flex items-center bg-slate-100 dark:bg-dragon-navy/80 border rounded-2xl h-10 shadow-inner transition-all duration-300
          focus-within:bg-slate-200 dark:focus-within:bg-black/60 focus-within:border-slate-300 dark:focus-within:border-white/20 focus-within:shadow-lg
          ${activeTab.isPrivate ? 'border-purple-500/30' : 'border-slate-200 dark:border-white/5'}
        `}
      >
        <button 
          type="button" 
          onClick={onSiteSettingsClick}
          className="flex items-center shrink-0 pl-3 pr-2 h-full cursor-pointer hover:opacity-70 transition-opacity"
        >
          {getSiteIcon()}
        </button>

        <input
          id="dragon-url-input"
          ref={inputRef}
          className={`flex-1 bg-transparent border-none outline-none text-[13px] font-medium h-full px-1 focus:ring-0 min-w-0 text-slate-900 dark:text-slate-100 placeholder-slate-400 dark:placeholder-slate-600`}
          value={urlInputValue}
          onChange={(e) => {
            onUrlChange(e.target.value);
            setShowSuggestions(true);
          }}
          onFocus={handleFocusInternal}
          onBlur={handleBlurInternal}
          placeholder="Search or enter address"
          autoCapitalize="off"
          autoComplete="off"
          spellCheck="false"
        />

        <div className="flex items-center gap-1 pr-2">
          {activeTab.isLoading && <Loader2 className="w-3.5 h-3.5 text-dragon-ember animate-spin mr-1" />}
          {urlInputValue && (
             <button 
               type="button" 
               onClick={() => onUrlChange('')}
               className="p-1.5 text-slate-400 hover:text-slate-900 dark:hover:text-white rounded-full hover:bg-black/5 dark:hover:bg-white/10 transition-colors"
             >
               <X size={12} />
             </button>
          )}
        </div>
      </form>

      {showSuggestions && mergedSuggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-3 bg-white dark:bg-[#0d0f11] backdrop-blur-3xl border border-slate-200 dark:border-white/10 rounded-2xl shadow-2xl overflow-hidden z-[100] animate-fade-in divide-y divide-slate-100 dark:divide-white/5 ring-1 ring-black/5 dark:ring-white/5">
          <div className="px-4 py-3 text-[9px] text-slate-500 uppercase tracking-widest font-black flex items-center gap-2 bg-slate-50 dark:bg-black/20">
            <Sparkles className="w-3 h-3 text-orange-500" /> Suggestions
          </div>
          {mergedSuggestions.map((s, idx) => (
            <button
              key={`suggestion-${idx}`}
              type="button"
              className="w-full text-left px-5 py-3 hover:bg-slate-50 dark:hover:bg-white/5 flex items-center gap-3 transition-all group"
              onMouseDown={(e) => {
                e.preventDefault();
                onUrlChange(s.value);
                onUrlSubmit();
                setShowSuggestions(false);
              }}
            >
              {getSuggestionIcon(s.type)}
              <div className="flex-1 min-w-0">
                 <span className="text-[12px] text-slate-700 dark:text-slate-300 font-medium truncate block">{s.label}</span>
                 {s.type !== 'web' && <span className="text-[9px] text-slate-400 truncate block">{s.value}</span>}
              </div>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
