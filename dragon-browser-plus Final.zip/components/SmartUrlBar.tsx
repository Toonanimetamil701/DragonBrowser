
import React, { useState, useEffect, useRef } from 'react';
import { Search, Globe, RotateCw, Download, Lock, Mic, Camera } from 'lucide-react';
import { useDragonAI } from '../hooks/useDragonAI';
import { useVoiceSearch } from '../hooks/useVoiceSearch';
import { Tab } from '../types';

interface SmartUrlBarProps {
  activeTab: Tab;
  urlInputValue: string;
  onUrlChange: (val: string) => void;
  onUrlSubmit: () => void;
  onReload: () => void;
  accentColor: string;
}

export const SmartUrlBar: React.FC<SmartUrlBarProps> = ({
  activeTab,
  urlInputValue,
  onUrlChange,
  onUrlSubmit,
  onReload,
  accentColor
}) => {
  const { suggestions, fetchSuggestions, setSuggestions } = useDragonAI();
  const [showSuggestions, setShowSuggestions] = useState(false);
  const inputRef = useRef<HTMLInputElement>(null);

  const { isListening, startListening } = useVoiceSearch((text) => {
    onUrlChange(text);
    onUrlSubmit();
  });

  useEffect(() => {
    const timer = setTimeout(() => {
      if (urlInputValue && document.activeElement === inputRef.current && !urlInputValue.startsWith('http')) {
        fetchSuggestions(urlInputValue);
      }
    }, 500);
    return () => clearTimeout(timer);
  }, [urlInputValue, fetchSuggestions]);

  const isSearch = !urlInputValue.includes('.') || urlInputValue.includes(' ');

  const handleLens = () => {
    window.open(`https://lens.google.com/uploadbyurl?url=${encodeURIComponent(activeTab.url)}`, '_blank');
  };

  return (
    <div className="flex-1 relative group">
      <form 
        onSubmit={(e) => { 
          e.preventDefault(); 
          setShowSuggestions(false);
          onUrlSubmit(); 
        }}
        className={`relative flex items-center bg-black/40 border rounded-full px-4 py-2.5 shadow-inner transition-all focus-within:bg-black/60 ${isListening ? 'border-dragon-cyan ring-2 ring-dragon-cyan/20' : 'border-white/10'}`}
      >
        {activeTab.isPrivate ? (
          <Lock className="w-4 h-4 mr-2 animate-pulse" style={{ color: accentColor }} />
        ) : isSearch ? (
           <img 
             src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" 
             alt="" 
             className="w-5 h-5 rounded-full object-cover mr-2 border border-white/10 shrink-0"
             onError={(e) => {
               (e.target as HTMLImageElement).style.display = 'none';
             }}
           />
        ) : (
           <Globe className="w-4 h-4 mr-2 text-slate-400" />
        )}

        <input
          ref={inputRef}
          className="flex-1 bg-transparent border-none outline-none text-sm text-white placeholder-slate-500 min-w-0"
          value={urlInputValue}
          onChange={(e) => {
            onUrlChange(e.target.value);
            setShowSuggestions(true);
          }}
          onFocus={() => setShowSuggestions(true)}
          onBlur={() => setTimeout(() => setShowSuggestions(false), 200)}
          placeholder={isListening ? "Listening..." : "Search or enter address"}
          autoCapitalize="off"
          autoComplete="off"
        />
        
        <div className="flex items-center gap-1">
          {!activeTab.url.includes('newtab') && (
            <button 
              type="button" 
              onClick={handleLens}
              className="p-1 text-slate-500 hover:text-dragon-cyan transition-colors"
            >
              <Camera className="w-4 h-4" />
            </button>
          )}

          <button 
            type="button" 
            onClick={startListening}
            className={`p-1 transition-colors ${isListening ? 'text-dragon-cyan' : 'text-slate-500 hover:text-white'}`}
          >
            <Mic className={`w-4 h-4 ${isListening ? 'animate-pulse' : ''}`} />
          </button>

          {activeTab.isLoading && (
            <RotateCw className="w-4 h-4 text-[var(--theme-color)] animate-spin ml-1" />
          )}
        </div>
      </form>

      {showSuggestions && suggestions.length > 0 && (
        <div className="absolute top-full left-0 right-0 mt-2 bg-dragon-navy/95 backdrop-blur-xl border border-white/10 rounded-xl shadow-2xl overflow-hidden z-50 animate-fade-in">
          <div className="px-3 py-2 text-[10px] text-slate-500 uppercase tracking-wider font-bold">Dragon Suggestions</div>
          {suggestions.map((s, idx) => (
            <button
              key={idx}
              className="w-full text-left px-4 py-3 hover:bg-white/5 flex items-center gap-3 transition-colors"
              onClick={() => {
                onUrlChange(s);
                onUrlSubmit();
                setSuggestions([]);
              }}
            >
              <Search className="w-4 h-4 text-[var(--theme-color)]" />
              <span className="text-sm text-slate-200">{s}</span>
            </button>
          ))}
        </div>
      )}
    </div>
  );
};
