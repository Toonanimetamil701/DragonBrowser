import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";

interface SplashScreenProps {
  onFinish?: () => void;
}

export const SplashScreen: React.FC<SplashScreenProps> = ({ onFinish }) => {
  const [hide, setHide] = useState(false);
  const subtitles = ["Make Some Difference", "Browse Without Limits", "Fast. Secure. Private."];
  const [subtitleIndex, setSubtitleIndex] = useState(0);

  // Splash duration & exit
  useEffect(() => {
    const timer = setTimeout(() => {
      setHide(true);
      setTimeout(() => onFinish?.(), 800); // wait for fade-out
    }, 1800);
    return () => clearTimeout(timer);
  }, [onFinish]);

  // Rotate subtitle
  useEffect(() => {
    const subTimer = setInterval(() => {
      setSubtitleIndex(prev => (prev + 1) % subtitles.length);
    }, 1500);
    return () => clearInterval(subTimer);
  }, []);

  return (
    <motion.div
      className="fixed inset-0 z-[9999] flex flex-col items-center justify-center bg-black overflow-hidden"
      initial={{ opacity: 1 }}
      animate={hide ? { opacity: 0 } : { opacity: 1 }}
      transition={{ duration: 0.8, ease: "easeInOut" }}
    >
      {/* Main Container */}
      <div className="flex flex-col items-center relative z-10">

        {/* Gradient Glow behind logo */}
        <div className="absolute top-1/2 left-1/2 -translate-x-1/2 -translate-y-1/2
          w-48 h-48 rounded-full animate-glow" />

        {/* Logo with shared transition */}
        <motion.div
          layoutId="logo"
          className="relative w-32 h-32 bg-[#050505] rounded-[2.5rem] p-1
            border border-white/10 shadow-[0_0_40px_rgba(0,0,0,0.5)] animate-breathe"
        >
          <img
            src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg"
            alt="Dragon Browser"
            onError={(e) => (e.currentTarget.style.display = "none")}
            className="w-full h-full object-cover rounded-[2.2rem]"
          />
        </motion.div>

        {/* Title */}
        <h1 className="text-4xl font-black text-white italic tracking-tighter uppercase mb-6 drop-shadow-2xl mt-6">
          Dragon Browser
        </h1>

        {/* Subtitle with rotating text */}
        <div className="flex items-center gap-4 mb-8">
          <div className="w-8 h-[2px] bg-gradient-to-r from-transparent to-orange-600 rounded-full opacity-60" />
          <span className="text-[10px] font-black text-orange-500 uppercase tracking-[0.3em] whitespace-nowrap">
            {subtitles[subtitleIndex]}
          </span>
          <div className="w-8 h-[2px] bg-gradient-to-l from-transparent to-orange-600 rounded-full opacity-60" />
        </div>

        {/* Shimmer Loading Bar */}
        <div className="w-24 h-[2px] bg-white/5 rounded-full overflow-hidden relative">
          <div className="absolute inset-y-0 w-12 bg-gradient-to-r from-transparent via-orange-500 to-transparent animate-shimmer" />
        </div>

        {/* Version */}
        <p className="absolute bottom-6 text-[10px] text-white/30 tracking-widest">
          v0.0.8A
        </p>
      </div>

      {/* Animations */}
      <style>{`
        /* Shimmer */
        @keyframes shimmer {
          0% { transform: translateX(-150%); }
          100% { transform: translateX(250%); }
        }
        .animate-shimmer { animation: shimmer 0.6s linear infinite alternate; }

        /* Breathing Logo */
        @keyframes logo-breathe {
          0%, 100% { transform: scale(1); }
          50% { transform: scale(1.03); }
        }
        .animate-breathe { animation: logo-breathe 2.5s ease-in-out infinite; }

        /* Gradient Glow */
        @keyframes glow-shift {
          0% { background-position: 0% 50%; }
          100% { background-position: 200% 50%; }
        }
        .animate-glow {
          background: linear-gradient(270deg, #f97316, #fbbf24, #f97316);
          background-size: 400% 400%;
          animation: glow-shift 5s ease infinite;
        }

        /* Pulse Slow (extra glow effect) */
        @keyframes pulse { 0%, 100% { opacity: 0.7; } 50% { opacity: 1; } }
        .animate-pulse-slow { animation: pulse 3s ease-in-out infinite; }
      `}</style>
    </motion.div>
  );
};