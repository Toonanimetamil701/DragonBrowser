
import React from 'react';
import { 
  ArrowRight, Star, Download, Info, RotateCw, 
  Plus, Ghost, History, Trash2, 
  Share2, Languages, Monitor, Settings, 
  Bookmark, FileDown,
  Moon, Shield, Radar, WifiOff, FileText, Globe
} from 'lucide-react';
import { useDragon } from '../DragonContext';
import { BrowserViewMode, Tab } from '../types';
import { Share } from '@capacitor/share';
import { isTranslatedUrl, getOriginalUrl } from '../utils/urlUtils';

interface MainMenuProps {
  activeTab?: Tab;
  onNavigate?: (url: string, options?: { isTranslation?: boolean, originalUrl?: string }) => void;
  onRefresh?: () => void;
  onForward?: () => void;
  onNewTab?: (isPrivate: boolean) => void;
  onOpenSiteSettings?: () => void;
}

interface MenuItem {
  label?: string;
  icon?: React.ReactNode;
  action?: () => void;
  separator?: boolean;
  isToggle?: boolean;
  toggleValue?: boolean;
  disabled?: boolean;
}

export const MainMenu: React.FC<MainMenuProps> = ({ 
  activeTab, 
  onNavigate, 
  onRefresh, 
  onForward, 
  onNewTab, 
  onOpenSiteSettings 
}) => {
  const { 
    settings, updateSettings, setViewMode, 
    bookmarks, toggleBookmark, 
    navigateTo, savePageOffline 
  } = useDragon();

  const isBookmarked = activeTab ? bookmarks.some(b => b.url === activeTab.url) : false;
  const isSite = activeTab && !activeTab.url.startsWith('dragon://');

  const closeMenu = () => setViewMode(BrowserViewMode.BROWSER);

  // Helper to update setting and close menu (Chrome behavior requested)
  const toggleSetting = (key: keyof typeof settings) => {
    updateSettings({ [key]: !settings[key] });
    // Keep menu open for toggles to allow rapid changes, or close with delay
    setTimeout(closeMenu, 250); 
  };

  const handleToggleDesktop = () => {
    toggleSetting('isDesktopMode');
    if (onRefresh) setTimeout(onRefresh, 200);
  };

  const handleShare = async () => {
    if (!activeTab) return;
    try {
      await Share.share({
        title: activeTab.title,
        text: activeTab.title,
        url: activeTab.url,
        dialogTitle: 'Share via'
      });
    } catch (e) {
      console.warn('Share failed', e);
    }
    closeMenu();
  };

  const handleTranslate = () => {
    if (!activeTab || !onNavigate || !isSite) return;
    
    const isTranslated = activeTab.isTranslated || isTranslatedUrl(activeTab.url);

    if (isTranslated) {
      const originalUrl = activeTab.originalUrl || getOriginalUrl(activeTab.url);
      onNavigate(originalUrl, { isTranslation: false });
    } else {
      const targetLang = settings.translationSettings?.targetLanguage || settings.language || 'en';
      const langCode = targetLang.split('-')[0];
      const encodedUrl = encodeURIComponent(activeTab.url);
      const targetUrl = `https://translate.google.com/translate?sl=auto&tl=${langCode}&u=${encodedUrl}`;
      
      onNavigate(targetUrl, { isTranslation: true, originalUrl: activeTab.url });
    }
    closeMenu();
  };

  const handleDownloadPage = () => {
    if (activeTab && isSite) {
      savePageOffline(activeTab.url, activeTab.title);
      closeMenu();
    }
  };

  const isDarkActive = () => {
    if (settings.themeMode === 'dark') return true;
    if (settings.themeMode === 'light') return false;
    return window.matchMedia('(prefers-color-scheme: dark)').matches;
  };

  const handleToggleTheme = () => {
    const current = isDarkActive();
    updateSettings({ themeMode: current ? 'light' : 'dark' });
    setTimeout(closeMenu, 250);
  };

  const QuickAction = ({ icon, onClick, active, disabled, label }: any) => (
    <button 
      onClick={onClick}
      disabled={disabled}
      className={`
        flex flex-col items-center justify-center gap-1.5 p-3 rounded-2xl transition-all duration-200 active:scale-95 group
        ${active ? 'bg-dragon-ember text-white shadow-lg shadow-dragon-ember/20' : 'bg-white/5 text-slate-400 hover:bg-white/10 hover:text-white'}
        ${disabled ? 'opacity-30 cursor-not-allowed' : ''}
      `}
    >
      <div className={`transition-transform duration-200 ${active ? 'scale-110' : 'group-hover:scale-110'}`}>
        {icon}
      </div>
    </button>
  );

  const menuItems: MenuItem[] = [
    { 
      label: 'New Tab', 
      icon: <Plus size={18} />, 
      action: () => { onNewTab?.(false); closeMenu(); } 
    },
    { 
      label: 'New Incognito Tab', 
      icon: <Ghost size={18} />, 
      action: () => { onNewTab?.(true); closeMenu(); } 
    },
    { separator: true },
    { 
      label: 'History', 
      icon: <History size={18} />, 
      action: () => navigateTo(BrowserViewMode.HISTORY) 
    },
    { 
      label: 'Clear Data', 
      icon: <Trash2 size={18} />, 
      action: () => navigateTo(BrowserViewMode.CLEAR_DATA)
    },
    { separator: true },
    { 
      label: 'Downloads', 
      icon: <FileDown size={18} />, 
      action: () => navigateTo(BrowserViewMode.DOWNLOADS) 
    },
    { 
      label: 'Bookmarks', 
      icon: <Bookmark size={18} />, 
      action: () => navigateTo(BrowserViewMode.BOOKMARKS) 
    },
    { 
      label: 'Notes', 
      icon: <FileText size={18} />, 
      action: () => navigateTo(BrowserViewMode.NOTES_LIBRARY) 
    },
    { separator: true },
    { 
      label: 'Share', 
      icon: <Share2 size={18} />, 
      action: handleShare,
    },
    { separator: true },
    // Global Toggles
    { 
      label: 'Dark Mode', 
      icon: <Moon size={18} />, 
      action: handleToggleTheme,
      isToggle: true,
      toggleValue: isDarkActive()
    },
    { 
      label: 'Ad Blocker', 
      icon: <Shield size={18} />, 
      action: () => toggleSetting('adBlockEnabled'),
      isToggle: true,
      toggleValue: settings.adBlockEnabled 
    },
    { 
      label: 'Tracker Blocker', 
      icon: <Radar size={18} />, 
      action: () => toggleSetting('trackerBlockingEnabled'),
      isToggle: true,
      toggleValue: settings.trackerBlockingEnabled 
    },
    { 
      label: 'Data Saver', 
      icon: <WifiOff size={18} />, 
      action: () => toggleSetting('dataSaverEnabled'),
      isToggle: true,
      toggleValue: settings.dataSaverEnabled 
    },
    // Site Specific Toggles
    ...(isSite ? [
      { 
        label: 'Translate', 
        icon: <Languages size={18} />, 
        action: handleTranslate 
      },
      { 
        label: 'Desktop Site', 
        icon: <Monitor size={18} />, 
        action: handleToggleDesktop,
        isToggle: true,
        toggleValue: settings.isDesktopMode 
      },
      {
        label: 'Site Settings',
        icon: <Globe size={18} />,
        action: () => { onOpenSiteSettings?.(); closeMenu(); }
      }
    ] : []),
    { separator: true },
    { 
      label: 'Settings', 
      icon: <Settings size={18} />, 
      action: () => navigateTo(BrowserViewMode.SETTINGS) 
    },
  ];

  return (
    <div className="fixed inset-0 z-[150] flex justify-end isolate">
      {/* Dimmed Backdrop - Closes menu on click */}
      <div 
        className="absolute inset-0 bg-black/60 backdrop-blur-sm animate-fade-in" 
        onClick={closeMenu} 
      />
      
      {/* Menu Panel - Premium Style */}
      <div className="relative z-10 flex flex-col h-full w-[85vw] max-w-[320px] bg-[#0a0a0a]/95 backdrop-blur-3xl text-slate-200 shadow-2xl animate-slide-in-right border-l border-white/10 overflow-hidden">
        
        {/* Quick Actions Grid */}
        <div className="p-4 grid grid-cols-5 gap-2 border-b border-white/5 bg-white/[0.02]">
          <QuickAction 
            icon={<ArrowRight size={20} />} 
            onClick={onForward} 
            disabled={false} // Forward logic check could be added if available
          />
          <QuickAction 
            icon={<Star size={20} className={isBookmarked ? "fill-current" : ""} />} 
            onClick={() => { 
              if(activeTab) {
                toggleBookmark(activeTab.url, activeTab.title);
                closeMenu(); 
              }
            }} 
            active={isBookmarked}
          />
          <QuickAction 
            icon={<Download size={20} />} 
            onClick={handleDownloadPage} 
            disabled={!isSite}
          />
          <QuickAction 
            icon={<Info size={20} />} 
            onClick={() => { onOpenSiteSettings?.(); closeMenu(); }} 
          />
          <QuickAction 
            icon={<RotateCw size={20} />} 
            onClick={() => { onRefresh?.(); closeMenu(); }} 
          />
        </div>

        {/* Menu List */}
        <div className="flex-1 overflow-y-auto no-scrollbar py-2">
          {menuItems.map((item, index) => {
            if (item.separator) {
              return <div key={index} className="h-px bg-white/5 my-2 mx-6" />;
            }

            return (
              <button
                key={index}
                onClick={item.action}
                disabled={item.disabled}
                className={`
                  w-full flex items-center justify-between px-6 py-3.5 transition-colors text-left group
                  ${item.disabled ? 'opacity-40 cursor-not-allowed' : 'hover:bg-white/5 active:bg-white/10'}
                `}
              >
                <div className="flex items-center gap-4">
                  <div className={`transition-colors duration-300 ${item.isToggle && item.toggleValue ? 'text-dragon-ember' : 'text-slate-400 group-hover:text-white'}`}>
                    {item.icon}
                  </div>
                  <span className={`text-[13px] font-bold tracking-wide transition-colors duration-300 ${item.isToggle && item.toggleValue ? 'text-white' : 'text-slate-300 group-hover:text-white'}`}>
                    {item.label}
                  </span>
                </div>
                
                {item.isToggle && (
                  <div className={`w-9 h-5 rounded-full relative transition-colors duration-300 ${item.toggleValue ? 'bg-dragon-ember' : 'bg-slate-700/50 border border-white/5'}`}>
                    <div className={`absolute top-1 w-3 h-3 bg-white rounded-full shadow-md transition-transform duration-300 ${item.toggleValue ? 'translate-x-5' : 'translate-x-1'}`} />
                  </div>
                )}
              </button>
            );
          })}
        </div>
        
        {/* Footer info (optional) */}
        <div className="p-4 border-t border-white/5 bg-black/20 text-center">
           <p className="text-[9px] font-black text-slate-600 uppercase tracking-[0.3em]">Dragon Browser</p>
        </div>
      </div>
    </div>
  );
};
