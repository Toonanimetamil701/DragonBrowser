
import React, { useState, useRef } from 'react';
import { 
  Shield, Moon, Sun, 
  Bookmark, Download, History, Palette, 
  X, ChevronRight, Settings, ChevronLeft, Image as ImageIcon, Layout,
  Camera, Mic, Monitor, Globe, Star, Plus, Check, Upload, ShieldCheck, FileText,
  Smartphone, Pencil
} from 'lucide-react';
import { useDragon } from '../DragonContext';
import { BrowserViewMode, ThemeMode, ToolbarConfig } from '../types';

const WALLPAPER_PRESETS = [
  { id: 'default', name: 'Dragon', url: 'https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg' },
  { id: 'void', name: 'Void', url: '' },
  { id: 'cyber', name: 'Cyber', url: 'https://images.unsplash.com/photo-1550745165-9bc0b252726f?q=80&w=1000' },
  { id: 'abyssal', name: 'Abyssal', url: 'https://images.unsplash.com/photo-1550684848-fac1c5b4e853?q=80&w=1000' },
  { id: 'ember_storm', name: 'Storm', url: 'https://images.unsplash.com/photo-1618005182384-a83a8bd57fbe?q=80&w=1000' },
];

export const MainMenu: React.FC = () => {
  const { settings, updateSettings, setViewMode, setNotesEntrySource, bookmarks, history, downloads, notes } = useDragon();
  const [menuView, setMenuView] = useState<'MAIN' | 'APPEARANCE'>('MAIN');
  const fileInputRef = useRef<HTMLInputElement>(null);

  const handleToggleAdBlock = () => {
    updateSettings({ adBlockEnabled: !settings.adBlockEnabled });
  };

  const handleToggleNightMode = () => {
    // Cycle: system -> light -> dark -> system
    let nextMode: ThemeMode = 'dark';
    if (settings.themeMode === 'dark') nextMode = 'system';
    else if (settings.themeMode === 'system') nextMode = 'light';
    else if (settings.themeMode === 'light') nextMode = 'dark';
    
    updateSettings({ themeMode: nextMode });
  };

  const handleToolbarToggle = (key: keyof ToolbarConfig) => {
    updateSettings({ 
      toolbarConfig: { ...settings.toolbarConfig, [key]: !settings.toolbarConfig[key] } 
    });
  };

  const navigateTo = (mode: BrowserViewMode) => {
    if (mode === BrowserViewMode.NOTES_LIBRARY) {
      setNotesEntrySource('menu');
    }
    setViewMode(mode);
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        const base64String = reader.result as string;
        updateSettings({ wallpaper: base64String });
      };
      reader.readAsDataURL(file);
    }
  };

  const triggerFileUpload = () => {
    fileInputRef.current?.click();
  };

  if (menuView === 'APPEARANCE') {
    const isCustomWallpaper = settings.wallpaper.startsWith('data:');

    return (
      <div className="flex flex-col h-full bg-slate-50 dark:bg-[#0a0a0a] text-slate-900 dark:text-slate-100 animate-fade-in overflow-y-auto no-scrollbar transition-colors duration-300">
        {/* Sub-menu Header */}
        <div className="px-6 pt-safe-top flex items-center h-24 border-b border-slate-200 dark:border-white/5 bg-white dark:bg-black/40 backdrop-blur-xl sticky top-0 z-10">
          <button 
            onClick={() => setMenuView('MAIN')}
            className="p-3 bg-slate-100 dark:bg-white/5 rounded-2xl text-dragon-ember transition-all active:scale-90"
          >
            <ChevronLeft size={24} />
          </button>
          <div className="ml-5">
            <h3 className="text-base font-black uppercase tracking-widest text-slate-900 dark:text-white">Appearance</h3>
            <p className="text-[10px] font-bold text-slate-400 uppercase tracking-widest mt-0.5">Interface Aesthetics</p>
          </div>
        </div>

        <div className="p-6 space-y-10 pb-32">
          {/* Theme Mode Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 px-2">
              <Palette size={14} className="text-dragon-ember" />
              <h4 className="text-[10px] font-black uppercase tracking-[0.25em] text-slate-400">Interface Mode</h4>
            </div>
            <div className="grid grid-cols-3 gap-3">
              {[
                { id: 'light', name: 'Light', icon: <Sun size={18} /> },
                { id: 'dark', name: 'Dark', icon: <Moon size={18} /> },
                { id: 'system', name: 'System', icon: <Smartphone size={18} /> },
              ].map(t => (
                <button 
                  key={t.id}
                  onClick={() => updateSettings({ themeMode: t.id as any })}
                  className={`flex flex-col items-center justify-center gap-3 p-5 rounded-[2rem] border transition-all ${settings.themeMode === t.id ? 'bg-dragon-ember/10 border-dragon-ember/40 text-dragon-ember shadow-lg shadow-dragon-ember/5' : 'bg-white dark:bg-white/5 border-slate-200 dark:border-transparent text-slate-400 hover:bg-white/10'}`}
                >
                  {t.icon}
                  <span className="text-[9px] font-black uppercase tracking-widest">{t.name}</span>
                </button>
              ))}
            </div>
          </div>

          {/* Wallpapers Section */}
          <div className="space-y-4">
            <div className="flex items-center justify-between px-2">
              <div className="flex items-center gap-2">
                <ImageIcon size={14} className="text-pink-400" />
                <h4 className="text-[10px] font-black uppercase tracking-[0.25em] text-slate-400">Wallpapers</h4>
              </div>
              <input 
                type="file" 
                ref={fileInputRef} 
                onChange={handleFileUpload} 
                accept="image/*" 
                className="hidden" 
              />
            </div>
            
            <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2 px-1">
              {/* Upload Button */}
              <button
                onClick={triggerFileUpload}
                className="relative shrink-0 w-28 h-36 rounded-[2rem] overflow-hidden border-2 border-dashed border-slate-300 dark:border-white/10 bg-white dark:bg-white/5 flex flex-col items-center justify-center gap-2 hover:bg-white/10 transition-all group"
              >
                <Upload size={20} className="text-slate-400 group-hover:text-dragon-ember" />
                <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest">Upload</span>
              </button>

              {/* Custom Image Preview if exists */}
              {isCustomWallpaper && (
                <button
                  onClick={() => updateSettings({ wallpaper: settings.wallpaper })} // Set to self to ensure active
                  className={`relative shrink-0 w-28 h-36 rounded-[2rem] overflow-hidden border-2 transition-all ${!WALLPAPER_PRESETS.some(p => p.id === settings.wallpaper) ? 'border-dragon-ember ring-4 ring-dragon-ember/20' : 'border-transparent opacity-60'}`}
                >
                  <img src={settings.wallpaper} className="w-full h-full object-cover" alt="Custom" />
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-3">
                    <span className="text-[8px] font-black text-white uppercase tracking-widest">Custom</span>
                  </div>
                  {!WALLPAPER_PRESETS.some(p => p.id === settings.wallpaper) && (
                    <div className="absolute top-3 right-3 bg-dragon-ember rounded-full p-1 shadow-lg">
                      <Check size={10} className="text-white" strokeWidth={4} />
                    </div>
                  )}
                </button>
              )}

              {WALLPAPER_PRESETS.map((wp) => (
                <button
                  key={wp.id}
                  onClick={() => updateSettings({ wallpaper: wp.id })}
                  className={`relative shrink-0 w-28 h-36 rounded-[2rem] overflow-hidden border-2 transition-all shadow-lg ${settings.wallpaper === wp.id ? 'border-dragon-ember ring-4 ring-dragon-ember/20 scale-[1.02]' : 'border-transparent opacity-60 hover:opacity-100'}`}
                >
                  {wp.url ? (
                    <img src={wp.url} className="w-full h-full object-cover" alt={wp.name} />
                  ) : (
                    <div className="w-full h-full bg-slate-900 flex items-center justify-center text-slate-700">
                      <Shield size={24} />
                    </div>
                  )}
                  <div className="absolute inset-0 bg-gradient-to-t from-black/80 to-transparent flex items-end p-3">
                    <span className="text-[8px] font-black text-white uppercase tracking-widest">{wp.name}</span>
                  </div>
                  {settings.wallpaper === wp.id && (
                    <div className="absolute top-3 right-3 bg-dragon-ember rounded-full p-1 shadow-lg">
                      <Check size={10} className="text-white" strokeWidth={4} />
                    </div>
                  )}
                </button>
              ))}
            </div>
          </div>

          {/* Toolbar Customization Section */}
          <div className="space-y-4">
            <div className="flex items-center gap-2 px-2">
              <Layout size={14} className="text-blue-400" />
              <h4 className="text-[10px] font-black uppercase tracking-[0.25em] text-slate-400">Toolbar Configuration</h4>
            </div>
            <div className="bg-white dark:bg-white/5 rounded-[2.5rem] border border-slate-200 dark:border-white/5 overflow-hidden shadow-sm">
              {[
                { id: 'showLens', label: 'Google Lens', icon: <Camera size={18} /> },
                { id: 'showMic', label: 'Voice Search', icon: <Mic size={18} /> },
                { id: 'showNotes', label: 'Quick Notes', icon: <Pencil size={18} /> },
                { id: 'showDesktopMode', label: 'Desktop Mode', icon: <Monitor size={18} /> },
                { id: 'showBookmark', label: 'Bookmarks', icon: <Star size={18} /> },
                { id: 'showNewTab', label: 'New Tab', icon: <Plus size={18} /> },
              ].map((tool) => (
                <div key={tool.id} className="flex items-center justify-between p-5 border-b border-slate-100 dark:border-white/5 last:border-0 hover:bg-slate-50 dark:hover:bg-white/5 transition-colors">
                  <div className="flex items-center gap-4">
                    <div className="p-2.5 bg-slate-100 dark:bg-black/40 rounded-xl text-slate-500">
                      {tool.icon}
                    </div>
                    <span className="text-xs font-black uppercase text-slate-800 dark:text-slate-200 tracking-tight">{tool.label}</span>
                  </div>
                  <button 
                    onClick={() => handleToolbarToggle(tool.id as keyof ToolbarConfig)}
                    className={`w-11 h-6 rounded-full relative transition-all duration-300 ${settings.toolbarConfig[tool.id as keyof ToolbarConfig] ? 'bg-dragon-ember' : 'bg-slate-300 dark:bg-slate-700'}`}
                  >
                    <div className={`absolute top-1 w-4 h-4 bg-white rounded-full shadow-lg transition-all duration-300 ${settings.toolbarConfig[tool.id as keyof ToolbarConfig] ? 'translate-x-6' : 'translate-x-1'}`} />
                  </button>
                </div>
              ))}
            </div>
          </div>
        </div>

        {/* Footer Close Button */}
        <div className="p-6 border-t border-slate-200 dark:border-white/5 mt-auto bg-white/50 dark:bg-black/40 sticky bottom-0 backdrop-blur-xl">
          <button 
            onClick={() => setMenuView('MAIN')}
            className="w-full py-4 bg-slate-100 dark:bg-white/5 border border-slate-200 dark:border-white/10 rounded-2xl flex items-center justify-center gap-3 font-black uppercase text-[10px] tracking-[0.2em] text-slate-500 hover:text-slate-900 dark:hover:text-white transition-all active:scale-95"
          >
            Return to Menu
          </button>
        </div>
      </div>
    );
  }

  const isDarkModeActive = settings.themeMode === 'dark' || (settings.themeMode === 'system' && window.matchMedia('(prefers-color-scheme: dark)').matches);

  return (
    <div className="flex flex-col h-full bg-slate-50 dark:bg-[#0a0a0a] text-slate-900 dark:text-slate-100 animate-fade-in overflow-y-auto no-scrollbar transition-colors duration-300">
      
      {/* Top Header - Settings Quick Access */}
      <div className="px-6 pt-safe-top flex justify-end items-center h-16">
        <button 
          onClick={() => navigateTo(BrowserViewMode.SETTINGS)}
          className="p-3 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 rounded-2xl text-slate-400 hover:text-dragon-ember transition-all active:scale-90 shadow-sm"
          title="Browser Settings"
        >
          <Settings size={22} strokeWidth={2.5} />
        </button>
      </div>

      {/* Quick Toggles Grid */}
      <div className="grid grid-cols-2 gap-4 p-6 pt-2">
        {[
          { 
            label: 'Ad Blocker', 
            icon: <Shield size={18} />, 
            status: settings.adBlockEnabled ? 'Armed' : 'Off', 
            active: settings.adBlockEnabled,
            onClick: handleToggleAdBlock 
          },
          { 
            label: 'Theme Mode', 
            icon: settings.themeMode === 'system' ? <Smartphone size={18} /> : (settings.themeMode === 'dark' ? <Moon size={18} /> : <Sun size={18} />), 
            status: settings.themeMode.toUpperCase(), 
            active: settings.themeMode !== 'light',
            onClick: handleToggleNightMode
          },
        ].map((item, idx) => (
          <button 
            key={idx} 
            onClick={item.onClick}
            className={`flex items-center gap-4 p-5 rounded-3xl border transition-all ${item.active ? 'bg-dragon-ember/10 text-dragon-ember border-dragon-ember/30 shadow-lg shadow-dragon-ember/5' : 'bg-white dark:bg-white/5 text-slate-500 border-slate-200 dark:border-white/5 hover:bg-white/10 shadow-sm'}`}
          >
            <div className={`shrink-0 ${item.active ? 'text-dragon-ember' : 'text-slate-400'}`}>
              {item.icon}
            </div>
            <div className="text-left min-w-0">
              <span className="text-[10px] font-black uppercase block tracking-tighter truncate">{item.label}</span>
              <span className={`text-[9px] font-bold uppercase tracking-widest mt-0.5 ${item.active ? 'text-dragon-ember' : 'text-slate-400'}`}>{item.status}</span>
            </div>
          </button>
        ))}
      </div>

      {/* Main Feature Grid (2 columns) */}
      <div className="px-6 grid grid-cols-2 gap-3">
        {[
          { id: 'bookmarks', label: 'Bookmarks', icon: <Bookmark size={20} className="text-blue-500" />, count: bookmarks.length, view: BrowserViewMode.BOOKMARKS },
          { id: 'downloads', label: 'Downloads', icon: <Download size={20} className="text-green-500" />, count: downloads.length, view: BrowserViewMode.DOWNLOADS },
          { id: 'history', label: 'History', icon: <History size={20} className="text-orange-500" />, count: history.length, view: BrowserViewMode.HISTORY },
          { id: 'notes', label: 'Notes', icon: <FileText size={20} className="text-pink-500" />, count: notes.length, view: BrowserViewMode.NOTES_LIBRARY },
        ].map((item, idx) => (
          <button
            key={item.id}
            onClick={() => navigateTo(item.view)}
            className={`flex items-center gap-4 p-5 bg-white dark:bg-white/5 border border-slate-200 dark:border-white/5 rounded-3xl hover:bg-slate-50 dark:hover:bg-white/10 transition-all text-left group shadow-sm`}
          >
            <div className="shrink-0 group-hover:scale-110 transition-transform">
              {item.icon}
            </div>
            <div className="flex-1 min-w-0">
              <span className="text-xs font-black uppercase text-slate-800 dark:text-slate-200 block truncate tracking-tight">{item.label}</span>
              <span className="text-[8px] font-black text-slate-400 uppercase tracking-widest mt-0.5">{item.count} Fragments</span>
            </div>
          </button>
        ))}
      </div>

      {/* List Actions */}
      <div className="px-6 py-8 space-y-2">
        {[
          { 
            label: 'Appearance', 
            sub: 'Personalize colors & toolbars', 
            icon: <Palette size={18} className="text-pink-400" />, 
            action: () => setMenuView('APPEARANCE') 
          },
          { 
            label: 'Dragon Shield', 
            sub: 'Heuristic security matrix', 
            icon: <ShieldCheck size={18} className="text-dragon-cyan" />, 
            action: () => navigateTo(BrowserViewMode.SHIELD) 
          },
        ].map((item, idx) => (
          <button 
            key={idx}
            onClick={item.action}
            className="w-full flex items-center justify-between p-5 hover:bg-white dark:hover:bg-white/5 rounded-3xl transition-all group border border-transparent hover:border-slate-200 dark:hover:border-white/5"
          >
            <div className="flex items-center gap-5">
              <div className="p-3 bg-white dark:bg-white/5 rounded-2xl text-slate-400 group-hover:text-dragon-ember transition-all shadow-sm group-hover:shadow-md">
                {item.icon}
              </div>
              <div className="text-left">
                <span className="text-sm font-black text-slate-800 dark:text-slate-200 block uppercase tracking-tight">{item.label}</span>
                <span className="text-[10px] text-slate-400 dark:text-slate-500 font-bold uppercase tracking-widest">{item.sub}</span>
              </div>
            </div>
            <ChevronRight size={18} className="text-slate-300 group-hover:text-dragon-cyan transition-colors" />
          </button>
        ))}
      </div>

      {/* Footer Close Button */}
      <div className="p-6 border-t border-slate-200 dark:border-white/5 mt-auto bg-white/50 dark:bg-black/40 backdrop-blur-xl">
        <button 
          onClick={() => navigateTo(BrowserViewMode.BROWSER)}
          className="w-full py-4 bg-slate-900 dark:bg-white/5 border border-transparent dark:border-white/10 rounded-2xl flex items-center justify-center gap-3 font-black uppercase text-[11px] tracking-[0.25em] text-white dark:text-slate-400 hover:brightness-110 transition-all active:scale-95 shadow-xl"
        >
          <X size={16} /> Close Menu
        </button>
      </div>
    </div>
  );
};
