
import React, { useState } from 'react';
import { useDragon } from '../DragonContext';
import { 
  X, File, FileText, Video, Music, Image as ImageIcon, 
  Trash2, Download, Search, ChevronLeft, Filter, Sparkles
} from 'lucide-react';
import { DownloadItem, BrowserViewMode } from '../types';

export const Downloads: React.FC = () => {
  const { downloads, setViewMode } = useDragon();
  const [filter, setFilter] = useState<string>('all');
  const [search, setSearch] = useState('');

  const filteredDownloads = downloads.filter(d => {
    const matchesSearch = d.filename.toLowerCase().includes(search.toLowerCase());
    const matchesFilter = filter === 'all' || d.type === filter;
    return matchesSearch && matchesFilter;
  });

  const getIcon = (type: string) => {
    switch (type) {
      case 'image': return <ImageIcon className="w-6 h-6 text-purple-400" />;
      case 'video': return <Video className="w-6 h-6 text-red-400" />;
      case 'audio': return <Music className="w-6 h-6 text-green-400" />;
      case 'pdf': return <FileText className="w-6 h-6 text-orange-400" />;
      default: return <File className="w-6 h-6 text-slate-400" />;
    }
  };

  const categories = [
    { id: 'all', label: 'All Artifacts' },
    { id: 'image', label: 'Visuals' },
    { id: 'video', label: 'Motion' },
    { id: 'audio', label: 'Sonic' },
    { id: 'pdf', label: 'Archives' },
    { id: 'other', label: 'Fragments' },
  ];

  return (
    <div className="flex flex-col h-full bg-dragon-dark text-slate-100 animate-fade-in pb-safe-bottom">
      <div className="p-8 pt-safe-top bg-dragon-navy/60 backdrop-blur-2xl sticky top-0 z-10 border-b border-white/5 flex items-center gap-6">
        <button 
          onClick={() => setViewMode(BrowserViewMode.BROWSER)} 
          className="p-3 bg-white/5 rounded-2xl hover:bg-white/10 transition-colors shadow-lg"
        >
          <ChevronLeft className="w-6 h-6" />
        </button>
        <div>
          <h2 className="text-2xl font-black tracking-tight">MY DOWNLOADS</h2>
          <p className="text-[10px] text-slate-500 font-bold uppercase tracking-widest">Secure Storage Active</p>
        </div>
      </div>

      <div className="p-6 space-y-6">
        <div className="relative group">
          <div className="absolute inset-y-0 left-5 flex items-center pointer-events-none">
            <Search className="w-5 h-5 text-slate-500 group-focus-within:text-dragon-cyan transition-colors" />
          </div>
          <input 
            type="text"
            placeholder="Search files..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="w-full bg-dragon-navy/50 border border-white/10 rounded-3xl py-5 pl-14 pr-6 text-base text-white placeholder-slate-600 focus:outline-none focus:border-dragon-cyan focus:ring-4 focus:ring-dragon-cyan/10 transition-all shadow-inner"
          />
        </div>

        <div className="flex gap-3 overflow-x-auto no-scrollbar pb-2 px-1">
          {categories.map(cat => (
            <button
              key={cat.id}
              onClick={() => setFilter(cat.id)}
              className={`px-6 py-3 rounded-full text-xs font-black transition-all whitespace-nowrap border-2 ${
                filter === cat.id 
                ? 'bg-dragon-cyan border-dragon-cyan text-dragon-dark shadow-[0_10px_20px_rgba(6,182,212,0.3)]' 
                : 'bg-white/5 border-white/10 text-slate-500 hover:text-slate-300 hover:border-white/20'
              }`}
            >
              {cat.label.toUpperCase()}
            </button>
          ))}
        </div>

        <div className="space-y-4">
          {filteredDownloads.length === 0 ? (
            <div className="py-32 text-center space-y-6 animate-pulse">
              <div className="relative inline-block">
                <div className="absolute -inset-10 bg-dragon-cyan/10 blur-3xl rounded-full" />
                <Download className="w-24 h-24 mx-auto text-slate-800" />
              </div>
              <div className="space-y-2">
                <p className="text-xl font-black text-slate-700 uppercase tracking-widest">Archive Void</p>
                <p className="text-xs text-slate-800 font-bold uppercase tracking-tighter">No neural fragments detected in the hoard</p>
              </div>
            </div>
          ) : (
            filteredDownloads.map(d => (
              <div key={d.id} className="relative group">
                <div className="absolute -inset-0.5 bg-gradient-to-r from-dragon-cyan/20 to-transparent rounded-[2.5rem] opacity-0 group-hover:opacity-100 transition-opacity blur" />
                <div className="relative bg-dragon-navy/30 rounded-[2.5rem] p-6 border border-white/5 flex items-center gap-6 group hover:bg-white/5 transition-all shadow-xl">
                  <div className="w-16 h-16 rounded-3xl bg-black/40 flex items-center justify-center shadow-inner border border-white/5 group-hover:scale-110 transition-transform">
                    {getIcon(d.type)}
                  </div>
                  <div className="flex-1 min-w-0">
                    <h4 className="text-lg font-black truncate text-white tracking-tight">{d.filename}</h4>
                    <div className="flex items-center gap-3 mt-1.5">
                      <div className="flex items-center gap-1.5">
                        <Sparkles className="w-3 h-3 text-slate-600" />
                        <span className="text-[11px] text-slate-500 font-black uppercase tracking-tighter">{d.size}</span>
                      </div>
                      <span className="text-[11px] text-slate-700">•</span>
                      <span className={`text-[11px] font-black tracking-widest ${d.status === 'completed' ? 'text-green-500' : 'text-dragon-ember animate-pulse'}`}>
                        {d.status.toUpperCase()}
                      </span>
                    </div>
                    {d.status === 'downloading' && (
                      <div className="w-full h-2 bg-white/5 rounded-full mt-4 overflow-hidden border border-white/5 shadow-inner">
                        <div 
                          className="h-full bg-gradient-to-r from-dragon-cyan to-blue-500 transition-all duration-700 ease-out shadow-[0_0_10px_rgba(6,182,212,0.5)]" 
                          style={{ width: `${d.progress}%` }} 
                        />
                      </div>
                    )}
                  </div>
                  <button className="p-4 bg-red-500/5 text-slate-700 hover:text-red-500 hover:bg-red-500/10 rounded-2xl transition-all opacity-0 group-hover:opacity-100 shadow-lg">
                    <Trash2 className="w-6 h-6" />
                  </button>
                </div>
              </div>
            ))
          )}
        </div>
      </div>
    </div>
  );
};
