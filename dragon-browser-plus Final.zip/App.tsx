
import React, { useState, useEffect, useCallback } from 'react';
import { DragonProvider, useDragon } from './DragonContext';
import { SplashScreen } from './components/SplashScreen';
import { NewTabPage } from './components/NewTabPage';
import { BrowserViewport } from './components/BrowserViewport';
import { FireProgressBar } from './components/FireProgressBar';
import { Settings } from './pages/Settings';
import { Downloads } from './pages/Downloads';
import { History } from './pages/History';
import { Bookmarks } from './pages/Bookmarks';
import { ShieldPage } from './pages/ShieldPage';
import { TabSwitcher } from './components/TabSwitcher';
import { QuickNotesPopup } from './components/QuickNotesPopup';
import { NotesLibrary } from './pages/NotesLibrary';
import { BrowserViewMode, Tab } from './types';
import { Home, Shield, Download, Settings as SettingsIcon, Star, ChevronLeft, RotateCcw, Monitor, Mic, Search, Languages, X, Layers, ChevronUp, ChevronDown, Pencil, Plus, Sparkles, Copy, CheckCircle } from 'lucide-react';
import { useTabs } from './hooks/useTabs';
import { useDragonEngine } from './services/BrowserEngine';
import { normalizeUrl, getDisplayTitle } from './utils/urlUtils';
import { AddressBar } from './components/AddressBar';
import { useVoiceSearch } from './hooks/useVoiceSearch';
import { useDragonAI } from './hooks/useDragonAI';
import { motion } from 'framer-motion';

const AppContent = () => {
  const { settings, viewMode, setViewMode, updateSettings, addHistory, bookmarks, toggleBookmark } = useDragon();
  const engine = useDragonEngine();
  const { 
    tabs, activeTab, goBack, navigateTab, setTabLoading, 
    createTab, reloadTab, closeTab, setActiveTabId, setTabs,
    clearCurrentSession, closeIncognitoTabs
  } = useTabs(settings.stealthFlight, settings.searchEngine);
  
  const [urlInputValue, setUrlInputValue] = useState('');
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [isNotesPopupOpen, setIsNotesPopupOpen] = useState(false);
  const [showBookmarkToast, setShowBookmarkToast] = useState(false);
  
  // AI Hooks
  const { summary, isSummarizing, generateSummary, clearSummary } = useDragonAI();

  // Permission Request on Mount
  useEffect(() => {
    const requestRuntimePermissions = async () => {
      try {
        await navigator.mediaDevices.getUserMedia({ audio: true }).catch((err) => console.log('Mic permission skipped', err));
        await navigator.mediaDevices.getUserMedia({ video: true }).catch((err) => console.log('Camera permission skipped', err));
        if (navigator.geolocation) {
          navigator.geolocation.getCurrentPosition(() => {}, () => {});
        }
      } catch (error) {
        console.warn("Permission auto-request failed:", error);
      }
    };
    requestRuntimePermissions();
  }, []);

  // Apply Theme Logic
  useEffect(() => {
    const root = window.document.documentElement;
    const applyTheme = () => {
       const isSystemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
       const isDark = settings.themeMode === 'dark' || (settings.themeMode === 'system' && isSystemDark);
       
       if (isDark) {
         root.classList.add('dark');
       } else {
         root.classList.remove('dark');
       }
    };
    applyTheme();
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handleChange = () => {
        if (settings.themeMode === 'system') applyTheme();
    };
    mediaQuery.addEventListener('change', handleChange);
    return () => mediaQuery.removeEventListener('change', handleChange);
  }, [settings.themeMode]);

  const handleReload = useCallback(() => {
    reloadTab();
    setRefreshTrigger(prev => prev + 1);
  }, [reloadTab]);

  const { isListening, interimTranscript, startListening } = useVoiceSearch((transcript) => {
    setUrlInputValue(transcript);
    handleNavigate(transcript);
  });

  useEffect(() => {
    if (isListening && interimTranscript) {
      setUrlInputValue(interimTranscript);
    }
  }, [isListening, interimTranscript]);

  useEffect(() => {
    if (!isListening) {
      if (activeTab.url === 'dragon://home') {
        setUrlInputValue('');
      } else {
        setUrlInputValue(activeTab.url);
      }
    }
  }, [activeTab.url, isListening]);

  const handleNavigate = useCallback((input: string) => {
    const normalized = input.startsWith('http') || input.startsWith('dragon://') 
      ? input 
      : normalizeUrl(input, settings.searchEngine);
    
    if (normalized !== 'dragon://home') {
      addHistory({ 
        url: normalized, 
        title: getDisplayTitle(normalized) 
      });
    }

    navigateTab(normalized);
    engine.open(normalized, {
      themeColor: '#f97316',
      isPrivate: activeTab.isPrivate,
      searchEngine: settings.searchEngine,
      isDesktopMode: settings.dragonStrength
    });
    setViewMode(BrowserViewMode.BROWSER);
  }, [navigateTab, engine, activeTab.isPrivate, settings.searchEngine, settings.dragonStrength, setViewMode, addHistory]);

  const handleOpenInNewTab = useCallback((url: string) => {
    const normalized = normalizeUrl(url, settings.searchEngine);
    const newId = Math.random().toString(36).substring(2, 15);
    const newTab: Tab = {
      id: newId,
      url: normalized,
      title: getDisplayTitle(normalized),
      lastAccessed: Date.now(),
      isLoading: true,
      isPrivate: activeTab.isPrivate,
      history: [normalized],
      currentIndex: 0,
    };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newId);
    setViewMode(BrowserViewMode.BROWSER);
    
    engine.open(normalized, {
      themeColor: '#f97316',
      isPrivate: activeTab.isPrivate,
      searchEngine: settings.searchEngine,
      isDesktopMode: settings.dragonStrength
    });
  }, [activeTab.isPrivate, settings.searchEngine, setActiveTabId, setTabs, setViewMode, engine, settings.dragonStrength]);

  const handleUrlSubmit = () => {
    if (urlInputValue.trim()) {
      handleNavigate(urlInputValue);
    }
  };

  const handleHomeClick = () => {
    if (activeTab.url === 'dragon://home') {
      setViewMode(BrowserViewMode.BROWSER);
    } else {
      createTab(activeTab.isPrivate);
      setViewMode(BrowserViewMode.BROWSER);
    }
  };

  const handleSummarize = async () => {
    if (isSummarizing) return;
    const contentToSummarize = `Page Title: ${activeTab.title}\nURL: ${activeTab.url}`;
    await generateSummary(contentToSummarize);
  };

  const handleBookmark = () => {
    toggleBookmark(activeTab.url, activeTab.title);
    setShowBookmarkToast(true);
    setTimeout(() => setShowBookmarkToast(false), 2000);
  };

  const isBookmarked = bookmarks.some(b => b.url === activeTab.url);

  return (
    <div className="flex flex-col h-screen w-full bg-slate-50 dark:bg-black text-slate-900 dark:text-white overflow-hidden font-sans relative transition-colors duration-300">
      
      <header className="h-14 bg-white dark:bg-black border-b border-slate-200 dark:border-white/5 flex items-center px-2 gap-2 z-50 shrink-0 transition-colors duration-300">
        <div className="flex items-center shrink-0 gap-1">
          <button 
            onClick={goBack} 
            className="p-2 text-slate-900 dark:text-white active:scale-90 transition-transform disabled:opacity-20 hover:bg-slate-100 dark:hover:bg-white/10 rounded-full"
            disabled={activeTab.currentIndex <= 0}
            title="Back"
          >
            <ChevronLeft size={20} strokeWidth={2.5} />
          </button>
          
          <button 
            onClick={handleHomeClick}
            className="p-2 text-slate-500 hover:text-orange-500 active:scale-90 transition-transform hover:bg-slate-100 dark:hover:bg-white/10 rounded-full"
            title="Home"
          >
            <Home size={20} strokeWidth={2} />
          </button>
        </div>

        <div className="flex-1 min-w-0">
          <AddressBar 
            activeTab={activeTab}
            urlInputValue={urlInputValue}
            onUrlChange={setUrlInputValue}
            onUrlSubmit={handleUrlSubmit}
            onReload={handleReload}
            accentColor="#f97316"
            onSummarize={handleSummarize}
            isSummarizing={isSummarizing}
          />
        </div>

        <div className="flex items-center shrink-0 gap-1">
          <button 
            onClick={handleReload}
            className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white active:rotate-180 duration-500 transition-all hover:bg-slate-100 dark:hover:bg-white/10 rounded-full"
            title="Reload"
          >
            <RotateCcw size={18} />
          </button>

          <button
            onClick={handleBookmark}
            className={`p-2 transition-colors hover:bg-slate-100 dark:hover:bg-white/10 rounded-full ${isBookmarked ? 'text-orange-500' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'}`}
            title="Bookmark"
          >
            <Star size={20} fill={isBookmarked ? "currentColor" : "none"} />
          </button>

          <button 
            onClick={() => setViewMode(BrowserViewMode.TAB_SWITCHER)}
            className="p-2 text-slate-500 hover:text-slate-900 dark:hover:text-white active:scale-90 transition-transform flex items-center justify-center hover:bg-slate-100 dark:hover:bg-white/10 rounded-full"
            title="Tabs"
          >
            <div className="w-5 h-5 border-[1.5px] border-currentColor rounded-md flex items-center justify-center text-[10px] font-black">
              {tabs.length}
            </div>
          </button>

          <button 
            onClick={() => createTab(activeTab.isPrivate)}
            className="p-2 text-slate-500 hover:text-orange-500 active:scale-90 transition-transform hover:bg-slate-100 dark:hover:bg-white/10 rounded-full"
            title="New Tab"
          >
            <Plus size={22} />
          </button>
          
          {settings.toolbarConfig.showMic && (
            <button 
              onClick={startListening}
              className={`p-2 transition-all hover:bg-slate-100 dark:hover:bg-white/10 rounded-full ${isListening ? 'text-orange-500 animate-pulse' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'}`}
              title="Voice Search"
            >
              <Mic size={18} />
            </button>
          )}

          {settings.toolbarConfig.showDesktop && (
            <button 
              onClick={() => updateSettings({ dragonStrength: !settings.dragonStrength })}
              className={`p-2 transition-colors hover:bg-slate-100 dark:hover:bg-white/10 rounded-full ${settings.dragonStrength ? 'text-orange-500' : 'text-slate-500 hover:text-slate-900 dark:hover:text-white'}`}
              title="Desktop Mode"
            >
              <Monitor size={18} />
            </button>
          )}
        </div>
      </header>

      <main className="flex-1 relative overflow-hidden flex flex-col">
        {/* AI SUMMARY POPUP */}
        {summary && (
          <div className="absolute top-4 right-4 z-[100] w-72 bg-[#0a0a0a]/95 backdrop-blur-2xl border border-orange-500/30 rounded-3xl p-5 shadow-2xl animate-fade-in ring-1 ring-orange-500/10">
            <div className="flex justify-between items-start mb-4">
              <div className="flex items-center gap-2">
                <div className="p-1.5 bg-orange-500/10 rounded-lg">
                  <Sparkles className="w-3.5 h-3.5 text-orange-500" />
                </div>
                <div>
                  <h3 className="text-[10px] font-black text-white uppercase tracking-widest leading-none">Dragon Insight</h3>
                  <p className="text-[8px] text-slate-500 font-bold uppercase tracking-wide">Gemini 3 Flash</p>
                </div>
              </div>
              <div className="flex items-center gap-1">
                 <button 
                   onClick={() => {
                     navigator.clipboard.writeText(summary);
                     alert("Summary Copied");
                   }}
                   className="p-1.5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors"
                 >
                   <Copy className="w-3 h-3" />
                 </button>
                 <button onClick={clearSummary} className="p-1.5 hover:bg-white/10 rounded-lg text-slate-400 hover:text-white transition-colors">
                   <X className="w-3.5 h-3.5" />
                 </button>
              </div>
            </div>
            <div className="text-[11px] text-slate-300 leading-relaxed font-medium whitespace-pre-wrap">
              {summary}
            </div>
          </div>
        )}
        
        {/* Bookmark Toast */}
        {showBookmarkToast && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[120] animate-fade-in pointer-events-none">
            <div className="bg-slate-900/90 backdrop-blur-md text-white px-4 py-2.5 rounded-full flex items-center gap-2 shadow-xl border border-white/10">
              <CheckCircle size={14} className="text-orange-500" />
              <span className="text-[10px] font-black uppercase tracking-widest">Page Bookmarked</span>
            </div>
          </div>
        )}

        <div className={`absolute inset-0 z-0 ${viewMode === BrowserViewMode.BROWSER ? 'visible' : 'invisible pointer-events-none'}`}>
          {tabs.map((tab) => (
            <div 
              key={tab.id}
              className={`absolute inset-0 transition-opacity duration-300 ${tab.id === activeTab.id ? 'opacity-100 pointer-events-auto' : 'opacity-0 pointer-events-none'}`}
            >
              {tab.url === 'dragon://home' ? (
                <NewTabPage 
                  onNavigate={handleNavigate} 
                  onOpenInNewTab={handleOpenInNewTab}
                />
              ) : (
                <div className="w-full h-full relative">
                  <FireProgressBar isLoading={tab.isLoading} themeColor="#f97316" />
                  <BrowserViewport 
                    activeTab={tab}
                    onLoadStart={() => setTabLoading(true)}
                    onLoadEnd={() => setTabLoading(false)}
                    isDragonBreath={settings.dragonBreath}
                    isDesktopMode={settings.dragonStrength}
                    accentColor="#f97316"
                    onReload={handleReload}
                    refreshTrigger={refreshTrigger}
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        {viewMode !== BrowserViewMode.BROWSER && (
          <div className="absolute inset-0 z-10 bg-slate-50 dark:bg-black animate-fade-in">
            {viewMode === BrowserViewMode.TAB_SWITCHER && (
              <TabSwitcher 
                tabs={tabs} 
                activeTabId={activeTab.id} 
                onSelectTab={(id) => { setActiveTabId(id); setViewMode(BrowserViewMode.BROWSER); }}
                onCloseTab={closeTab}
                onCreateTab={(isPrivate) => { createTab(isPrivate); setViewMode(BrowserViewMode.BROWSER); }}
                onClose={() => setViewMode(BrowserViewMode.BROWSER)}
                onCloseIncognito={closeIncognitoTabs}
                onCloseAll={clearCurrentSession}
              />
            )}
            {viewMode === BrowserViewMode.SETTINGS && <Settings />}
            {viewMode === BrowserViewMode.DOWNLOADS && <Downloads />}
            {viewMode === BrowserViewMode.HISTORY && <History />}
            {viewMode === BrowserViewMode.BOOKMARKS && <Bookmarks onNavigate={handleNavigate} />}
            {viewMode === BrowserViewMode.NOTES_LIBRARY && <NotesLibrary />}
            {viewMode === BrowserViewMode.SHIELD && <ShieldPage />}
          </div>
        )}

        {settings.toolbarConfig.showNotes && (
        <button 
          onClick={() => setIsNotesPopupOpen(true)}
          className="fixed bottom-[90px] right-5 w-14 h-14 bg-[#E11D48] rounded-full flex items-center justify-center shadow-xl shadow-red-900/40 active:scale-90 transition-all z-[60] group border border-white/10"
        >
          <Pencil size={24} className="text-black" strokeWidth={2.5} />
        </button>
        )}

        <QuickNotesPopup 
          isOpen={isNotesPopupOpen} 
          onClose={() => setIsNotesPopupOpen(false)} 
        />
      </main>

      <nav className="h-[72px] bg-white dark:bg-black border-t border-slate-200 dark:border-white/5 flex items-center justify-around px-2 z-50 relative pb-safe-bottom transition-colors duration-300">
        <button onClick={() => setViewMode(BrowserViewMode.BOOKMARKS)} className={`flex flex-col items-center gap-1 flex-1 transition-colors ${viewMode === BrowserViewMode.BOOKMARKS ? 'text-orange-500' : 'text-slate-500 dark:text-slate-500'}`}>
          <Star size={18} />
          <span className="text-[8px] font-black uppercase tracking-tighter">Bookmarks</span>
        </button>
        
        <button onClick={() => setViewMode(BrowserViewMode.SHIELD)} className={`flex flex-col items-center gap-1 flex-1 transition-colors ${viewMode === BrowserViewMode.SHIELD ? 'text-orange-500' : 'text-slate-500 dark:text-slate-500'}`}>
          <div className="relative">
            <Shield size={18} />
            {settings.adBlockEnabled && <div className="absolute top-0 -right-1 w-1.5 h-1.5 bg-orange-500 rounded-full" />}
          </div>
          <span className="text-[8px] font-black uppercase tracking-tighter">Shield</span>
        </button>

        <div className="flex-1 flex justify-center -mt-8 relative z-10">
          <motion.button 
            onClick={handleHomeClick}
            className="w-14 h-14 bg-black rounded-full p-0.5 border-2 border-orange-600 shadow-[0_10px_30px_rgba(234,88,12,0.4)] active:scale-90 overflow-hidden relative z-50"
            whileTap={{ scale: 0.9 }}
          >
            <img 
              src="https://i.ibb.co/CKVTVSbg/IMG-20251221-WA0021.jpg" 
              className="w-full h-full object-cover rounded-full" 
              alt="Dragon Home" 
            />
          </motion.button>
        </div>

        <button onClick={() => setViewMode(BrowserViewMode.DOWNLOADS)} className={`flex flex-col items-center gap-1 flex-1 transition-colors ${viewMode === BrowserViewMode.DOWNLOADS ? 'text-orange-500' : 'text-slate-500 dark:text-slate-500'}`}>
          <Download size={18} />
          <span className="text-[8px] font-black uppercase tracking-tighter">Downloads</span>
        </button>
        
        <button onClick={() => setViewMode(BrowserViewMode.SETTINGS)} className={`flex flex-col items-center gap-1 flex-1 transition-colors ${viewMode === BrowserViewMode.SETTINGS ? 'text-orange-500' : 'text-slate-500 dark:text-slate-500'}`}>
          <SettingsIcon size={18} />
          <span className="text-[8px] font-black uppercase tracking-tighter">Settings</span>
        </button>
      </nav>
    </div>
  );
};

const App = () => {
  const [showSplash, setShowSplash] = useState(true);

  return (
    <DragonProvider>
      {showSplash ? (
        <SplashScreen onFinish={() => setShowSplash(false)} />
      ) : (
        <AppContent />
      )}
    </DragonProvider>
  );
};

export default App;
