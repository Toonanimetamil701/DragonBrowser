
import React, { useState, useEffect, useCallback, useRef } from 'react';
import { DragonProvider, useDragon } from './DragonContext';
import { NewTabPage } from './components/NewTabPage';
import { BrowserViewport, BrowserViewportHandle } from './components/BrowserViewport';
import { FireProgressBar } from './components/FireProgressBar';
import { Settings } from './pages/Settings';
import { Downloads } from './pages/Downloads';
import { History } from './pages/History';
import { Bookmarks } from './pages/Bookmarks';
import { Library } from './pages/Library';
import { ShieldPage } from './pages/ShieldPage';
import { MainMenu } from './components/MainMenu';
import { TabSwitcher } from './components/TabSwitcher';
import { BrowserViewMode, Tab } from './types';
import { Home, Star, Mic, Plus, CheckCircle, Camera, Monitor, FileText, Pencil } from 'lucide-react';
import { useTabs } from './hooks/useTabs';
import { normalizeUrl, getDisplayTitle, cleanUrlForDisplay } from './utils/urlUtils';
import { AddressBar } from './components/AddressBar';
import { useVoiceSearch } from './hooks/useVoiceSearch';
import { useGestures } from './hooks/useGestures';
import { AnimatePresence } from 'framer-motion';
import { SplashScreen } from './components/SplashScreen';
import { App as CapacitorApp } from '@capacitor/app';
import { AppLockScreen } from './components/AppLockScreen';
import { SiteSettingsPopup } from './components/SiteSettingsPopup';
import { ShareIntentDialog } from './components/ShareIntentDialog';
import { ImageContextMenu } from './components/ImageContextMenu';
import { BottomBar } from './components/BottomBar';
import { SearchOverlay } from './components/SearchOverlay';
import { LensActionSheet } from './components/LensActionSheet';
import { MediaPlayer } from './components/MediaPlayer';
import { ImageViewer } from './components/ImageViewer';
import { QuickNotesPopup } from './components/QuickNotesPopup';
import { NotesLibrary } from './pages/NotesLibrary';

const AppContent = () => {
  const { 
    settings, viewMode, setViewMode, updateSettings, addHistory, 
    bookmarks, toggleBookmark, isAppLocked, addDownload,
    imageContextMenuData, closeImageContextMenu,
    activeMedia, closeMedia
  } = useDragon();
  
  const { 
    tabs, tabGroups, activeTab, goBack, goForward, navigateTab, setTabLoading, 
    createTab, createTabGroup, deleteTabGroup, updateTabGroup, moveTabToGroup,
    reloadTab, closeTab, setActiveTabId, setTabs, duplicateTab,
    clearCurrentSession, closeIncognitoTabs, handleInternalNavigate
  } = useTabs(settings.stealthFlight, settings.searchEngine);
  
  const [urlInputValue, setUrlInputValue] = useState('');
  const [refreshTrigger, setRefreshTrigger] = useState(0);
  const [showBookmarkToast, setShowBookmarkToast] = useState(false);
  const [isSiteSettingsOpen, setIsSiteSettingsOpen] = useState(false);
  const [isSearchOverlayOpen, setIsSearchOverlayOpen] = useState(false);
  const [isLensOpen, setIsLensOpen] = useState(false);
  const [isQuickNotesOpen, setIsQuickNotesOpen] = useState(false);
  
  const viewportRefs = useRef<Map<string, BrowserViewportHandle>>(new Map());
  const [shareIntentUrl, setShareIntentUrl] = useState<string | null>(null);

  // THEME SYNCHRONIZATION CORE
  useEffect(() => {
    const updateTheme = () => {
      const root = window.document.documentElement;
      const systemDark = window.matchMedia('(prefers-color-scheme: dark)').matches;
      const isDark = settings.themeMode === 'dark' || 
        (settings.themeMode === 'system' && systemDark);
      
      if (isDark) {
        root.classList.add('dark');
        root.style.colorScheme = 'dark';
      } else {
        root.classList.remove('dark');
        root.style.colorScheme = 'light';
      }

      // Sync Native/Browser Meta Color
      const metaThemeColor = document.querySelector('meta[name="theme-color"]');
      if (metaThemeColor) {
        metaThemeColor.setAttribute('content', isDark ? '#000000' : '#ffffff');
      }
    };

    updateTheme();

    // Listen for OS theme changes
    const mediaQuery = window.matchMedia('(prefers-color-scheme: dark)');
    const handler = () => {
      if (settings.themeMode === 'system') {
        updateTheme();
      }
    };
    
    mediaQuery.addEventListener('change', handler);
    return () => mediaQuery.removeEventListener('change', handler);
  }, [settings.themeMode]);

  const handleSmartBack = useCallback(() => {
    if (isSearchOverlayOpen) {
      setIsSearchOverlayOpen(false);
      return;
    }
    const currentViewport = viewportRefs.current.get(activeTab.id);
    const handledInternally = currentViewport?.goBack() ?? false;
    if (handledInternally) return;
    if (activeTab.currentIndex > 0) goBack(); else CapacitorApp.exitApp();
  }, [activeTab.id, activeTab.currentIndex, goBack, isSearchOverlayOpen]);

  useEffect(() => {
    let backListener: any;
    const setupBackListener = async () => {
      backListener = await CapacitorApp.addListener('backButton', () => {
        if (isSearchOverlayOpen) setIsSearchOverlayOpen(false);
        else if (viewMode === BrowserViewMode.BROWSER) handleSmartBack();
        else setViewMode(BrowserViewMode.BROWSER);
      });
    };
    setupBackListener();
    return () => { if (backListener) backListener.remove(); };
  }, [viewMode, handleSmartBack, setViewMode, isSearchOverlayOpen]);

  const { isListening, startListening } = useVoiceSearch((transcript) => handleNavigate(transcript));

  const gestureHandlers = useGestures({
    onSwipeLeft: () => {
      const idx = tabs.findIndex(t => t.id === activeTab.id);
      if (idx < tabs.length - 1) setActiveTabId(tabs[idx + 1].id);
    },
    onSwipeRight: () => {
      const idx = tabs.findIndex(t => t.id === activeTab.id);
      if (idx > 0) setActiveTabId(tabs[idx - 1].id);
    }
  });

  // PRECISION SYNC: Updates the input field with the RAW literal URL
  useEffect(() => {
    if (!isListening && !isSearchOverlayOpen) {
      setUrlInputValue(cleanUrlForDisplay(activeTab.url));
    }
  }, [activeTab.url, isListening, isSearchOverlayOpen]);

  const handleNavigate = useCallback((input: string) => {
    const normalized = normalizeUrl(input, settings.searchEngine);
    setUrlInputValue(cleanUrlForDisplay(normalized));
    if (normalized !== 'dragon://home') {
      addHistory({ url: normalized, title: getDisplayTitle(normalized) });
    }
    navigateTab(normalized);
    setViewMode(BrowserViewMode.BROWSER);
    setIsSearchOverlayOpen(false);
  }, [navigateTab, settings.searchEngine, setViewMode, addHistory]);

  const handleOpenInNewTab = useCallback((url: string) => {
    const normalized = normalizeUrl(url, settings.searchEngine);
    const newId = Math.random().toString(36).substring(2, 15);
    const newTab: Tab = {
      id: newId, url: normalized, title: getDisplayTitle(normalized),
      lastAccessed: Date.now(), isLoading: true, isPrivate: activeTab.isPrivate,
      history: [normalized], currentIndex: 0, groupId: activeTab.groupId, renderId: 0
    };
    setTabs(prev => [...prev, newTab]);
    setActiveTabId(newId);
    setViewMode(BrowserViewMode.BROWSER);
  }, [activeTab.isPrivate, activeTab.groupId, settings.searchEngine, setActiveTabId, setTabs, setViewMode]);

  const handleToggleDesktopMode = () => {
    updateSettings({ isDesktopMode: !settings.isDesktopMode });
    reloadTab();
  };

  const isBookmarked = bookmarks.some(b => b.url === activeTab.url);
  const isHomePage = activeTab.url === 'dragon://home';

  if (isAppLocked) return <AppLockScreen />;

  return (
    <div className="flex flex-col h-screen w-full bg-slate-50 dark:bg-black text-slate-900 dark:text-white overflow-hidden font-sans relative transition-colors duration-300">
      {viewMode === BrowserViewMode.BROWSER && !isHomePage && (
        <header className="h-[60px] bg-white dark:bg-black border-b border-slate-200 dark:border-white/5 flex items-center px-1 z-50 shrink-0 transition-colors duration-300">
          <button onClick={() => navigateTab('dragon://home')} className="p-2 text-slate-500 hover:text-orange-500 rounded-full pl-3"><Home size={22} /></button>
          <div className="flex-1 min-w-0 mx-1">
            <AddressBar 
              activeTab={activeTab} urlInputValue={urlInputValue}
              onUrlChange={setUrlInputValue} onUrlSubmit={() => handleNavigate(urlInputValue)}
              onReload={() => { reloadTab(); setRefreshTrigger(t => t + 1); }}
              accentColor="#f97316" onSiteSettingsClick={() => setIsSiteSettingsOpen(true)}
              onFocus={() => setIsSearchOverlayOpen(true)}
            />
          </div>
          <div className="flex items-center shrink-0 pr-1 gap-0.5">
            {settings.toolbarConfig.showLens && (
              <button onClick={() => setIsLensOpen(true)} className="p-1.5 text-slate-500 hover:text-orange-500 rounded-full"><Camera size={19} /></button>
            )}
            {settings.toolbarConfig.showMic && (
              <button onClick={startListening} className={`p-1.5 rounded-full ${isListening ? 'text-orange-500' : 'text-slate-500'}`}><Mic size={19} /></button>
            )}
            {settings.toolbarConfig.showDesktopMode && (
              <button onClick={handleToggleDesktopMode} className={`p-1.5 rounded-full ${settings.isDesktopMode ? 'text-orange-500' : 'text-slate-500'}`}><Monitor size={19} /></button>
            )}
            {settings.toolbarConfig.showNewTab && (
              <button onClick={() => createTab(false)} className="p-1.5 text-slate-500 hover:text-orange-500 rounded-full"><Plus size={20} /></button>
            )}
            <button onClick={() => { toggleBookmark(activeTab.url, activeTab.title); setShowBookmarkToast(true); setTimeout(() => setShowBookmarkToast(false), 2000); }} className={`p-1.5 rounded-full ${isBookmarked ? 'text-orange-500' : 'text-slate-500'}`}><Star size={19} fill={isBookmarked ? "currentColor" : "none"} /></button>
          </div>
        </header>
      )}

      <main className="flex-1 relative overflow-hidden flex flex-col" {...gestureHandlers}>
        {showBookmarkToast && (
          <div className="absolute top-4 left-1/2 -translate-x-1/2 z-[120] animate-fade-in pointer-events-none bg-slate-900 text-white px-4 py-2 rounded-full text-[10px] font-black uppercase tracking-widest border border-white/10 flex items-center gap-2"><CheckCircle size={14} className="text-orange-500" /> Bookmarked</div>
        )}

        <div className={`absolute inset-0 z-0 ${viewMode === BrowserViewMode.BROWSER ? 'visible' : 'invisible pointer-events-none'}`}>
          {tabs.map((tab) => (
            <div key={tab.id} className={`absolute inset-0 transition-opacity duration-300 ${tab.id === activeTab.id ? 'opacity-100' : 'opacity-0 pointer-events-none'}`}>
              {tab.url === 'dragon://home' ? (
                <NewTabPage 
                  onNavigate={handleNavigate} 
                  onTriggerSearch={() => setIsSearchOverlayOpen(true)} 
                  onOpenInNewTab={handleOpenInNewTab} 
                />
              ) : (
                <div className="w-full h-full relative">
                  <FireProgressBar isLoading={tab.isLoading} themeColor="#f97316" />
                  <BrowserViewport 
                    ref={(el) => { if (el) viewportRefs.current.set(tab.id, el); else viewportRefs.current.delete(tab.id); }}
                    activeTab={tab} onLoadStart={() => setTabLoading(true)} onLoadEnd={() => setTabLoading(false)}
                    onInternalNavigate={handleInternalNavigate} isDragonBreath={settings.dragonBreath}
                    isDesktopMode={settings.isDesktopMode} javaScriptEnabled={settings.javaScriptEnabled}
                    accentColor="#f97316" onReload={reloadTab} refreshTrigger={refreshTrigger}
                  />
                </div>
              )}
            </div>
          ))}
        </div>

        {/* QUICK NOTES FLOATING ACTION BUTTON - Global primary add note trigger */}
        {viewMode === BrowserViewMode.BROWSER && settings.toolbarConfig.showNotes && (
          <button 
            onClick={() => setIsQuickNotesOpen(true)}
            className="fixed bottom-24 right-6 p-4 bg-white/80 dark:bg-[#0a0a0a]/80 backdrop-blur-xl border border-slate-200 dark:border-red-500/30 text-red-500 rounded-2xl shadow-xl dark:shadow-[0_0_30px_rgba(225,29,72,0.3)] hover:bg-slate-50 dark:hover:bg-red-500/10 active:scale-90 transition-all z-[60] group ring-1 ring-black/5 dark:ring-white/5"
            title="Add Quick Note"
          >
            <Pencil size={24} className="group-hover:rotate-12 transition-transform" />
          </button>
        )}

        {viewMode !== BrowserViewMode.BROWSER && (
          <div className="absolute inset-0 z-10 bg-slate-50 dark:bg-black animate-fade-in transition-colors duration-300">
            {viewMode === BrowserViewMode.TAB_SWITCHER && (
              <TabSwitcher tabs={tabs} tabGroups={tabGroups} activeTabId={activeTab.id} 
                onSelectTab={(id) => { setActiveTabId(id); setViewMode(BrowserViewMode.BROWSER); }}
                onCloseTab={closeTab} onDuplicateTab={duplicateTab} onCreateTab={createTab}
                onCreateGroup={createTabGroup} onDeleteGroup={deleteTabGroup} onUpdateGroup={updateTabGroup}
                onMoveTabToGroup={moveTabToGroup} onClose={() => setViewMode(BrowserViewMode.BROWSER)}
                onCloseIncognito={closeIncognitoTabs} onCloseAll={() => { clearCurrentSession(); setViewMode(BrowserViewMode.BROWSER); }}
              />
            )}
            {viewMode === BrowserViewMode.SETTINGS && <Settings />}
            {viewMode === BrowserViewMode.DOWNLOADS && <Downloads />}
            {viewMode === BrowserViewMode.HISTORY && <History />}
            {viewMode === BrowserViewMode.BOOKMARKS && <Bookmarks onNavigate={handleNavigate} />}
            {viewMode === BrowserViewMode.NOTES_LIBRARY && <NotesLibrary />}
            {viewMode === BrowserViewMode.LIBRARY && <Library />}
            {viewMode === BrowserViewMode.SHIELD && <ShieldPage />}
            {viewMode === BrowserViewMode.MAIN_MENU && <MainMenu />}
          </div>
        )}

        {/* Overlays */}
        <SiteSettingsPopup isOpen={isSiteSettingsOpen} onClose={() => setIsSiteSettingsOpen(false)} url={activeTab.url} />
        <LensActionSheet isOpen={isLensOpen} onClose={() => setIsLensOpen(false)} />
        <QuickNotesPopup isOpen={isQuickNotesOpen} onClose={() => setIsQuickNotesOpen(false)} />
        <AnimatePresence>{imageContextMenuData && <ImageContextMenu key="img-ctx" url={imageContextMenuData.url} onClose={closeImageContextMenu} onOpenInNewTab={handleOpenInNewTab} />}</AnimatePresence>
        <AnimatePresence>{isSearchOverlayOpen && <SearchOverlay isOpen={true} onClose={() => setIsSearchOverlayOpen(false)} onNavigate={handleNavigate} initialValue={urlInputValue} searchEngine={settings.searchEngine} />}</AnimatePresence>
        
        {/* Media Overlays */}
        <AnimatePresence>
          {activeMedia && (
            activeMedia.type === 'image' ? (
              <ImageViewer key="media-image" media={activeMedia} onClose={closeMedia} />
            ) : (
              <MediaPlayer key="media-av" media={activeMedia} onClose={closeMedia} />
            )
          )}
        </AnimatePresence>
      </main>

      {viewMode === BrowserViewMode.BROWSER && (
        <BottomBar 
          onBack={handleSmartBack} onForward={goForward} onSearch={() => setIsSearchOverlayOpen(true)}
          onTabs={() => setViewMode(BrowserViewMode.TAB_SWITCHER)} onMenu={() => setViewMode(BrowserViewMode.MAIN_MENU)}
          tabCount={tabs.length} canGoBack={activeTab.currentIndex > 0} canGoForward={activeTab.currentIndex < activeTab.history.length - 1}
        />
      )}
    </div>
  );
};

const App = () => (
  <DragonProvider>
    <AppContent />
  </DragonProvider>
);

export default App;
