
import { SearchEngine } from '../types';

/**
 * SOVEREIGN CORE OMNIBOX LOGIC (v1.3.1 Smart Search)
 * Input Classifier: Detects Direct URLs vs Search Queries.
 * CRITICAL FIX: Appends &igu=1 to Google searches for iframe compatibility.
 * CRITICAL FIX: Appends ?app=desktop to YouTube.
 * Architect: Amudhan T
 */

export const DESKTOP_USER_AGENT = "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

export const SEARCH_ENGINES_CONFIG: Record<string, { name: string, url: string }> = {
  google: { 
    name: "Google Global", 
    url: "https://www.google.com/search?igu=1&q=" 
  },
  dragon: { 
    name: "Dragon Engine", 
    url: "https://www.google.com/search?igu=1&q=" 
  },
  bing: { 
    name: "Microsoft Bing", 
    url: "https://www.bing.com/search?q=" 
  }
};

export const enforceSovereignProtocol = (url: string): string => {
  let processed = url;

  // Google Iframe Fix (CRITICAL)
  if (processed.includes('google.com') && !processed.includes('igu=1')) {
    const separator = processed.includes('?') ? '&' : '?';
    // Apply fix to main domain and search results
    if (processed.includes('/search') || /google\.com\/?(\?.*)?$/.test(processed)) {
      processed = `${processed}${separator}igu=1`;
    }
  }

  if (processed.includes('m.youtube.com')) {
    processed = processed.replace('m.youtube.com', 'www.youtube.com');
  }
  
  if (processed.includes('m.facebook.com')) {
    processed = processed.replace('m.facebook.com', 'www.facebook.com');
  }

  // YouTube Desktop Fix
  if (processed.includes('youtube.com') && !processed.includes('app=desktop')) {
    const separator = processed.includes('?') ? '&' : '?';
    processed = `${processed}${separator}app=desktop`;
  }

  return processed;
};

export const normalizeUrl = (input: string, engine: SearchEngine = 'google'): string => {
  const query = input ? input.trim() : "";
  if (!query) return 'dragon://home';
  if (query.startsWith('dragon://')) return query;

  // Shortcut Keywords
  const lowerQuery = query.toLowerCase();
  if (lowerQuery === 'google' || lowerQuery === 'google.com') {
    return enforceSovereignProtocol("https://www.google.com/");
  }
  if (lowerQuery === 'youtube' || lowerQuery === 'youtube.com') {
    return "https://www.youtube.com/?app=desktop";
  }

  // Domain Detection
  const isDomain = query.includes(".") && !query.includes(" ");
  
  if (isDomain) {
    let finalUrl = query.startsWith("http") ? query : `https://${query}`;
    return enforceSovereignProtocol(finalUrl);
  } else {
    // Search Engine Query
    const engineConfig = SEARCH_ENGINES_CONFIG[engine] || SEARCH_ENGINES_CONFIG.google;
    return `${engineConfig.url}${encodeURIComponent(query)}`;
  }
};

export const getDisplayTitle = (url: string): string => {
  if (url === 'dragon://home') return 'Dragon Search';
  if (url.startsWith('dragon://')) return url.split('://')[1].toUpperCase();
  try {
    const urlObj = new URL(url);
    const host = urlObj.hostname.replace('www.', '');
    return host.charAt(0).toUpperCase() + host.slice(1);
  } catch {
    return url;
  }
};
