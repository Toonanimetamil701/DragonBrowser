
import { SearchEngine } from '../types';

/**
 * DRAGON CORE OMNIBOX LOGIC (v5.0 Literal-Sync)
 * - Returns 1:1 literal URL strings.
 * - No smart brand mapping or cleaning.
 */

export const SEARCH_ENGINES_CONFIG: Record<string, { name: string, url: string }> = {
  google: { 
    name: "Google Global", 
    url: "https://www.google.com/search?q=" 
  },
  dragon: { 
    name: "Dragon Search", 
    url: "https://www.google.com/search?q=" 
  },
  bing: { 
    name: "Microsoft Bing", 
    url: "https://www.bing.com/search?q=" 
  }
};

export const enforceSovereignProtocol = (url: string): string => {
  if (!url) return url;
  let processed = url;

  // Only inject iframe-bypass (igu=1) for Google Search results to enable functionality
  if ((processed.includes('google.com/search') || processed.includes('google.co.in/search')) && !processed.includes('igu=1')) {
    const separator = processed.includes('?') ? '&' : '?';
    const [base, hash] = processed.split('#');
    processed = `${base}${separator}igu=1${hash ? '#' + hash : ''}`;
  }
  
  return processed;
};

/**
 * DISPLAY: Returns the actual full URL string for the address bar (Chrome Style).
 */
export const cleanUrlForDisplay = (url: string): string => {
  if (!url || url === 'dragon://home') return '';
  // Show the literal raw URL as requested by the user
  return url;
};

/**
 * NORMALIZATION: Strict URL vs Search differentiation.
 */
export const normalizeUrl = (input: string, engine: SearchEngine = 'google'): string => {
  const query = input ? input.trim() : "";
  if (!query) return 'dragon://home';
  if (query.startsWith('dragon://')) return query;

  // 1. Check for protocol
  if (query.startsWith("http://") || query.startsWith("https://")) {
    return enforceSovereignProtocol(query);
  }

  // 2. Strict URL Rule: Must have a dot and NO spaces
  const hasDot = query.includes('.');
  const hasSpace = query.includes(' ');
  
  if (hasDot && !hasSpace) {
    return enforceSovereignProtocol(`https://${query}`);
  }
  
  // 3. Search Fallback
  const engineConfig = SEARCH_ENGINES_CONFIG[engine] || SEARCH_ENGINES_CONFIG.google;
  return enforceSovereignProtocol(`${engineConfig.url}${encodeURIComponent(query)}`);
};

export const getDisplayTitle = (url: string): string => {
  if (!url || url === 'dragon://home') return 'Dragon Search';
  try {
    const urlObj = new URL(url);
    const host = urlObj.hostname.replace('www.', '');
    return host.charAt(0).toUpperCase() + host.slice(1);
  } catch {
    return url;
  }
};
