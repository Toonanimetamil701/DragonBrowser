import { GoogleGenAI, Type } from "@google/genai";

// Initialize with environment variable
// The API key must be obtained exclusively from the environment variable process.env.API_KEY
const apiKey = process.env.API_KEY || '';
const ai = new GoogleGenAI({ apiKey });

export const performDragonSearch = async (query: string): Promise<string> => {
  if (!query || !apiKey) return '';

  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `You are Dragon Browser's AI assistant. 
      The user is searching for: "${query}".
      Provide a concise, helpful summary or answer in plain text (max 100 words). 
      If it's a navigational query, describe the website they might be looking for.`,
      config: {
        thinkingConfig: { thinkingBudget: 0 },
      }
    });

    return response.text || "No results found.";
  } catch (error) {
    console.error("Dragon AI Search Error:", error);
    return "Dragon AI is currently offline.";
  }
};

export const summarizeContent = async (text: string): Promise<string> => {
  if (!apiKey) return "API Key missing.";
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `Analyze the following webpage data (Content/URL/Title) and provide a summary in exactly 3 concise bullet points.
      If the content is minimal or just a URL, summarize what this website is generally known for.

      Input Data: "${text.substring(0, 5000)}..."`,
      config: {
        thinkingConfig: { thinkingBudget: 0 },
      }
    });
    return response.text || "Could not generate summary.";
  } catch (error) {
    console.error("Dragon Insight Error:", error);
    return "Dragon Insight is unavailable.";
  }
};

export const getSearchSuggestions = async (query: string): Promise<string[]> => {
  if (query.length < 3 || !apiKey) return [];
  try {
    const response = await ai.models.generateContent({
      model: 'gemini-3-flash-preview',
      contents: `User is typing in a browser address bar: "${query}". 
      Return a JSON array of 3 short, relevant search suggestions or URL completions.`,
      config: {
        responseMimeType: "application/json",
        responseSchema: {
          type: Type.ARRAY,
          items: {
            type: Type.STRING,
          },
        },
        thinkingConfig: { thinkingBudget: 0 },
      }
    });
    const text = response.text || "[]";
    return JSON.parse(text);
  } catch (error) {
    console.error("Dragon Suggestions Error:", error);
    return [];
  }
};