
import { useState, useCallback, useRef, useEffect } from 'react';
import { useDragon } from '../DragonContext';

export type VoiceState = 'idle' | 'listening' | 'processing' | 'error' | 'success';

export const useVoiceSearch = (onResult: (text: string) => void) => {
  const [voiceState, setVoiceState] = useState<VoiceState>('idle');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  const { requestSystemPermission } = useDragon();
  
  const recognitionRef = useRef<any>(null);
  const onResultRef = useRef(onResult);
  const silenceTimer = useRef<number | null>(null);

  useEffect(() => {
    onResultRef.current = onResult;
  }, [onResult]);

  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try { recognitionRef.current.abort(); } catch (e) {}
      }
      if (silenceTimer.current) clearTimeout(silenceTimer.current);
    };
  }, []);

  const reset = useCallback(() => {
    setVoiceState('idle');
    setInterimTranscript('');
    setError(null);
    if (silenceTimer.current) clearTimeout(silenceTimer.current);
  }, []);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try { recognitionRef.current.stop(); } catch (e) {}
    }
    // Don't immediately set to idle, allow onend to handle flow or force processing state if needed
    if (voiceState === 'listening') {
       setVoiceState('processing');
    }
  }, [voiceState]);

  const startListening = useCallback(async () => {
    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      setVoiceState('error');
      setError('Speech API not supported.');
      return;
    }

    if (voiceState === 'listening') {
      stopListening();
      return;
    }

    // Permission Check
    const hasPermission = await requestSystemPermission('microphone');
    if (!hasPermission) {
      setVoiceState('error');
      setError('Microphone access denied.');
      return;
    }

    try {
      // Reset previous session
      if (recognitionRef.current) {
        try { recognitionRef.current.abort(); } catch (e) {}
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = navigator.language || 'en-US';

      // Silence Timeout: Stop if no speech for 6 seconds
      if (silenceTimer.current) clearTimeout(silenceTimer.current);
      silenceTimer.current = window.setTimeout(() => {
        if (recognitionRef.current) recognitionRef.current.stop();
        setVoiceState('idle'); // Or error 'timeout'
      }, 8000);

      recognition.onstart = () => {
        setVoiceState('listening');
        setInterimTranscript('');
        setError(null);
      };

      recognition.onend = () => {
        // If we ended without success or error, just go back to idle
        // Small delay to let success state show if needed
        setTimeout(() => {
            setVoiceState(prev => prev === 'processing' ? 'idle' : prev);
        }, 500);
      };

      recognition.onerror = (event: any) => {
        console.warn('Dragon Voice Error:', event.error);
        if (event.error === 'no-speech') {
          setVoiceState('idle');
          return;
        }
        
        setVoiceState('error');
        if (event.error === 'not-allowed') {
          setError('Microphone access denied.');
        } else if (event.error === 'network') {
          setError('Network error. Check connection.');
        } else {
          setError('Voice recognition failed.');
        }
      };

      recognition.onresult = (event: any) => {
        // Clear silence timer on activity
        if (silenceTimer.current) clearTimeout(silenceTimer.current);
        // Reset timer for pauses
        silenceTimer.current = window.setTimeout(() => {
            if (recognitionRef.current) recognitionRef.current.stop();
        }, 3000);

        let final = '';
        let interim = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        if (final) {
          setVoiceState('processing'); // Briefly show processing
          setTimeout(() => {
            setVoiceState('success');
            if (onResultRef.current) {
                onResultRef.current(final.trim());
            }
            // Auto close after success
            setTimeout(() => reset(), 1000);
          }, 200);
        } else {
          setInterimTranscript(interim);
        }
      };

      recognitionRef.current = recognition;
      recognition.start();

    } catch (error) {
      console.error("Dragon Voice Init Failure:", error);
      setVoiceState('error');
      setError('Initialization failed.');
    }
  }, [voiceState, stopListening, reset, requestSystemPermission]);

  return { 
    isListening: voiceState === 'listening',
    voiceState,
    interimTranscript, 
    error,
    startListening, 
    stopListening,
    reset
  };
};
