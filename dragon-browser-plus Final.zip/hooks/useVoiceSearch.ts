
import { useState, useCallback, useRef, useEffect } from 'react';

export const useVoiceSearch = (onResult: (text: string) => void) => {
  const [isListening, setIsListening] = useState(false);
  const [interimTranscript, setInterimTranscript] = useState('');
  
  const recognitionRef = useRef<any>(null);
  const onResultRef = useRef(onResult);

  // Keep callback fresh without triggering re-renders of startListening
  useEffect(() => {
    onResultRef.current = onResult;
  }, [onResult]);

  // Cleanup on unmount
  useEffect(() => {
    return () => {
      if (recognitionRef.current) {
        try {
          recognitionRef.current.abort();
        } catch (e) {
          // Ignore abort errors on unmount
        }
      }
    };
  }, []);

  const stopListening = useCallback(() => {
    if (recognitionRef.current) {
      try {
        recognitionRef.current.stop();
      } catch (e) {
        // Ignore stop errors
      }
    }
    setIsListening(false);
    setInterimTranscript('');
  }, []);

  const startListening = useCallback(() => {
    // If already listening, toggle off
    if (isListening) {
      stopListening();
      return;
    }

    const SpeechRecognition = (window as any).SpeechRecognition || (window as any).webkitSpeechRecognition;

    if (!SpeechRecognition) {
      alert('Dragon Voice Protocol: Speech API not supported on this node.');
      return;
    }

    try {
      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = navigator.language || 'en-US';

      recognition.onstart = () => {
        setIsListening(true);
        setInterimTranscript('');
      };

      recognition.onend = () => {
        setIsListening(false);
        // Clear interim on end, final result handled in onresult
        setInterimTranscript('');
      };

      recognition.onerror = (event: any) => {
        console.warn('Dragon Voice Error:', event.error);
        setIsListening(false);
        
        if (event.error === 'not-allowed') {
          alert('Dragon Voice Protocol: Access Denied. Please enable microphone permissions in your browser settings.');
        } else if (event.error === 'no-speech') {
          // Silent fail - usually means no sound detected, don't annoy user
        } else if (event.error === 'network') {
          alert('Dragon Voice Protocol: Network Error. Please check your connection.');
        }
      };

      recognition.onresult = (event: any) => {
        let final = '';
        let interim = '';

        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            final += event.results[i][0].transcript;
          } else {
            interim += event.results[i][0].transcript;
          }
        }

        if (final) {
          if (onResultRef.current) {
            onResultRef.current(final.trim());
          }
        } else {
          setInterimTranscript(interim);
        }
      };

      recognitionRef.current = recognition;
      recognition.start();

    } catch (error) {
      console.error("Dragon Voice Init Failure:", error);
      setIsListening(false);
    }
  }, [isListening, stopListening]);

  // Always return an object, never undefined
  return { 
    isListening, 
    interimTranscript, 
    startListening, 
    stopListening 
  };
};
