
import { useState, useCallback, useRef, useEffect } from 'react';

export type VoiceState = 'idle' | 'listening' | 'processing' | 'error' | 'success';

// Define the Global Interface for the Android Native Bridge and Web APIs
declare global {
  interface Window {
    DragonBridge?: {
      startVoiceRecognition: () => void;
    };
    // Callbacks invoked by Android Native Code
    onVoiceRecognitionResult?: (text: string) => void;
    onVoiceRecognitionError?: (error: string) => void;
    
    // Web Speech API
    SpeechRecognition: any;
    webkitSpeechRecognition: any;
  }
}

export const useVoiceSearch = (onResult: (text: string) => void) => {
  const [voiceState, setVoiceState] = useState<VoiceState>('idle');
  const [interimTranscript, setInterimTranscript] = useState('');
  const [error, setError] = useState<string | null>(null);
  
  const onResultRef = useRef(onResult);
  const recognitionRef = useRef<any>(null);
  const silenceTimer = useRef<number | null>(null);

  useEffect(() => {
    onResultRef.current = onResult;
  }, [onResult]);

  // Setup listeners for Android Native Events
  useEffect(() => {
    window.onVoiceRecognitionResult = (text: string) => {
      setVoiceState('success');
      setInterimTranscript(text);
      
      // Execute the callback with the recognized text
      if (onResultRef.current) {
        onResultRef.current(text);
      }

      // Auto-reset state after a brief success display
      setTimeout(() => {
        setVoiceState('idle');
        setInterimTranscript('');
      }, 1000);
    };

    window.onVoiceRecognitionError = (errorMessage: string) => {
      console.warn("Voice Error:", errorMessage);
      setVoiceState('error');
      setError(errorMessage);
      
      // Auto-reset error state
      setTimeout(() => {
        setVoiceState('idle');
        setError(null);
      }, 2500);
    };

    return () => {
      window.onVoiceRecognitionResult = undefined;
      window.onVoiceRecognitionError = undefined;
    };
  }, []);

  const startListening = useCallback(() => {
    setInterimTranscript('');
    setError(null);

    // 1. Try Native Bridge (Android Wrapper)
    if (window.DragonBridge && window.DragonBridge.startVoiceRecognition) {
      setVoiceState('listening');
      try {
        window.DragonBridge.startVoiceRecognition();
      } catch (e) {
        setVoiceState('error');
        setError('Bridge Connection Failed');
        setTimeout(() => { setVoiceState('idle'); setError(null); }, 2000);
      }
      return;
    } 
    
    // 2. Fallback to Web Speech API (Browser/PWA)
    const SpeechRecognition = window.SpeechRecognition || window.webkitSpeechRecognition;
    
    if (SpeechRecognition) {
      // Abort any existing instances
      if (recognitionRef.current) {
        try { recognitionRef.current.abort(); } catch(e) {}
      }

      const recognition = new SpeechRecognition();
      recognition.continuous = false;
      recognition.interimResults = true;
      recognition.lang = 'en-US'; // Future: Sync with app language settings

      recognition.onstart = () => {
        setVoiceState('listening');
        // Watchdog: If no result or error within 8s, manually time out
        if (silenceTimer.current) clearTimeout(silenceTimer.current);
        silenceTimer.current = window.setTimeout(() => {
            if (voiceState === 'listening') {
                recognition.stop();
                setVoiceState('error');
                setError('No speech detected');
            }
        }, 8000);
      };

      recognition.onresult = (event: any) => {
        if (silenceTimer.current) clearTimeout(silenceTimer.current);
        
        let interim = '';
        for (let i = event.resultIndex; i < event.results.length; ++i) {
          if (event.results[i].isFinal) {
            const finalText = event.results[i][0].transcript;
            setVoiceState('success');
            setInterimTranscript(finalText);
            
            if (onResultRef.current) {
              onResultRef.current(finalText);
            }
          } else {
            interim += event.results[i][0].transcript;
          }
        }
        
        // Show interim results and switch state to 'processing' to indicate activity
        if (interim) {
            setInterimTranscript(interim);
            setVoiceState('processing');
        }
      };

      recognition.onerror = (event: any) => {
        if (silenceTimer.current) clearTimeout(silenceTimer.current);
        console.warn("Web Speech Error:", event.error);
        
        if (event.error === 'aborted') return; // Ignore aborts

        setVoiceState('error');
        
        let msg = 'Voice Error';
        switch(event.error) {
            case 'no-speech': msg = 'No speech detected'; break;
            case 'audio-capture': msg = 'No microphone found'; break;
            case 'not-allowed': msg = 'Microphone permission denied'; break;
            case 'network': msg = 'Network error - Check connection'; break;
            default: msg = 'Recognition failed';
        }
        
        setError(msg);
        
        // Auto-reset
        setTimeout(() => {
            setVoiceState('idle');
            setError(null);
        }, 2500);
      };

      recognition.onend = () => {
        if (silenceTimer.current) clearTimeout(silenceTimer.current);
        
        // Graceful reset if not in a terminal state
        setTimeout(() => {
            setVoiceState(prev => {
                if (prev === 'success') {
                    // Success state auto-clears separately
                    setTimeout(() => { setVoiceState('idle'); setInterimTranscript(''); }, 1000);
                    return 'success';
                }
                if (prev === 'error') return 'error'; 
                return 'idle';
            });
        }, 100);
      };

      try {
        recognition.start();
        recognitionRef.current = recognition;
      } catch (e) {
        setVoiceState('error');
        setError('Could not start recognition');
        setTimeout(() => { setVoiceState('idle'); setError(null); }, 2000);
      }
      return;
    }

    // 3. No support found
    console.warn("No voice support found.");
    setVoiceState('error');
    setError('Voice not supported on this device');
    setTimeout(() => {
        setVoiceState('idle');
        setError(null);
    }, 2500);

  }, []); // Intentionally empty deps to keep stable

  const stopListening = useCallback(() => {
    if (silenceTimer.current) clearTimeout(silenceTimer.current);
    if (recognitionRef.current) {
      recognitionRef.current.stop();
    }
    // State will be updated by onend
  }, []);

  const reset = useCallback(() => {
    if (silenceTimer.current) clearTimeout(silenceTimer.current);
    if (recognitionRef.current) {
        recognitionRef.current.abort(); // Force stop
        recognitionRef.current = null;
    }
    setVoiceState('idle');
    setInterimTranscript('');
    setError(null);
  }, []);

  return { 
    isListening: voiceState === 'listening' || voiceState === 'processing',
    voiceState,
    interimTranscript, 
    error,
    startListening, 
    stopListening,
    reset
  };
};
