
import React, { useState, useRef, useCallback, useEffect } from 'react';

export const usePullToRefresh = (
  enabled: boolean,
  onRefresh: () => void,
  condition: boolean = true
) => {
  const [pullY, setPullY] = useState(0);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const startY = useRef(0);

  // Reset pull if disabled while pulling
  useEffect(() => {
    if (!enabled) setPullY(0);
  }, [enabled]);

  const onTouchStart = useCallback((e: React.TouchEvent) => {
    // Only enable if toggle is ON, conditions met (e.g. not video), and at top of page
    if (!enabled || !condition || isRefreshing || window.scrollY > 0) return;
    startY.current = e.touches[0].clientY;
  }, [enabled, condition, isRefreshing]);

  const onTouchMove = useCallback((e: React.TouchEvent) => {
    if (!enabled || !condition || isRefreshing || startY.current === 0 || window.scrollY > 0) return;
    
    const currentY = e.touches[0].clientY;
    const delta = currentY - startY.current;

    // Only handle pull down gestures
    if (delta > 0) {
      // Resistance factor 0.4 for natural feel
      setPullY(delta * 0.4);
    }
  }, [enabled, condition, isRefreshing]);

  const onTouchEnd = useCallback(() => {
    if (!enabled || !condition || isRefreshing) {
      setPullY(0);
      startY.current = 0;
      return;
    }

    // Rule: Pull down more than 120px to refresh
    if (pullY > 120) {
      setIsRefreshing(true);
      setPullY(60); // Snap to loading indicator position
      
      // Trigger refresh action
      onRefresh();

      // Reset after delay to show loading animation
      setTimeout(() => {
        setIsRefreshing(false);
        setPullY(0);
      }, 1500);
    } else {
      // Spring back if threshold not met
      setPullY(0);
    }
    startY.current = 0;
  }, [enabled, condition, isRefreshing, pullY, onRefresh]);

  return {
    pullY,
    isRefreshing,
    handlers: {
      onTouchStart,
      onTouchMove,
      onTouchEnd
    }
  };
};
