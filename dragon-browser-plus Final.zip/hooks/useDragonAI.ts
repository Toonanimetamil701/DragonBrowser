import { useState, useCallback } from 'react';
import { summarizeContent, getSearchSuggestions } from '../services/geminiService';

export const useDragonAI = () => {
  const [summary, setSummary] = useState<string | null>(null);
  const [isSummarizing, setIsSummarizing] = useState(false);
  const [suggestions, setSuggestions] = useState<string[]>([]);

  const generateSummary = useCallback(async (content: string) => {
    if (!content) return;
    setIsSummarizing(true);
    const result = await summarizeContent(content);
    setSummary(result);
    setIsSummarizing(false);
  }, []);

  const clearSummary = useCallback(() => setSummary(null), []);

  const fetchSuggestions = useCallback(async (query: string) => {
    if (query.length < 2) {
      setSuggestions([]);
      return;
    }
    const results = await getSearchSuggestions(query);
    setSuggestions(results);
  }, []);

  return {
    summary,
    isSummarizing,
    suggestions,
    generateSummary,
    clearSummary,
    fetchSuggestions,
    setSuggestions
  };
};