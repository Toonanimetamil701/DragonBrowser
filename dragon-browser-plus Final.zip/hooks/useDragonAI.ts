
import { useState, useCallback } from 'react';
import { getSearchSuggestions } from '../services/geminiService';

export const useDragonAI = () => {
  const [suggestions, setSuggestions] = useState<string[]>([]);
  const [isLoading, setIsLoading] = useState(false);

  const fetchSuggestions = useCallback(async (query: string) => {
    if (query.length < 2) {
      setSuggestions([]);
      return;
    }
    setIsLoading(true);
    try {
      const results = await getSearchSuggestions(query);
      setSuggestions(results);
    } catch (e) {
      setSuggestions([]);
    } finally {
      setIsLoading(false);
    }
  }, []);

  return {
    suggestions,
    fetchSuggestions,
    setSuggestions,
    isLoading
  };
};
