
import { useCallback, useState, useEffect } from 'react';
import { Browser } from '@capacitor/browser';
import { Capacitor } from '@capacitor/core';
import { SearchEngine } from '../types';

interface DragonEngineOptions {
  themeColor: string;
  isPrivate: boolean;
  searchEngine: SearchEngine;
  isDesktopMode: boolean;
}

export const useDragonEngine = () => {
  const [isActive, setIsActive] = useState(false);
  const [currentUrl, setCurrentUrl] = useState<string | null>(null);

  const open = useCallback(async (url: string, options: DragonEngineOptions) => {
    if (url === 'dragon://newtab') {
      setIsActive(false);
      setCurrentUrl(null);
      return;
    }

    const isNative = Capacitor.isNativePlatform();
    setCurrentUrl(url);
    setIsActive(true);

    if (isNative) {
      try {
        // Dragon Neural Core Native Launch
        await Browser.open({
          url,
          toolbarColor: options.themeColor,
          windowName: options.isPrivate ? '_blank' : '_self', // _blank forces ephemeral-like state in some implementations
        });
        
        // Setup listener to sync back when user closes native tab
        const listener = await Browser.addListener('browserFinished', () => {
          setIsActive(false);
          listener.remove();
        });
      } catch (error) {
        console.error("Dragon Engine Protocol Failure:", error);
      }
    }
  }, []);

  const close = useCallback(async () => {
    if (Capacitor.isNativePlatform()) {
      await Browser.close();
    }
    setIsActive(false);
    setCurrentUrl(null);
  }, []);

  return {
    open,
    close,
    isActive,
    currentUrl
  };
};
