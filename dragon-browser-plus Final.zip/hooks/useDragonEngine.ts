
import { useCallback, useState } from 'react';
import { Capacitor } from '@capacitor/core';
import { SearchEngine } from '../types';

declare global {
  interface Window {
    cordova?: {
      InAppBrowser: {
        open: (url: string, target: string, options: string) => InAppBrowserRef;
      };
    };
  }
}

interface InAppBrowserRef {
  addEventListener: (eventname: string, callback: (event: any) => void) => void;
  removeEventListener: (eventname: string, callback: (event: any) => void) => void;
  close: () => void;
  show: () => void;
  executeScript: (details: any, callback?: (result: any) => void) => void;
  insertCSS: (details: any, callback?: () => void) => void;
}

interface DragonEngineOptions {
  themeColor: string;
  isPrivate: boolean;
  searchEngine: SearchEngine;
  isDesktopMode: boolean;
}

export const useDragonEngine = () => {
  const [isActive, setIsActive] = useState(false);
  const [currentUrl, setCurrentUrl] = useState<string | null>(null);
  const [browserRef, setBrowserRef] = useState<InAppBrowserRef | null>(null);

  const open = useCallback(async (url: string, options: DragonEngineOptions) => {
    if (url === 'dragon://newtab') {
      setIsActive(false);
      setCurrentUrl(null);
      return;
    }

    const isNative = Capacitor.isNativePlatform();
    setCurrentUrl(url);
    setIsActive(true);

    if (isNative && window.cordova?.InAppBrowser) {
      try {
        const target = '_blank';
        
        const optionsList = [
          'location=no',
          'hidden=no',
          'zoom=no',
          'hardwareback=yes',
          'toolbar=yes',
          `toolbarcolor=${options.themeColor.replace('#', '')}`,
          'navigationbuttoncolor=#ffffff',
          'closebuttoncolor=#ffffff',
          'closebuttoncaption=Close',
          'hidenavigationbuttons=no',
          'mediaPlaybackRequiresUserAction=no',
          'allowInlineMediaPlayback=yes',
          'shouldPauseOnSuspend=yes'
        ];

        if (options.isPrivate) {
          optionsList.push('clearcache=yes');
          optionsList.push('clearsessioncache=yes');
        }

        const optionsStr = optionsList.join(',');
        const ref = window.cordova.InAppBrowser.open(url, target, optionsStr);
        setBrowserRef(ref);

        ref.addEventListener('loaderror', (event: any) => {
           alert('Error loading site: ' + event.message);
           console.error("Dragon Engine Load Error:", event.message);
        });

        ref.addEventListener('exit', () => {
          setIsActive(false);
          setBrowserRef(null);
          setCurrentUrl(null);
        });

      } catch (error) {
        console.error("Dragon Engine Protocol Failure:", error);
        window.location.href = url;
      }
    } else {
      window.location.href = url;
    }
  }, []);

  const close = useCallback(async () => {
    if (browserRef) {
      browserRef.close();
    }
    setIsActive(false);
    setCurrentUrl(null);
    setBrowserRef(null);
  }, [browserRef]);

  return {
    open,
    close,
    isActive,
    currentUrl
  };
};
